DROP TABLE IF EXISTS Frequencia;
DROP TABLE IF EXISTS Aula;
DROP TABLE IF EXISTS Matricula;
DROP TABLE IF EXISTS Turma;
DROP TABLE IF EXISTS Disciplina;
DROP TABLE IF EXISTS Usuario;

CREATE TYPE user_type AS ENUM ('aluno', 'professor', 'coordenador');

CREATE TABLE Usuario (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    tipo user_type NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    ativo BOOLEAN DEFAULT true
);

CREATE TABLE Disciplina (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    coordenador_id INT NOT NULL,
    FOREIGN KEY (coordenador_id) REFERENCES Usuario(id)
);

CREATE TABLE Turma (
    id SERIAL PRIMARY KEY,
    disciplina_id INT NOT NULL,
    professor_id INT NOT NULL,
    semestre VARCHAR(20) NOT NULL,
    FOREIGN KEY (disciplina_id) REFERENCES Disciplina(id),
    FOREIGN KEY (professor_id) REFERENCES Usuario(id)
);

CREATE TABLE Matricula (
    id SERIAL PRIMARY KEY,
    aluno_id INT NOT NULL,
    turma_id INT NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES Usuario(id),
    FOREIGN KEY (turma_id) REFERENCES Turma(id),
    UNIQUE (aluno_id, turma_id)
);

CREATE TABLE Aula (
    id SERIAL PRIMARY KEY,
    turma_id INT NOT NULL,
    data DATE NOT NULL,
    conteudo TEXT,
    criado_por INT NOT NULL,
    FOREIGN KEY (turma_id) REFERENCES Turma(id),
    FOREIGN KEY (criado_por) REFERENCES Usuario(id)
);

CREATE TABLE Frequencia (
    id SERIAL PRIMARY KEY,
    aula_id INT NOT NULL,
    aluno_id INT NOT NULL,
    presente BOOLEAN NOT NULL DEFAULT false,
    FOREIGN KEY (aula_id) REFERENCES Aula(id),
    FOREIGN KEY (aluno_id) REFERENCES Usuario(id),
    UNIQUE (aula_id, aluno_id)
);

CREATE TABLE Atividade (
    id SERIAL PRIMARY KEY,
    turma_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT,
    data_atividade DATE NOT NULL,
    tipo VARCHAR(50) NOT NULL DEFAULT 'atividade',
    criado_por INT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (turma_id) REFERENCES Turma(id),
    FOREIGN KEY (criado_por) REFERENCES Usuario(id)
);

