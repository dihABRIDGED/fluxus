-- MySQL Schema for Fluxus System
DROP TABLE IF EXISTS Frequencia;
DROP TABLE IF EXISTS Aula;
DROP TABLE IF EXISTS Matricula;
DROP TABLE IF EXISTS Turma;
DROP TABLE IF EXISTS Disciplina;
DROP TABLE IF EXISTS Usuario;
DROP TABLE IF EXISTS Atividade;

CREATE TABLE Usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    tipo ENUM('aluno', 'professor', 'coordenador') NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    ativo BOOLEAN DEFAULT true
);

CREATE TABLE Disciplina (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    coordenador_id INT NOT NULL,
    FOREIGN KEY (coordenador_id) REFERENCES Usuario(id)
);

CREATE TABLE Turma (
    id INT AUTO_INCREMENT PRIMARY KEY,
    disciplina_id INT NOT NULL,
    professor_id INT NOT NULL,
    semestre VARCHAR(20) NOT NULL,
    FOREIGN KEY (disciplina_id) REFERENCES Disciplina(id),
    FOREIGN KEY (professor_id) REFERENCES Usuario(id)
);

CREATE TABLE Matricula (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_id INT NOT NULL,
    turma_id INT NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES Usuario(id),
    FOREIGN KEY (turma_id) REFERENCES Turma(id),
    UNIQUE KEY unique_matricula (aluno_id, turma_id)
);

CREATE TABLE Aula (
    id INT AUTO_INCREMENT PRIMARY KEY,
    turma_id INT NOT NULL,
    data DATE NOT NULL,
    conteudo TEXT,
    criado_por INT NOT NULL,
    FOREIGN KEY (turma_id) REFERENCES Turma(id),
    FOREIGN KEY (criado_por) REFERENCES Usuario(id)
);

CREATE TABLE Frequencia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aula_id INT NOT NULL,
    aluno_id INT NOT NULL,
    presente BOOLEAN NOT NULL DEFAULT false,
    FOREIGN KEY (aula_id) REFERENCES Aula(id),
    FOREIGN KEY (aluno_id) REFERENCES Usuario(id),
    UNIQUE KEY unique_frequencia (aula_id, aluno_id)
);

CREATE TABLE Atividade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    turma_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT,
    data_atividade DATE NOT NULL,
    tipo VARCHAR(50) NOT NULL DEFAULT 'atividade',
    criado_por INT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (turma_id) REFERENCES Turma(id),
    FOREIGN KEY (criado_por) REFERENCES Usuario(id)
);

