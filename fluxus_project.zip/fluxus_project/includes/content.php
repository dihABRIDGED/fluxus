<?php
/**
 * Main content area
 * Fluxus Project - Optimized Version
 */
?>

<div class="content-wrapper">
    <?php include_once 'cards.php'; ?>
    
    <!-- Additional content sections can be added here -->
    <div class="additional-content">
        <!-- Future content sections -->
    </div>
</div>

