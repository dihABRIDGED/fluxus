<?php
/**
 * Página de Faltas - Aluno (Integrada com TCC 2.0)
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Demo data for student absences
$faltas_demo = [
    ['data' => '2024-12-15', 'disciplina' => 'Matemática', 'conteudo' => 'Equações do 2º grau', 'justificada' => false],
    ['data' => '2024-12-10', 'disciplina' => 'Português', 'conteudo' => 'Análise sintática', 'justificada' => true],
    ['data' => '2024-12-05', 'disciplina' => 'História', 'conteudo' => 'Segunda Guerra Mundial', 'justificada' => false],
    ['data' => '2024-11-28', 'disciplina' => 'Física', 'conteudo' => 'Leis de Newton', 'justificada' => false],
    ['data' => '2024-11-20', 'disciplina' => 'Química', 'conteudo' => 'Tabela Periódica', 'justificada' => true],
];

// Calculate statistics
$total_faltas = count($faltas_demo);
$faltas_justificadas = count(array_filter($faltas_demo, function($f) { return $f['justificada']; }));
$faltas_nao_justificadas = $total_faltas - $faltas_justificadas;
$frequencia_geral = 85; // Demo percentage
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Faltas - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_aluno_integrated.php">Cronograma</a>
            <a href="faltas_integrated.php">Faltas</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Controle de Faltas</h1>
        
        <div class="user-view-selector">
            <button class="view-btn active" onclick="showStudentView()">
                <i class="fas fa-user-graduate"></i> Visão Aluno
            </button>
            <button class="view-btn" onclick="showProfessorView()">
                <i class="fas fa-chalkboard-teacher"></i> Visão Professor
            </button>
        </div>

        <!-- Visão Aluno -->
        <div id="studentView" class="view-section active">
            <div class="frequencia-resumo">
                <div class="card">
                    <h3><i class="fas fa-chart-pie"></i> Frequência Geral</h3>
                    <div class="numero-destaque"><?php echo $frequencia_geral; ?>%</div>
                    <p>Presença nas aulas</p>
                </div>
                <div class="card">
                    <h3><i class="fas fa-calendar-times"></i> Total de Faltas</h3>
                    <div class="numero-destaque"><?php echo $total_faltas; ?></div>
                    <p>Faltas registradas</p>
                </div>
                <div class="card">
                    <h3><i class="fas fa-exclamation-triangle"></i> Não Justificadas</h3>
                    <div class="numero-destaque"><?php echo $faltas_nao_justificadas; ?></div>
                    <p>Faltas sem justificativa</p>
                </div>
                <div class="card">
                    <h3><i class="fas fa-check-circle"></i> Justificadas</h3>
                    <div class="numero-destaque"><?php echo $faltas_justificadas; ?></div>
                    <p>Faltas justificadas</p>
                </div>
            </div>

            <div class="faltas-container">
                <h2><i class="fas fa-list"></i> Histórico de Faltas</h2>
                <table class="tabela-frequencia">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Disciplina</th>
                            <th>Conteúdo</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($faltas_demo as $falta): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($falta['data'])); ?></td>
                            <td><?php echo $falta['disciplina']; ?></td>
                            <td><?php echo $falta['conteudo']; ?></td>
                            <td>
                                <?php if ($falta['justificada']): ?>
                                    <span class="falta-justificada">
                                        <i class="fas fa-check"></i> Justificada
                                    </span>
                                <?php else: ?>
                                    <span class="falta-nao-justificada">
                                        <i class="fas fa-times"></i> Não Justificada
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Visão Professor -->
        <div id="professorView" class="view-section">
            <div class="professor-info">
                <div class="info-card">
                    <h2><i class="fas fa-info-circle"></i> Informações para Professores</h2>
                    <p>Esta seção permite que professores visualizem relatórios de frequência de suas turmas.</p>
                    <div class="professor-actions">
                        <a href="chamada.php" class="btn btn-primary">
                            <i class="fas fa-clipboard-check"></i> Fazer Chamada
                        </a>
                        <a href="agendamento_integrated.php" class="btn btn-secondary">
                            <i class="fas fa-calendar-plus"></i> Agendar Atividade
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .frequencia-resumo {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background-color: #222;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            border: 1px solid #333;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(198, 40, 40, 0.3);
        }

        .card h3 {
            color: #c62828;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .numero-destaque {
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            margin: 15px 0;
        }

        .card p {
            color: #ccc;
            font-size: 14px;
        }

        .faltas-container {
            background: #222;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #333;
        }

        .faltas-container h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .tabela-frequencia {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .tabela-frequencia th,
        .tabela-frequencia td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #444;
        }

        .tabela-frequencia th {
            background-color: #333;
            color: #c62828;
            font-weight: bold;
        }

        .tabela-frequencia td {
            color: white;
        }

        .tabela-frequencia tr:hover {
            background-color: #2a2a2a;
        }

        .falta-justificada {
            color: #4CAF50;
            font-weight: bold;
        }

        .falta-nao-justificada {
            color: #f44336;
            font-weight: bold;
        }

        .professor-info {
            max-width: 600px;
            margin: 0 auto;
        }

        .info-card {
            background: #222;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            border: 1px solid #333;
        }

        .info-card h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .info-card p {
            color: #ccc;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .professor-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        @media (max-width: 768px) {
            .frequencia-resumo {
                grid-template-columns: 1fr;
            }
            
            .professor-actions {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>

    <script>
        function showStudentView() {
            document.getElementById('studentView').classList.add('active');
            document.getElementById('professorView').classList.remove('active');
            document.querySelectorAll('.view-btn')[0].classList.add('active');
            document.querySelectorAll('.view-btn')[1].classList.remove('active');
        }

        function showProfessorView() {
            document.getElementById('studentView').classList.remove('active');
            document.getElementById('professorView').classList.add('active');
            document.querySelectorAll('.view-btn')[0].classList.remove('active');
            document.querySelectorAll('.view-btn')[1].classList.add('active');
        }
    </script>
</body>
</html>

<?php
$con = null;
?>

