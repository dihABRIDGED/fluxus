<?php
/**
 * Página de Cronograma - Aluno (Integrada com TCC 2.0)
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

session_start();

// Check if user is logged in and is a student
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'aluno') {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Get student's activities
$stmt = $con->prepare("
    SELECT a.*, d.nome as disciplina_nome, t.semestre, u.nome as professor_nome
    FROM Atividade a 
    JOIN Turma t ON a.turma_id = t.id 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    JOIN Usuario u ON t.professor_id = u.id
    JOIN Matricula m ON t.id = m.turma_id
    WHERE m.aluno_id = :aluno_id 
    ORDER BY a.data_atividade ASC
");
$stmt->bindParam(':aluno_id', $_SESSION['user_id']);
$stmt->execute();
$atividades = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Separate activities by status
$atividades_futuras = [];
$atividades_passadas = [];
$hoje = date('Y-m-d');

foreach ($atividades as $atividade) {
    if ($atividade['data_atividade'] >= $hoje) {
        $atividades_futuras[] = $atividade;
    } else {
        $atividades_passadas[] = $atividade;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cronograma - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_aluno_integrated.php">Cronograma</a>
            <a href="faltas_integrated.php">Faltas</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Meu Cronograma</h1>
        
        <div class="cronograma-container">
            <div class="atividades-section">
                <h2><i class="fas fa-clock"></i> Próximas Atividades</h2>
                <?php if (empty($atividades_futuras)): ?>
                    <div class="no-activities">
                        <i class="fas fa-calendar-check"></i>
                        <p>Nenhuma atividade próxima agendada.</p>
                    </div>
                <?php else: ?>
                    <div class="atividades-list">
                        <?php foreach ($atividades_futuras as $atividade): ?>
                            <?php
                            $dias_restantes = (strtotime($atividade['data_atividade']) - strtotime($hoje)) / (60 * 60 * 24);
                            $urgencia = '';
                            if ($dias_restantes <= 1) $urgencia = 'urgente';
                            elseif ($dias_restantes <= 7) $urgencia = 'proxima';
                            ?>
                            <div class="atividade-card <?php echo $urgencia; ?>">
                                <div class="atividade-header">
                                    <h3><?php echo htmlspecialchars($atividade['titulo']); ?></h3>
                                    <div class="badges">
                                        <span class="tipo-badge tipo-<?php echo $atividade['tipo']; ?>">
                                            <?php echo ucfirst($atividade['tipo']); ?>
                                        </span>
                                        <?php if ($dias_restantes <= 1): ?>
                                            <span class="urgencia-badge">URGENTE</span>
                                        <?php elseif ($dias_restantes <= 7): ?>
                                            <span class="proxima-badge">PRÓXIMA</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="atividade-info">
                                    <p><strong>Disciplina:</strong> <?php echo $atividade['disciplina_nome'] . ' - ' . $atividade['semestre']; ?></p>
                                    <p><strong>Professor:</strong> <?php echo $atividade['professor_nome']; ?></p>
                                    <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                                    <p><strong>Dias restantes:</strong> <?php echo ceil($dias_restantes); ?> dia(s)</p>
                                    <?php if ($atividade['descricao']): ?>
                                        <p><strong>Descrição:</strong> <?php echo htmlspecialchars($atividade['descricao']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="atividades-section">
                <h2><i class="fas fa-history"></i> Atividades Passadas</h2>
                <?php if (empty($atividades_passadas)): ?>
                    <div class="no-activities">
                        <i class="fas fa-calendar-times"></i>
                        <p>Nenhuma atividade passada registrada.</p>
                    </div>
                <?php else: ?>
                    <div class="atividades-list">
                        <?php foreach (array_slice($atividades_passadas, 0, 10) as $atividade): ?>
                            <div class="atividade-card passada">
                                <div class="atividade-header">
                                    <h3><?php echo htmlspecialchars($atividade['titulo']); ?></h3>
                                    <span class="tipo-badge tipo-<?php echo $atividade['tipo']; ?>">
                                        <?php echo ucfirst($atividade['tipo']); ?>
                                    </span>
                                </div>
                                <div class="atividade-info">
                                    <p><strong>Disciplina:</strong> <?php echo $atividade['disciplina_nome'] . ' - ' . $atividade['semestre']; ?></p>
                                    <p><strong>Professor:</strong> <?php echo $atividade['professor_nome']; ?></p>
                                    <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                                    <?php if ($atividade['descricao']): ?>
                                        <p><strong>Descrição:</strong> <?php echo htmlspecialchars($atividade['descricao']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($atividades_passadas) > 10): ?>
                        <p class="mais-atividades">Mostrando as 10 atividades mais recentes de <?php echo count($atividades_passadas); ?> total.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
        .cronograma-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .atividades-section {
            background: #222;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #333;
        }

        .atividades-section h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .atividades-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .atividade-card {
            border: 1px solid #444;
            border-radius: 8px;
            padding: 20px;
            background: #333;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .atividade-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(198, 40, 40, 0.3);
        }

        .atividade-card.urgente {
            border-left: 5px solid #c62828;
            background: #2d1a1a;
        }

        .atividade-card.proxima {
            border-left: 5px solid #ffc107;
            background: #2d2a1a;
        }

        .atividade-card.passada {
            opacity: 0.7;
            background: #2a2a2a;
        }

        .atividade-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .atividade-header h3 {
            margin: 0;
            color: white;
            font-size: 16px;
            flex: 1;
        }

        .badges {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .tipo-badge, .urgencia-badge, .proxima-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .tipo-prova { background: #c62828; color: white; }
        .tipo-trabalho { background: #28a745; color: white; }
        .tipo-seminario { background: #17a2b8; color: white; }
        .tipo-exercicio { background: #ffc107; color: #212529; }
        .tipo-projeto { background: #6f42c1; color: white; }
        .tipo-atividade { background: #6c757d; color: white; }

        .urgencia-badge {
            background: #c62828;
            color: white;
            animation: pulse 2s infinite;
        }

        .proxima-badge {
            background: #ffc107;
            color: #212529;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }

        .atividade-info p {
            margin: 8px 0;
            font-size: 14px;
            color: #ccc;
        }

        .no-activities {
            text-align: center;
            color: #666;
            padding: 60px;
        }

        .no-activities i {
            font-size: 3rem;
            color: #c62828;
            margin-bottom: 15px;
        }

        .mais-atividades {
            text-align: center;
            color: #666;
            font-style: italic;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #444;
        }

        @media (max-width: 768px) {
            .cronograma-container {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .badges {
                flex-direction: column;
                align-items: flex-end;
            }
        }
    </style>
</body>
</html>

<?php
$con = null;
?>

