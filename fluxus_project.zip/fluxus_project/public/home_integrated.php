<?php
/**
 * Home page - Integração Fluxus + TCC 2.0
 * Funcionalidades do Fluxus com estilo do TCC 2.0
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Educacional Integrado</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <?php if ($_SESSION['user_type'] === 'aluno'): ?>
                <a href="cronograma_aluno_integrated.php">Cronograma</a>
                <a href="faltas_integrated.php">Faltas</a>
            <?php elseif ($_SESSION['user_type'] === 'professor'): ?>
                <a href="cronograma_integrated.php">Cronograma</a>
                <a href="agendamento_integrated.php">Agendamento</a>
                <a href="chamada.php">Frequência</a>
            <?php elseif ($_SESSION['user_type'] === 'coordenador'): ?>
                <a href="cronograma_integrated.php">Cronograma</a>
                <a href="gerenciar_usuarios_integrated.php">Usuários</a>
            <?php endif; ?>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <!-- Hero Section no estilo TCC 2.0 -->
    <section class="hero">
        <div class="hero-content">
            <img src="img/logo.png" alt="Logo do Sistema" class="hero-img" style="width: 100px; margin-bottom: 20px;" />
            <div class="hero-text destaque-texto">
                <h1>Sistema Educacional Integrado</h1>
                <p>A central de todas as suas informações em um só lugar.</p>
            </div>
        </div>
    </section>

    <!-- Carrossel no estilo TCC 2.0 com funcionalidades do Fluxus -->
    <section class="carrossel">
        <div class="carrossel-item bloco bloco1 active">
            <div class="carrossel-icon">
                <i class="fa-solid fa-chart-line"></i>
            </div>
            <div class="carrossel-text">
                <h2>Controle de Frequência</h2>
                <p>Acompanhe suas faltas em tempo real com relatórios visuais e sistema avançado de chamada.</p>
            </div>
        </div>
        
        <div class="carrossel-item bloco bloco2">
            <div class="carrossel-icon">
                <i class="fa-solid fa-calendar-alt"></i>
            </div>
            <div class="carrossel-text">
                <h2>Cronograma Personalizado</h2>
                <p>Visualize seu planejamento com clareza, organização e funcionalidades interativas.</p>
            </div>
        </div>
        
        <div class="carrossel-item bloco bloco3">
            <div class="carrossel-icon">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="carrossel-text">
                <h2>Gestão de Usuários</h2>
                <p>Sistema completo de gerenciamento de alunos, professores e coordenadores.</p>
            </div>
        </div>
        
        <div class="dots">
            <span class="dot active" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </section>

    <!-- Scripts -->
    <script>
        // Carrossel automático do TCC 2.0
        document.addEventListener("DOMContentLoaded", () => {
            let index = 0;
            const items = document.querySelectorAll('.carrossel-item');
            const dots = document.querySelectorAll('.dots .dot');
        
            function changeCarrossel() {
                items.forEach((item, i) => {
                    item.classList.remove('active');
                    dots[i].classList.remove('active');
                });
                items[index].classList.add('active');
                dots[index].classList.add('active');
                index = (index + 1) % items.length;
            }
            
            // Auto-play
            setInterval(changeCarrossel, 5000);
        });

        // Função para navegação manual do carrossel
        function currentSlide(n) {
            const items = document.querySelectorAll('.carrossel-item');
            const dots = document.querySelectorAll('.dots .dot');
            
            items.forEach((item, i) => {
                item.classList.remove('active');
                dots[i].classList.remove('active');
            });
            
            items[n-1].classList.add('active');
            dots[n-1].classList.add('active');
        }
    </script>
</body>
</html>
<?php
// mysqli_close($con);
?>

