<?php
/**
 * Página de Gerenciamento de Usuários - Coordenador (Integrada com TCC 2.0)
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

session_start();

// Check if user is logged in and is a coordinator
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'coordenador') {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Handle form submissions
if ($_POST) {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                $nome = $_POST['nome'];
                $email = $_POST['email'];
                $tipo = $_POST['tipo'];
                $login = $_POST['login'];
                $senha = $_POST['senha'];
                
                $stmt = $con->prepare("INSERT INTO Usuario (nome, email, tipo, login, senha) VALUES (:nome, :email, :tipo, :login, :senha)");
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':tipo', $tipo);
                $stmt->bindParam(':login', $login);
                $stmt->bindParam(':senha', $senha);
                
                if ($stmt->execute()) {
                    $success_message = "Usuário criado com sucesso!";
                } else {
                    $error_message = "Erro ao criar usuário. Verifique se o login e email são únicos.";
                }
                break;
                
            case 'update':
                $id = $_POST['id'];
                $nome = $_POST['nome'];
                $email = $_POST['email'];
                $login = $_POST['login'];
                $ativo = isset($_POST['ativo']) ? 1 : 0;
                
                $stmt = $con->prepare("UPDATE Usuario SET nome = :nome, email = :email, login = :login, ativo = :ativo WHERE id = :id");
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':login', $login);
                $stmt->bindParam(':ativo', $ativo);
                $stmt->bindParam(':id', $id);
                
                if ($stmt->execute()) {
                    $success_message = "Usuário atualizado com sucesso!";
                } else {
                    $error_message = "Erro ao atualizar usuário.";
                }
                break;
                
            case 'delete':
                $id = $_POST['id'];
                $stmt = $con->prepare("DELETE FROM Usuario WHERE id = :id");
                $stmt->bindParam(':id', $id);
                
                if ($stmt->execute()) {
                    $success_message = "Usuário removido com sucesso!";
                } else {
                    $error_message = "Erro ao remover usuário.";
                }
                break;
        }
    }
}

// Get all users
$stmt = $con->prepare("SELECT * FROM Usuario ORDER BY tipo, nome");
$stmt->execute();
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Separate users by type
$alunos = array_filter($usuarios, function($u) { return $u['tipo'] === 'aluno'; });
$professores = array_filter($usuarios, function($u) { return $u['tipo'] === 'professor'; });
$coordenadores = array_filter($usuarios, function($u) { return $u['tipo'] === 'coordenador'; });
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gerenciar Usuários - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_integrated.php">Cronograma</a>
            <a href="gerenciar_usuarios_integrated.php">Usuários</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Gerenciar Usuários</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="gerenciamento-container">
            <!-- Form para criar novo usuário -->
            <div class="form-section">
                <h2><i class="fas fa-user-plus"></i> Criar Novo Usuário</h2>
                <form method="POST" action="gerenciar_usuarios_integrated.php" class="create-form">
                    <input type="hidden" name="action" value="create">
                    
                    <div class="form-group">
                        <label for="nome">Nome Completo:</label>
                        <input type="text" name="nome" id="nome" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo">Tipo de Usuário:</label>
                        <select name="tipo" id="tipo" required>
                            <option value="aluno">Aluno</option>
                            <option value="professor">Professor</option>
                            <option value="coordenador">Coordenador</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="login">Login:</label>
                        <input type="text" name="login" id="login" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="senha">Senha:</label>
                        <input type="password" name="senha" id="senha" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Criar Usuário
                    </button>
                </form>
            </div>
            
            <!-- Lista de usuários -->
            <div class="users-section">
                <div class="users-tabs">
                    <button class="tab-btn active" onclick="showTab('alunos')">
                        <i class="fas fa-user-graduate"></i> Alunos (<?php echo count($alunos); ?>)
                    </button>
                    <button class="tab-btn" onclick="showTab('professores')">
                        <i class="fas fa-chalkboard-teacher"></i> Professores (<?php echo count($professores); ?>)
                    </button>
                    <button class="tab-btn" onclick="showTab('coordenadores')">
                        <i class="fas fa-user-tie"></i> Coordenadores (<?php echo count($coordenadores); ?>)
                    </button>
                </div>
                
                <!-- Alunos -->
                <div id="alunos" class="tab-content active">
                    <div class="users-list">
                        <?php foreach ($alunos as $usuario): ?>
                            <div class="user-card">
                                <div class="user-info">
                                    <h4><?php echo htmlspecialchars($usuario['nome']); ?></h4>
                                    <p><strong>Login:</strong> <?php echo htmlspecialchars($usuario['login']); ?></p>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
                                    <p><strong>Status:</strong> 
                                        <span class="status <?php echo $usuario['ativo'] ? 'ativo' : 'inativo'; ?>">
                                            <?php echo $usuario['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </p>
                                </div>
                                <div class="user-actions">
                                    <button class="btn btn-small btn-edit" onclick="editUser(<?php echo htmlspecialchars(json_encode($usuario)); ?>)">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button class="btn btn-small btn-delete" onclick="deleteUser(<?php echo $usuario['id']; ?>, '<?php echo htmlspecialchars($usuario['nome']); ?>')">
                                        <i class="fas fa-trash"></i> Remover
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Professores -->
                <div id="professores" class="tab-content">
                    <div class="users-list">
                        <?php foreach ($professores as $usuario): ?>
                            <div class="user-card">
                                <div class="user-info">
                                    <h4><?php echo htmlspecialchars($usuario['nome']); ?></h4>
                                    <p><strong>Login:</strong> <?php echo htmlspecialchars($usuario['login']); ?></p>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
                                    <p><strong>Status:</strong> 
                                        <span class="status <?php echo $usuario['ativo'] ? 'ativo' : 'inativo'; ?>">
                                            <?php echo $usuario['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </p>
                                </div>
                                <div class="user-actions">
                                    <button class="btn btn-small btn-edit" onclick="editUser(<?php echo htmlspecialchars(json_encode($usuario)); ?>)">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button class="btn btn-small btn-delete" onclick="deleteUser(<?php echo $usuario['id']; ?>, '<?php echo htmlspecialchars($usuario['nome']); ?>')">
                                        <i class="fas fa-trash"></i> Remover
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Coordenadores -->
                <div id="coordenadores" class="tab-content">
                    <div class="users-list">
                        <?php foreach ($coordenadores as $usuario): ?>
                            <div class="user-card">
                                <div class="user-info">
                                    <h4><?php echo htmlspecialchars($usuario['nome']); ?></h4>
                                    <p><strong>Login:</strong> <?php echo htmlspecialchars($usuario['login']); ?></p>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
                                    <p><strong>Status:</strong> 
                                        <span class="status <?php echo $usuario['ativo'] ? 'ativo' : 'inativo'; ?>">
                                            <?php echo $usuario['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </p>
                                </div>
                                <div class="user-actions">
                                    <button class="btn btn-small btn-edit" onclick="editUser(<?php echo htmlspecialchars(json_encode($usuario)); ?>)">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button class="btn btn-small btn-delete" onclick="deleteUser(<?php echo $usuario['id']; ?>, '<?php echo htmlspecialchars($usuario['nome']); ?>')">
                                        <i class="fas fa-trash"></i> Remover
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para editar usuário -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2><i class="fas fa-user-edit"></i> Editar Usuário</h2>
            <form method="POST" action="gerenciar_usuarios_integrated.php" id="editForm">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-group">
                    <label for="edit_nome">Nome Completo:</label>
                    <input type="text" name="nome" id="edit_nome" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_email">Email:</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_login">Login:</label>
                    <input type="text" name="login" id="edit_login" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="ativo" id="edit_ativo" value="1">
                        <span class="checkmark"></span>
                        Usuário Ativo
                    </label>
                </div>
                
                <div class="modal-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Alterações
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Form oculto para deletar -->
    <form method="POST" action="gerenciar_usuarios_integrated.php" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="delete_id">
    </form>

    <style>
        .gerenciamento-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 400px 1fr;
            gap: 30px;
        }

        .form-section {
            background: #222;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #333;
            height: fit-content;
        }

        .users-section {
            background: #222;
            border-radius: 10px;
            border: 1px solid #333;
            overflow: hidden;
        }

        .form-section h2, .users-section h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: white;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 6px;
            font-size: 14px;
            background-color: #333;
            color: white;
            transition: border-color 0.3s;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #c62828;
            box-shadow: 0 0 0 2px rgba(198, 40, 40, 0.25);
        }

        .users-tabs {
            display: flex;
            background: #333;
            border-bottom: 1px solid #444;
        }

        .tab-btn {
            flex: 1;
            padding: 15px;
            border: none;
            background: transparent;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
            color: #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .tab-btn.active {
            background: #c62828;
            color: white;
        }

        .tab-btn:hover:not(.active) {
            background: #444;
        }

        .tab-content {
            display: none;
            padding: 25px;
        }

        .tab-content.active {
            display: block;
        }

        .users-list {
            display: grid;
            gap: 15px;
        }

        .user-card {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border: 1px solid #444;
            border-radius: 8px;
            background: #333;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .user-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(198, 40, 40, 0.3);
        }

        .user-info h4 {
            margin: 0 0 10px 0;
            color: white;
        }

        .user-info p {
            margin: 5px 0;
            font-size: 14px;
            color: #ccc;
        }

        .status {
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .status.ativo {
            background: #4CAF50;
            color: white;
        }

        .status.inativo {
            background: #f44336;
            color: white;
        }

        .user-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        .btn-edit {
            background: #28a745;
            color: white;
        }

        .btn-edit:hover {
            background: #1e7e34;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background: #c82333;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
        }

        .alert-success {
            background: #2d5a2d;
            color: #4CAF50;
            border: 1px solid #4CAF50;
        }

        .alert-error {
            background: #5a2d2d;
            color: #f44336;
            border: 1px solid #f44336;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #222;
            margin: 5% auto;
            padding: 30px;
            border-radius: 10px;
            width: 500px;
            max-width: 90%;
            position: relative;
            border: 1px solid #333;
        }

        .modal-content h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .close {
            position: absolute;
            right: 15px;
            top: 15px;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: #ccc;
            transition: color 0.3s;
        }

        .close:hover {
            color: #c62828;
        }

        .modal-actions {
            margin-top: 25px;
            display: flex;
            gap: 15px;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            cursor: pointer;
            color: white;
        }

        .checkbox-label input {
            margin-right: 10px;
            width: auto;
        }

        @media (max-width: 768px) {
            .gerenciamento-container {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .user-card {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }
    </style>

    <script>
        function showTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tab buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }

        function editUser(user) {
            document.getElementById('edit_id').value = user.id;
            document.getElementById('edit_nome').value = user.nome;
            document.getElementById('edit_email').value = user.email;
            document.getElementById('edit_login').value = user.login;
            document.getElementById('edit_ativo').checked = user.ativo == 1;
            
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function deleteUser(id, nome) {
            if (confirm('Tem certeza que deseja remover o usuário "' + nome + '"?')) {
                document.getElementById('delete_id').value = id;
                document.getElementById('deleteForm').submit();
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('editModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>

<?php
$con = null;
?>

