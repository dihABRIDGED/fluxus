<?php
/**
 * Demo Aluno page - Integração Fluxus + TCC 2.0
 * Página de demonstração para testar permissões de aluno
 */

// Simular sessão para demo
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_type'] = 'aluno';
$_SESSION['user_name'] = 'Aluno Demo';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Educacional - Aluno Demo</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="demo_aluno.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="demo_aluno.php">Página Inicial</a>
            <a href="cronograma_demo_aluno.php">Cronograma</a>
            <a href="faltas_integrated.php">Faltas</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="#" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <!-- Hero Section no estilo TCC 2.0 -->
    <section class="hero">
        <div class="hero-content">
            <img src="img/logo.png" alt="Logo do Sistema" class="hero-img" style="width: 100px; margin-bottom: 20px;" />
            <div class="hero-text destaque-texto">
                <h1>Área do Aluno</h1>
                <p>Acompanhe suas atividades e desempenho acadêmico.</p>
                <p style="font-size: 14px; opacity: 0.8; margin-top: 10px;">Modo Demo - Logado como Aluno</p>
            </div>
        </div>
    </section>

    <!-- Seção de funcionalidades do aluno -->
    <section class="funcionalidades" style="padding: 50px 20px; max-width: 1200px; margin: 0 auto;">
        <h2 style="text-align: center; color: #c62828; margin-bottom: 40px;">
            <i class="fas fa-graduation-cap"></i> Funcionalidades do Aluno
        </h2>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-calendar-alt"></i> Meu Cronograma
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Visualize suas atividades, provas e trabalhos organizados por data e prioridade.
                </p>
                <a href="cronograma_demo_aluno.php" style="color: #c62828; text-decoration: none; font-weight: bold;">
                    → Ver Cronograma
                </a>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-user-times"></i> Controle de Faltas
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Acompanhe sua frequência e faltas em todas as disciplinas.
                </p>
                <a href="faltas_integrated.php" style="color: #c62828; text-decoration: none; font-weight: bold;">
                    → Ver Faltas
                </a>
            </div>
            
            <div style="background: #333; padding: 20px; border-radius: 10px; border: 1px solid #555; opacity: 0.6;">
                <h3 style="color: #888; margin-bottom: 15px;">
                    <i class="fas fa-clipboard-check"></i> Controle de Frequência
                </h3>
                <p style="color: #888; line-height: 1.6;">
                    Acesso restrito apenas para professores.
                </p>
                <span style="color: #888; font-weight: bold;">
                    ✗ Sem permissão
                </span>
            </div>
            
            <div style="background: #333; padding: 20px; border-radius: 10px; border: 1px solid #555; opacity: 0.6;">
                <h3 style="color: #888; margin-bottom: 15px;">
                    <i class="fas fa-users-cog"></i> Gestão de Usuários
                </h3>
                <p style="color: #888; line-height: 1.6;">
                    Acesso restrito apenas para coordenadores.
                </p>
                <span style="color: #888; font-weight: bold;">
                    ✗ Sem permissão
                </span>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-headset"></i> Central de Suporte
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Acesse a central de suporte para dúvidas e problemas técnicos.
                </p>
                <a href="suporte_integrated.php" style="color: #c62828; text-decoration: none; font-weight: bold;">
                    → Central de Suporte
                </a>
            </div>
        </div>
    </section>

    <!-- Scripts -->
    <script>
        // Verificar se links restritos funcionam
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Demo Aluno carregado - Tipo de usuário:', '<?php echo $_SESSION["user_type"]; ?>');
        });
    </script>
</body>
</html>

