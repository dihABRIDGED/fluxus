<?php
/**
 * Demo Home page - Integração Fluxus + TCC 2.0
 * Página de demonstração sem necessidade de banco de dados
 */

// Simular sessão para demo
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_type'] = 'aluno';
$_SESSION['user_name'] = 'Demo User';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema Educacional Integrado - Demo</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="demo_home.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="demo_home.php">Página Inicial</a>
            <a href="cronograma_aluno_integrated.php">Cronograma</a>
            <a href="faltas_integrated.php">Faltas</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="#" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <!-- Hero Section no estilo TCC 2.0 -->
    <section class="hero">
        <div class="hero-content">
            <img src="img/logo.png" alt="Logo do Sistema" class="hero-img" style="width: 100px; margin-bottom: 20px;" />
            <div class="hero-text destaque-texto">
                <h1>Sistema Educacional Integrado</h1>
                <p>A central de todas as suas informações em um só lugar.</p>
                <p style="font-size: 14px; opacity: 0.8; margin-top: 10px;">Modo Demo - Todas as funcionalidades do Fluxus com design do TCC 2.0</p>
            </div>
        </div>
    </section>

    <!-- Carrossel no estilo TCC 2.0 com funcionalidades do Fluxus -->
    <section class="carrossel">
        <div class="carrossel-item bloco bloco1 active">
            <div class="carrossel-icon">
                <i class="fa-solid fa-chart-line"></i>
            </div>
            <div class="carrossel-text">
                <h2>Controle de Frequência</h2>
                <p>Acompanhe suas faltas em tempo real com relatórios visuais e sistema avançado de chamada.</p>
            </div>
        </div>
        
        <div class="carrossel-item bloco bloco2">
            <div class="carrossel-icon">
                <i class="fa-solid fa-calendar-alt"></i>
            </div>
            <div class="carrossel-text">
                <h2>Cronograma Personalizado</h2>
                <p>Visualize seu planejamento com clareza, organização e funcionalidades interativas.</p>
            </div>
        </div>
        
        <div class="carrossel-item bloco bloco3">
            <div class="carrossel-icon">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="carrossel-text">
                <h2>Gestão de Usuários</h2>
                <p>Sistema completo de gerenciamento de alunos, professores e coordenadores.</p>
            </div>
        </div>
        
        <div class="dots">
            <span class="dot active" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </section>

    <!-- Seção de funcionalidades -->
    <section class="funcionalidades" style="padding: 50px 20px; max-width: 1200px; margin: 0 auto;">
        <h2 style="text-align: center; color: #c62828; margin-bottom: 40px;">
            <i class="fas fa-check-circle"></i> Funcionalidades Implementadas
        </h2>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-calendar-check"></i> Cronograma do Aluno
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Visualização completa de atividades futuras e passadas com indicadores de urgência e detalhes das disciplinas.
                </p>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-calendar-plus"></i> Agendamento de Atividades
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Professores podem agendar provas, trabalhos e outras atividades com descrições detalhadas.
                </p>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-user-times"></i> Controle de Faltas
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Visualização completa do histórico de faltas com estatísticas e status de justificativas.
                </p>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-headset"></i> Central de Suporte
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    FAQ interativo e formulário de contato para suporte técnico e dúvidas do sistema.
                </p>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-users-cog"></i> Gestão de Usuários
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Interface completa para coordenadores gerenciarem alunos, professores e outros usuários.
                </p>
            </div>
            
            <div style="background: #222; padding: 20px; border-radius: 10px; border: 1px solid #333;">
                <h3 style="color: #c62828; margin-bottom: 15px;">
                    <i class="fas fa-mobile-alt"></i> Design Responsivo
                </h3>
                <p style="color: #ccc; line-height: 1.6;">
                    Interface adaptada para todos os dispositivos mantendo o estilo visual do TCC 2.0.
                </p>
            </div>
        </div>
    </section>

    <!-- Scripts -->
    <script>
        // Carrossel automático do TCC 2.0
        document.addEventListener("DOMContentLoaded", () => {
            let index = 0;
            const items = document.querySelectorAll('.carrossel-item');
            const dots = document.querySelectorAll('.dots .dot');
        
            function changeCarrossel() {
                items.forEach((item, i) => {
                    item.classList.remove('active');
                    dots[i].classList.remove('active');
                });
                items[index].classList.add('active');
                dots[index].classList.add('active');
                index = (index + 1) % items.length;
            }
            
            // Auto-play
            setInterval(changeCarrossel, 5000);
        });

        // Função para navegação manual do carrossel
        function currentSlide(n) {
            const items = document.querySelectorAll('.carrossel-item');
            const dots = document.querySelectorAll('.dots .dot');
            
            items.forEach((item, i) => {
                item.classList.remove('active');
                dots[i].classList.remove('active');
            });
            
            items[n-1].classList.add('active');
            dots[n-1].classList.add('active');
        }
    </script>
</body>
</html>

