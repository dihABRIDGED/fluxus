<?php
/**
 * Página de Chamada - Professor
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

session_start();

// Check if user is logged in and is a professor
if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true || $_SESSION["user_type"] !== "professor") {
    header("Location: index.php");
    exit();
}

require_once '../includes/connection.php';

// Get professor's classes (simplified for demo)
$turmas = [
    ['id' => 1, 'disciplina_nome' => 'Matemática', 'semestre' => '2024.1'],
    ['id' => 2, 'disciplina_nome' => 'Português', 'semestre' => '2024.1'],
    ['id' => 3, 'disciplina_nome' => 'História', 'semestre' => '2024.1']
];

// Handle form submission
if ($_POST) {
    $turma_id = $_POST['turma_id'];
    $data = $_POST['data'];
    $conteudo = $_POST['conteudo'];
    
    $success_message = "Chamada realizada com sucesso!";
}

// Get selected class students if turma_id is provided
$selected_turma_id = $_GET['turma_id'] ?? null;
$alunos_turma = [];
if ($selected_turma_id) {
    // Demo students
    $alunos_turma = [
        ['id' => 1, 'nome' => 'Ana Silva'],
        ['id' => 2, 'nome' => 'Bruno Santos'],
        ['id' => 3, 'nome' => 'Carlos Oliveira'],
        ['id' => 4, 'nome' => 'Diana Costa'],
        ['id' => 5, 'nome' => 'Eduardo Lima']
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Frequência - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_integrated.php">Cronograma</a>
            <a href="chamada.php">Frequência</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Controle de Frequência</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <div class="user-view-selector">
            <button class="view-btn active" onclick="showProfessorView()">
                <i class="fas fa-chalkboard-teacher"></i> Visão Professor
            </button>
            <button class="view-btn" onclick="showStudentView()">
                <i class="fas fa-user-graduate"></i> Visão Aluno
            </button>
        </div>

        <!-- Visão Professor -->
        <div id="professorView" class="view-section active">
            <div class="chamada-container">
                <div class="step-card">
                    <h2><i class="fas fa-users"></i> 1. Selecione a Turma</h2>
                    <form method="GET" action="chamada.php">
                        <select name="turma_id" onchange="this.form.submit()" required>
                            <option value="">Selecione uma turma...</option>
                            <?php foreach ($turmas as $turma): ?>
                                <option value="<?php echo $turma['id']; ?>" <?php echo $selected_turma_id == $turma['id'] ? 'selected' : ''; ?>>
                                    <?php echo $turma['disciplina_nome'] . ' - ' . $turma['semestre']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
                
                <?php if ($selected_turma_id && !empty($alunos_turma)): ?>
                <div class="step-card">
                    <h2><i class="fas fa-clipboard-check"></i> 2. Registrar Aula e Presença</h2>
                    <form method="POST" action="chamada.php">
                        <input type="hidden" name="turma_id" value="<?php echo $selected_turma_id; ?>">
                        
                        <div class="aula-info">
                            <div class="form-group">
                                <label for="data">Data da Aula:</label>
                                <input type="date" name="data" id="data" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="conteudo">Conteúdo da Aula:</label>
                                <textarea name="conteudo" id="conteudo" rows="3" placeholder="Descreva o conteúdo abordado na aula..."></textarea>
                            </div>
                        </div>
                        
                        <div class="lista-alunos">
                            <h3>Lista de Presença</h3>
                            <div class="alunos-grid">
                                <?php foreach ($alunos_turma as $aluno): ?>
                                <div class="aluno-item">
                                    <label class="checkbox-container">
                                        <input type="checkbox" name="presente_<?php echo $aluno['id']; ?>" value="1">
                                        <span class="checkmark"></span>
                                        <?php echo $aluno['nome']; ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Registrar Chamada
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="marcarTodos()">
                                <i class="fas fa-check-double"></i> Marcar Todos
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="desmarcarTodos()">
                                <i class="fas fa-times"></i> Desmarcar Todos
                            </button>
                        </div>
                    </form>
                </div>
                <?php elseif ($selected_turma_id): ?>
                <div class="no-students">
                    <i class="fas fa-user-slash"></i>
                    <p>Nenhum aluno encontrado nesta turma.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Visão Aluno -->
        <div id="studentView" class="view-section">
            <div class="frequencia-resumo">
                <div class="card">
                    <h3>Frequência Geral</h3>
                    <div class="numero-risco">85%</div>
                    <p>Presença nas aulas</p>
                </div>
                <div class="card">
                    <h3>Faltas no Mês</h3>
                    <div class="numero-risco">3</div>
                    <p>Faltas em Dezembro</p>
                </div>
            </div>

            <table class="tabela-frequencia">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Disciplina</th>
                        <th>Conteúdo</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>15/12/2024</td>
                        <td>Matemática</td>
                        <td>Equações do 2º grau</td>
                        <td><span class="presenca">Presente</span></td>
                    </tr>
                    <tr>
                        <td>14/12/2024</td>
                        <td>Português</td>
                        <td>Análise sintática</td>
                        <td><span class="falta">Falta</span></td>
                    </tr>
                    <tr>
                        <td>13/12/2024</td>
                        <td>História</td>
                        <td>Segunda Guerra Mundial</td>
                        <td><span class="presenca">Presente</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function showProfessorView() {
            document.getElementById('professorView').classList.add('active');
            document.getElementById('studentView').classList.remove('active');
            document.querySelectorAll('.view-btn')[0].classList.add('active');
            document.querySelectorAll('.view-btn')[1].classList.remove('active');
        }

        function showStudentView() {
            document.getElementById('professorView').classList.remove('active');
            document.getElementById('studentView').classList.add('active');
            document.querySelectorAll('.view-btn')[0].classList.remove('active');
            document.querySelectorAll('.view-btn')[1].classList.add('active');
        }

        function marcarTodos() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name^="presente_"]');
            checkboxes.forEach(checkbox => checkbox.checked = true);
        }

        function desmarcarTodos() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name^="presente_"]');
            checkboxes.forEach(checkbox => checkbox.checked = false);
        }
    </script>

    <style>
        .chamada-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .step-card {
            background: #222;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid #333;
        }

        .step-card h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: white;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 5px;
            background-color: #333;
            color: white;
            font-size: 14px;
        }

        .alunos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .aluno-item {
            padding: 15px;
            border: 1px solid #444;
            border-radius: 8px;
            background: #333;
            transition: background-color 0.3s;
        }

        .aluno-item:hover {
            background: #444;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            cursor: pointer;
            font-size: 14px;
            color: white;
        }

        .checkbox-container input {
            margin-right: 12px;
            width: auto;
            transform: scale(1.2);
        }

        .form-actions {
            margin-top: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .alert-success {
            background: #2d5a2d;
            color: #4CAF50;
            border: 1px solid #4CAF50;
        }

        .no-students {
            text-align: center;
            padding: 60px;
            color: #ccc;
            background: #222;
            border-radius: 10px;
        }

        .no-students i {
            font-size: 3rem;
            color: #c62828;
            margin-bottom: 15px;
        }

        .coordenador-resumo {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            margin-bottom: 30px;
        }

        .coordenador-resumo .card {
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            width: 45%;
        }
    </style>
</body>
</html>
<?php
// mysqli_close($con);
?>

