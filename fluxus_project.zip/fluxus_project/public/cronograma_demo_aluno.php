<?php
/**
 * Cronograma Demo - Aluno (Integrada com TCC 2.0)
 * Página de demonstração sem dependência de banco de dados
 */

// Simular sessão para demo
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_type'] = 'aluno';
$_SESSION['user_name'] = 'Aluno Demo';

// Dados demo para cronograma do aluno
$atividades_demo = [
    [
        'id' => 1,
        'titulo' => 'Prova de Matemática',
        'descricao' => 'Avaliação sobre equações do 2º grau',
        'data_atividade' => '2024-12-20',
        'tipo' => 'prova',
        'disciplina_nome' => 'Matemática',
        'professor_nome' => 'Prof. Silva',
        'urgencia' => 'alta'
    ],
    [
        'id' => 2,
        'titulo' => 'Trabalho de História',
        'descricao' => 'Pesquisa sobre Segunda Guerra Mundial',
        'data_atividade' => '2024-12-22',
        'tipo' => 'trabalho',
        'disciplina_nome' => 'História',
        'professor_nome' => 'Prof. Santos',
        'urgencia' => 'media'
    ],
    [
        'id' => 3,
        'titulo' => 'Seminário de Português',
        'descricao' => 'Apresentação sobre literatura brasileira',
        'data_atividade' => '2024-12-25',
        'tipo' => 'seminario',
        'disciplina_nome' => 'Português',
        'professor_nome' => 'Prof. Costa',
        'urgencia' => 'baixa'
    ],
    [
        'id' => 4,
        'titulo' => 'Prova de Física',
        'descricao' => 'Avaliação sobre mecânica clássica',
        'data_atividade' => '2024-12-15',
        'tipo' => 'prova',
        'disciplina_nome' => 'Física',
        'professor_nome' => 'Prof. Lima',
        'urgencia' => 'concluida'
    ]
];

// Separar atividades por status
$hoje = date('Y-m-d');
$atividades_futuras = [];
$atividades_passadas = [];

foreach ($atividades_demo as $atividade) {
    if ($atividade['data_atividade'] >= $hoje) {
        $atividades_futuras[] = $atividade;
    } else {
        $atividades_passadas[] = $atividade;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Meu Cronograma - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="demo_home.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="demo_home.php">Página Inicial</a>
            <a href="cronograma_demo_aluno.php">Cronograma</a>
            <a href="faltas_integrated.php">Faltas</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="#" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Meu Cronograma</h1>
        
        <div class="cronograma-container">
            <div class="atividades-section">
                <div class="section-header">
                    <h2><i class="fas fa-clock"></i> Próximas Atividades</h2>
                    <span class="count"><?php echo count($atividades_futuras); ?> atividades</span>
                </div>
                
                <div class="atividades-grid">
                    <?php foreach ($atividades_futuras as $atividade): ?>
                    <div class="atividade-card <?php echo $atividade['urgencia']; ?>">
                        <div class="atividade-header">
                            <h3><?php echo $atividade['titulo']; ?></h3>
                            <span class="urgencia-badge <?php echo $atividade['urgencia']; ?>">
                                <?php 
                                switch($atividade['urgencia']) {
                                    case 'alta': echo 'Urgente'; break;
                                    case 'media': echo 'Moderada'; break;
                                    case 'baixa': echo 'Tranquila'; break;
                                }
                                ?>
                            </span>
                        </div>
                        
                        <div class="atividade-info">
                            <p><i class="fas fa-book"></i> <?php echo $atividade['disciplina_nome']; ?></p>
                            <p><i class="fas fa-user"></i> <?php echo $atividade['professor_nome']; ?></p>
                            <p><i class="fas fa-calendar"></i> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                            <p><i class="fas fa-tag"></i> <?php echo ucfirst($atividade['tipo']); ?></p>
                        </div>
                        
                        <div class="atividade-descricao">
                            <p><?php echo $atividade['descricao']; ?></p>
                        </div>
                        
                        <div class="dias-restantes">
                            <?php 
                            $dias = (strtotime($atividade['data_atividade']) - strtotime($hoje)) / (60 * 60 * 24);
                            if ($dias == 0) {
                                echo '<span class="hoje">Hoje!</span>';
                            } elseif ($dias == 1) {
                                echo '<span class="amanha">Amanhã</span>';
                            } else {
                                echo '<span class="futuro">' . ceil($dias) . ' dias</span>';
                            }
                            ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="atividades-section">
                <div class="section-header">
                    <h2><i class="fas fa-check-circle"></i> Atividades Concluídas</h2>
                    <span class="count"><?php echo count($atividades_passadas); ?> atividades</span>
                </div>
                
                <div class="atividades-grid">
                    <?php foreach ($atividades_passadas as $atividade): ?>
                    <div class="atividade-card concluida">
                        <div class="atividade-header">
                            <h3><?php echo $atividade['titulo']; ?></h3>
                            <span class="urgencia-badge concluida">Concluída</span>
                        </div>
                        
                        <div class="atividade-info">
                            <p><i class="fas fa-book"></i> <?php echo $atividade['disciplina_nome']; ?></p>
                            <p><i class="fas fa-user"></i> <?php echo $atividade['professor_nome']; ?></p>
                            <p><i class="fas fa-calendar"></i> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                            <p><i class="fas fa-tag"></i> <?php echo ucfirst($atividade['tipo']); ?></p>
                        </div>
                        
                        <div class="atividade-descricao">
                            <p><?php echo $atividade['descricao']; ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <style>
        .cronograma-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .atividades-section {
            margin-bottom: 40px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }

        .section-header h2 {
            color: #c62828;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .count {
            background: #333;
            color: white;
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 14px;
        }

        .atividades-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }

        .atividade-card {
            background: #222;
            border-radius: 10px;
            padding: 20px;
            border: 1px solid #333;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .atividade-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(198, 40, 40, 0.3);
        }

        .atividade-card.alta {
            border-left: 4px solid #f44336;
        }

        .atividade-card.media {
            border-left: 4px solid #ff9800;
        }

        .atividade-card.baixa {
            border-left: 4px solid #4CAF50;
        }

        .atividade-card.concluida {
            border-left: 4px solid #666;
            opacity: 0.7;
        }

        .atividade-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .atividade-header h3 {
            color: white;
            margin: 0;
            flex: 1;
        }

        .urgencia-badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            margin-left: 10px;
        }

        .urgencia-badge.alta {
            background: #f44336;
            color: white;
        }

        .urgencia-badge.media {
            background: #ff9800;
            color: white;
        }

        .urgencia-badge.baixa {
            background: #4CAF50;
            color: white;
        }

        .urgencia-badge.concluida {
            background: #666;
            color: white;
        }

        .atividade-info {
            margin-bottom: 15px;
        }

        .atividade-info p {
            margin: 8px 0;
            color: #ccc;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .atividade-info i {
            width: 16px;
            color: #c62828;
        }

        .atividade-descricao {
            margin-bottom: 15px;
            padding: 12px;
            background: #333;
            border-radius: 6px;
        }

        .atividade-descricao p {
            color: #ddd;
            margin: 0;
            font-style: italic;
            line-height: 1.4;
        }

        .dias-restantes {
            text-align: center;
            margin-top: 15px;
        }

        .dias-restantes span {
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
        }

        .hoje {
            background: #f44336;
            color: white;
            animation: pulse 2s infinite;
        }

        .amanha {
            background: #ff9800;
            color: white;
        }

        .futuro {
            background: #4CAF50;
            color: white;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @media (max-width: 768px) {
            .atividades-grid {
                grid-template-columns: 1fr;
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Cronograma Aluno Demo carregado');
        });
    </script>
</body>
</html>

