/**
 * Fluxus - Main JavaScript File
 * Optimized Version with Dark Mode System
 */

// ===== DARK MODE SYSTEM =====
class ThemeManager {
  constructor() {
    this.currentTheme = localStorage.getItem('fluxus-theme') || 'light';
    this.init();
  }

  init() {
    this.applyTheme(this.currentTheme);
    this.updateThemeIcon();
  }

  toggleTheme() {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
    this.applyTheme(this.currentTheme);
    this.updateThemeIcon();
    localStorage.setItem('fluxus-theme', this.currentTheme);
  }

  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
  }

  updateThemeIcon() {
    const themeIcon = document.getElementById('theme-icon');
    if (themeIcon) {
      themeIcon.className = this.currentTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }
  }
}

// ===== CAROUSEL SYSTEM =====
class CarouselManager {
  constructor() {
    this.carousel = document.getElementById("memory-carousel");
    this.cards = document.querySelectorAll(".memory-card");
    this.prevBtn = document.getElementById("prev-btn");
    this.nextBtn = document.getElementById("next-btn");
    
    // Variables
    this.currentIndex = 0;
    this.startX = 0;
    this.startY = 0;
    this.isDragging = false;
    this.theta = 0;
    this.radius = this.calculateRadius();
    this.totalCards = this.cards.length;
    
    this.init();
  }

  calculateRadius() {
    return window.innerWidth <= 768 ? 250 : 400;
  }

  init() {
    if (!this.carousel || this.totalCards === 0) return;
    
    this.arrangeCards();
    this.addEventListeners();
  }

  arrangeCards() {
    const angle = 360 / this.totalCards;
    this.cards.forEach((card, index) => {
      const cardAngle = angle * index;
      card.style.transform = `rotateY(${cardAngle}deg) translateZ(${this.radius}px)`;
      card.dataset.index = index;
    });
  }

  addEventListeners() {
    // Button controls
    if (this.prevBtn) this.prevBtn.addEventListener("click", () => this.prevCard());
    if (this.nextBtn) this.nextBtn.addEventListener("click", () => this.nextCard());
    
    // Card flip
    this.cards.forEach((card) => {
      card.addEventListener("click", (e) => this.flipCard(e));
    });

    // Touch/mouse events for dragging
    if (this.carousel) {
      this.carousel.addEventListener("mousedown", (e) => this.dragStart(e));
      this.carousel.addEventListener("touchstart", (e) => this.dragStart(e), { passive: true });
    }
    
    document.addEventListener("mousemove", (e) => this.drag(e));
    document.addEventListener("touchmove", (e) => this.drag(e), { passive: false });
    document.addEventListener("mouseup", (e) => this.dragEnd(e));
    document.addEventListener("touchend", (e) => this.dragEnd(e));

    // Keyboard navigation
    document.addEventListener("keydown", (e) => this.handleKeyDown(e));
    
    // Resize handler
    window.addEventListener("resize", () => this.handleResize());
  }

  rotateCarousel() {
    if (this.carousel) {
      this.carousel.style.transform = `rotateY(${this.theta}deg)`;
      this.currentIndex = Math.round(Math.abs(this.theta / (360 / this.totalCards)) % this.totalCards);
      if (this.currentIndex >= this.totalCards) this.currentIndex = 0;
    }
  }

  nextCard() {
    this.theta -= 360 / this.totalCards;
    this.rotateCarousel();
  }

  prevCard() {
    this.theta += 360 / this.totalCards;
    this.rotateCarousel();
  }

  flipCard(e) {
    const card = e.currentTarget;
    const cardIndex = parseInt(card.dataset.index);

    if (cardIndex === this.currentIndex) {
      card.classList.toggle("flipped");
    }
  }

  dragStart(e) {
    e.preventDefault();
    this.isDragging = true;
    this.startX = e.pageX || e.touches[0].pageX;
  }

  drag(e) {
    if (!this.isDragging) return;
    e.preventDefault();

    const currentX = e.pageX || (e.touches ? e.touches[0].pageX : this.startX);
    const diffX = currentX - this.startX;
    const sensitivity = 0.5;
    const newTheta = this.theta + diffX * sensitivity;

    if (this.carousel) {
      this.carousel.style.transform = `rotateY(${newTheta}deg)`;
    }
  }

  dragEnd(e) {
    if (!this.isDragging) return;
    this.isDragging = false;

    const currentX = e.pageX || (e.changedTouches ? e.changedTouches[0].pageX : this.startX);
    const diffX = currentX - this.startX;

    if (Math.abs(diffX) > 20) {
      if (diffX > 0) {
        this.prevCard();
      } else {
        this.nextCard();
      }
    } else {
      const anglePerCard = 360 / this.totalCards;
      const snapAngle = Math.round(this.theta / anglePerCard) * anglePerCard;
      this.theta = snapAngle;
      this.rotateCarousel();
    }
  }

  handleKeyDown(e) {
    if (e.key === "ArrowLeft") {
      this.nextCard();
    } else if (e.key === "ArrowRight") {
      this.prevCard();
    } else if (e.key === "Enter" || e.key === " ") {
      const currentCard = document.querySelector(`.memory-card[data-index="${this.currentIndex}"]`);
      if (currentCard) {
        currentCard.classList.toggle("flipped");
      }
    }
  }

  handleResize() {
    this.radius = this.calculateRadius();
    this.arrangeCards();
    this.rotateCarousel();
  }
}

// ===== UTILITY FUNCTIONS =====
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// ===== GLOBAL FUNCTIONS =====
function toggleTheme() {
  if (window.themeManager) {
    window.themeManager.toggleTheme();
  }
}

// ===== INITIALIZATION =====
document.addEventListener("DOMContentLoaded", function() {
  // Initialize theme manager
  window.themeManager = new ThemeManager();
  
  // Initialize carousel if cards exist
  if (document.querySelector('.memory-card')) {
    window.carouselManager = new CarouselManager();
  }
  
  // Add smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
  
  // Add loading animation completion
  document.body.classList.add('loaded');
});

// ===== PERFORMANCE OPTIMIZATIONS =====
// Lazy load images
if ('IntersectionObserver' in window) {
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.classList.remove('lazy');
        imageObserver.unobserve(img);
      }
    });
  });

  document.querySelectorAll('img[data-src]').forEach(img => {
    imageObserver.observe(img);
  });
}

// Preload critical resources
function preloadCriticalResources() {
  const criticalImages = [
    'img/logo.png',
    'img/lamp.png'
  ];
  
  criticalImages.forEach(src => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = src;
    document.head.appendChild(link);
  });
}

// Initialize preloading
preloadCriticalResources();

