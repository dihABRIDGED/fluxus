<?php
/**
 * Cronograma Demo - Coordenador (Integrada com TCC 2.0)
 * Página de demonstração sem dependência de banco de dados
 */

// Simular sessão para demo
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_type'] = 'coordenador';
$_SESSION['user_name'] = 'Coord. Demo';

// Dados demo para cronograma
$atividades_demo = [
    [
        'id' => 1,
        'titulo' => 'Prova de Matemática',
        'descricao' => 'Avaliação sobre equações do 2º grau',
        'data_atividade' => '2024-12-20',
        'tipo' => 'prova',
        'disciplina_nome' => 'Matemática',
        'professor_nome' => 'Prof. Silva',
        'semestre' => '2024.2'
    ],
    [
        'id' => 2,
        'titulo' => 'Trabalho de História',
        'descricao' => 'Pesquisa sobre Segunda Guerra Mundial',
        'data_atividade' => '2024-12-22',
        'tipo' => 'trabalho',
        'disciplina_nome' => 'História',
        'professor_nome' => 'Prof. Santos',
        'semestre' => '2024.2'
    ],
    [
        'id' => 3,
        'titulo' => 'Seminário de Português',
        'descricao' => 'Apresentação sobre literatura brasileira',
        'data_atividade' => '2024-12-25',
        'tipo' => 'seminario',
        'disciplina_nome' => 'Português',
        'professor_nome' => 'Prof. Costa',
        'semestre' => '2024.2'
    ]
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cronograma Geral - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="demo_coordenador.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="demo_coordenador.php">Página Inicial</a>
            <a href="cronograma_demo_coordenador.php">Cronograma</a>
            <a href="gerenciar_usuarios_integrated.php">Usuários</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="#" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Cronograma Geral - Coordenação</h1>
        
        <div class="cronograma-stats">
            <div class="stat-card">
                <h3>Total de Atividades</h3>
                <div class="stat-number"><?php echo count($atividades_demo); ?></div>
            </div>
            <div class="stat-card">
                <h3>Disciplinas Ativas</h3>
                <div class="stat-number">3</div>
            </div>
            <div class="stat-card">
                <h3>Professores</h3>
                <div class="stat-number">3</div>
            </div>
        </div>
        
        <div class="calendar-container">
            <div class="calendar-header">
                <h2><i class="fas fa-calendar-alt"></i> Atividades Programadas</h2>
                <p>Visão geral de todas as atividades do sistema</p>
            </div>
            
            <div class="atividades-list">
                <?php foreach ($atividades_demo as $atividade): ?>
                <div class="atividade-card <?php echo $atividade['tipo']; ?>">
                    <div class="atividade-header">
                        <h3><?php echo $atividade['titulo']; ?></h3>
                        <span class="atividade-tipo"><?php echo ucfirst($atividade['tipo']); ?></span>
                    </div>
                    
                    <div class="atividade-info">
                        <p><strong>Disciplina:</strong> <?php echo $atividade['disciplina_nome']; ?></p>
                        <p><strong>Professor:</strong> <?php echo $atividade['professor_nome']; ?></p>
                        <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                        <p><strong>Semestre:</strong> <?php echo $atividade['semestre']; ?></p>
                    </div>
                    
                    <div class="atividade-descricao">
                        <p><?php echo $atividade['descricao']; ?></p>
                    </div>
                    
                    <div class="atividade-actions">
                        <button class="btn btn-small btn-info">
                            <i class="fas fa-eye"></i> Detalhes
                        </button>
                        <button class="btn btn-small btn-warning">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <style>
        .cronograma-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: #222;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            border: 1px solid #333;
        }

        .stat-card h3 {
            color: #c62828;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: white;
        }

        .calendar-container {
            background: #222;
            border-radius: 10px;
            padding: 30px;
            border: 1px solid #333;
        }

        .calendar-header {
            margin-bottom: 30px;
            text-align: center;
        }

        .calendar-header h2 {
            color: #c62828;
            margin-bottom: 10px;
        }

        .calendar-header p {
            color: #ccc;
        }

        .atividades-list {
            display: grid;
            gap: 20px;
        }

        .atividade-card {
            background: #333;
            border-radius: 8px;
            padding: 20px;
            border-left: 4px solid #c62828;
            transition: transform 0.2s;
        }

        .atividade-card:hover {
            transform: translateY(-2px);
        }

        .atividade-card.prova {
            border-left-color: #f44336;
        }

        .atividade-card.trabalho {
            border-left-color: #2196F3;
        }

        .atividade-card.seminario {
            border-left-color: #4CAF50;
        }

        .atividade-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .atividade-header h3 {
            color: white;
            margin: 0;
        }

        .atividade-tipo {
            background: #c62828;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }

        .atividade-info {
            margin-bottom: 15px;
        }

        .atividade-info p {
            margin: 5px 0;
            color: #ccc;
            font-size: 14px;
        }

        .atividade-descricao {
            margin-bottom: 15px;
            padding: 10px;
            background: #444;
            border-radius: 5px;
        }

        .atividade-descricao p {
            color: #ddd;
            margin: 0;
            font-style: italic;
        }

        .atividade-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.3s;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 11px;
        }

        .btn-info {
            background: #17a2b8;
            color: white;
        }

        .btn-info:hover {
            background: #138496;
        }

        .btn-warning {
            background: #ffc107;
            color: #212529;
        }

        .btn-warning:hover {
            background: #e0a800;
        }

        @media (max-width: 768px) {
            .atividade-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .atividade-actions {
                flex-direction: column;
            }
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Cronograma Coordenador Demo carregado');
        });
    </script>
</body>
</html>

