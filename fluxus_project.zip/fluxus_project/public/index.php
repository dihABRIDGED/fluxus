<?php
/**
 * Login page - Integração Fluxus + TCC 2.0
 * Funcionalidades do Fluxus com estilo do TCC 2.0
 */

require_once '../includes/connection.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="login-page">
    <div class="login-container">
        <form class="login-form" action="../core/auth.php" method="POST">
            <img src="img/logo.png" alt="Logo" class="login-logo">
            <h2>Sistema Educacional</h2>
            
            <!-- Seletor de tipo de usuário do TCC 2.0 -->
            <select name="tipoUsuario" id="tipoUsuario" required>
                <option value="">Selecione o tipo de usuário</option>
                <option value="aluno">Aluno</option>
                <option value="professor">Professor</option>
                <option value="coordenador">Coordenador</option>
            </select>
            
            <!-- Campo de login adaptado -->
            <input type="text" name="login" id="identificacao" placeholder="Código de matrícula ou usuário" required>
            
            <!-- Campo de senha -->
            <input type="password" name="senha" id="senha" placeholder="Senha" required>
            
            <!-- Botão de entrar -->
            <button type="submit" id="btn-entrar">
                <i class="fas fa-sign-in-alt"></i> Entrar
            </button>
            
            <!-- Links adicionais -->
            <div class="signup-link">
                <p><a href="#" style="color: rgba(255, 255, 255, 0.7);">Esqueceu a senha?</a></p>
                <p><a href="#" style="color: rgba(255, 255, 255, 0.7);">Não tem uma conta? Cadastre-se</a></p>
            </div>
        </form>
    </div>

    <script>
        // Validação adicional do TCC 2.0
        document.getElementById('btn-entrar').addEventListener('click', function(e) {
            const tipoUsuario = document.getElementById('tipoUsuario').value;
            const identificacao = document.getElementById('identificacao').value;
            const senha = document.getElementById('senha').value;
            
            if (!tipoUsuario) {
                e.preventDefault();
                alert('Por favor, selecione o tipo de usuário.');
                return;
            }
            
            if (!identificacao || !senha) {
                e.preventDefault();
                alert('Por favor, preencha todos os campos.');
                return;
            }
        });
    </script>
</body>
</html>
<?php
// mysqli_close($con);
?>

