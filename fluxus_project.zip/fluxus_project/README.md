# Fluxus - Projeto Completamente Otimizado 🚀

## Visão Geral
Este é o projeto Fluxus **completamente otimizado** com melhor organização de arquivos, sistema de dark mode eficiente para toda a página, responsividade avançada e sistema de cores personalizáveis.

## ✨ Principais Melhorias Implementadas

### 🔐 Campo de Login Atualizado
- **Label alterada**: "Código de Matrícula ou Professor" (ao invés de email)
- **Tipo de input**: Texto para aceitar códigos alfanuméricos
- **Validação**: Mantém a funcionalidade de validação

### 🌙 Sistema de Dark Mode Completo
- **Página inteira**: Afeta todos os elementos da interface
- **Header responsivo**: Muda cores conforme o tema
- **Background cósmico**: Gradientes adaptativos
- **Persistência**: Tema salvo no localStorage
- **Transições suaves**: Mudanças animadas

### 📱 Responsividade Avançada
- **Desktop Large** (1920px+): Layout expandido
- **Desktop** (1024px-1920px): Layout padrão otimizado  
- **Tablet** (768px-1024px): Cards médios, header adaptado
- **Mobile Landscape** (600px-768px): Menu reorganizado
- **Mobile Portrait** (375px-600px): Layout mobile otimizado
- **Extra Small** (<375px): Suporte para dispositivos pequenos

### 🎨 Sistema de Cores Personalizáveis
- **Variáveis CSS centralizadas**: Fácil personalização
- **Classes utilitárias**: `.theme-blue`, `.theme-green`, `.theme-purple`, `.theme-orange`
- **Cores da marca**: `--brand-primary`, `--brand-secondary`, `--brand-accent`

## 📁 Estrutura do Projeto
```
fluxus_optimized/
├── public/                 # Arquivos públicos
│   ├── css/
│   │   ├── style.css      # CSS principal otimizado com dark mode completo
│   │   └── login.css      # CSS específico para login
│   ├── js/
│   │   ├── main.js        # JavaScript principal com sistema de temas
│   │   └── login.js       # JavaScript para página de login
│   ├── img/               # Imagens do projeto
│   ├── index.php          # Página de login (campo atualizado)
│   ├── home.php           # Página principal
│   └── home-demo.php      # Versão demo da página principal
├── includes/              # Componentes reutilizáveis
│   ├── header.php         # Cabeçalho responsivo
│   ├── cards.php          # Componente de cards 3D
│   ├── content.php        # Área de conteúdo principal
│   └── connection.php     # Configuração de conexão com banco
├── core/                  # Lógica central da aplicação
│   └── auth.php           # Sistema de autenticação
└── README.md              # Este arquivo
```

## 🎨 Como Personalizar as Cores

### Método 1: Variáveis CSS (Recomendado)
Edite o arquivo `public/css/style.css` e altere as variáveis no topo:

```css
:root {
  /* === CORES PRIMÁRIAS (FÁCIL DE PERSONALIZAR) === */
  --brand-primary: #ff5252;        /* Sua cor principal */
  --brand-secondary: #4285f4;      /* Sua cor secundária */
  --brand-accent: #d32f2f;         /* Sua cor de destaque */
}
```

### Método 2: Classes Utilitárias
Adicione uma classe ao elemento `<body>`:

```html
<body class="theme-blue">   <!-- Tema azul -->
<body class="theme-green">  <!-- Tema verde -->
<body class="theme-purple"> <!-- Tema roxo -->
<body class="theme-orange"> <!-- Tema laranja -->
```

## 🌙 Funcionalidades do Dark Mode

1. **Alternância via header**: Botão no canto superior direito
2. **Alternância via botão flutuante**: Botão lateral na página principal
3. **Persistência**: Tema salvo automaticamente no localStorage
4. **Transições suaves**: Mudanças animadas entre temas
5. **Página completa**: Afeta header, background, cards, textos e todos os elementos

## 📱 Breakpoints de Responsividade

| Dispositivo | Largura | Características |
|-------------|---------|-----------------|
| Desktop Large | 1920px+ | Cards grandes (300px), layout expandido |
| Desktop | 1024px-1920px | Cards médios (280px), layout padrão |
| Tablet | 768px-1024px | Cards médios (280px), header adaptado |
| Mobile Landscape | 600px-768px | Cards pequenos (260px), menu reorganizado |
| Mobile Portrait | 375px-600px | Cards pequenos (260px), layout mobile |
| Extra Small | < 375px | Cards extra pequenos (240px) |

## 🚀 Como Usar

### Requisitos
- PHP 8.1 ou superior
- Servidor web (Apache/Nginx) ou PHP built-in server
- MySQL (opcional, para funcionalidades completas)

### Instalação
1. Extraia os arquivos para seu servidor web
2. Configure a conexão com banco em `includes/connection.php`
3. Acesse `public/index.php` para a página de login
4. Use `public/home-demo.php` para testar sem banco de dados

### Desenvolvimento Local
```bash
cd public/
php -S localhost:8080
```

## 🛠️ Tecnologias Utilizadas
- **PHP 8.1+**: Backend e lógica de servidor
- **HTML5**: Estrutura semântica
- **CSS3**: Variáveis customizadas, Grid, Flexbox, responsividade
- **JavaScript ES6+**: Interatividade e sistema de temas
- **Font Awesome**: Ícones
- **Google Fonts**: Tipografia (Inter, Cinzel, Orbitron)

## ✨ Funcionalidades Principais

### 🔐 Sistema de Login
- Campo para "Código de Matrícula ou Professor"
- Validação em tempo real
- Animações suaves
- Design responsivo

### 🏠 Página Principal
- Header responsivo com navegação
- Sistema de carrossel 3D interativo
- Cards com efeito flip
- Background cósmico animado
- Controles de navegação

### 🎨 Sistema de Temas
- Dark mode completo
- Cores personalizáveis
- Transições suaves
- Persistência de preferências

## 🔧 Melhorias Técnicas

### Performance
- CSS otimizado e minificado
- JavaScript modular
- Carregamento rápido
- Transições com cubic-bezier otimizado

### Acessibilidade
- Foco visível para navegação por teclado
- Suporte a alto contraste
- Redução de movimento para usuários sensíveis
- ARIA labels apropriados

### Compatibilidade
- Funciona em todos os navegadores modernos
- Suporte a dispositivos touch
- Responsivo em todas as resoluções

## 📝 Changelog

### Versão 2.0 (Atual)
- ✅ Campo de login atualizado para "Código de Matrícula ou Professor"
- ✅ Dark mode completo afetando toda a página
- ✅ Responsividade avançada para todos os dispositivos
- ✅ Sistema de cores personalizáveis
- ✅ Performance otimizada
- ✅ Acessibilidade melhorada
- ✅ Código limpo e documentado

### Versão 1.0 (Original)
- Sistema básico de cards
- Dark mode apenas nos cards
- Responsividade limitada
- Cores fixas

## 🤝 Contribuição
Para contribuir com o projeto:
1. Mantenha a estrutura de pastas
2. Use as variáveis CSS existentes para cores
3. Teste em ambos os temas (claro/escuro)
4. Verifique responsividade em diferentes dispositivos
5. Documente mudanças significativas

## 📄 Licença
Este projeto é uma versão completamente otimizada do projeto original Fluxus.

---

**Desenvolvido com ❤️ para ser moderno, responsivo e altamente personalizável!**
