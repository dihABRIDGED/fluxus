-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 24-Ago-2025 às 17:19
-- Versão do servidor: 10.4.10-MariaDB
-- versão do PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `fluxusdb`
--
CREATE DATABASE IF NOT EXISTS `fluxusdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fluxusdb`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `atividade`
--

DROP TABLE IF EXISTS `atividade`;
CREATE TABLE IF NOT EXISTS `atividade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `turma_id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text DEFAULT NULL,
  `data_atividade` date NOT NULL,
  `tipo` varchar(50) NOT NULL DEFAULT 'atividade',
  `criado_por` int(11) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `turma_id` (`turma_id`),
  KEY `criado_por` (`criado_por`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `aula`
--

DROP TABLE IF EXISTS `aula`;
CREATE TABLE IF NOT EXISTS `aula` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `turma_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `conteudo` text DEFAULT NULL,
  `criado_por` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `turma_id` (`turma_id`),
  KEY `criado_por` (`criado_por`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina`
--

DROP TABLE IF EXISTS `disciplina`;
CREATE TABLE IF NOT EXISTS `disciplina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `coordenador_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `coordenador_id` (`coordenador_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `frequencia`
--

DROP TABLE IF EXISTS `frequencia`;
CREATE TABLE IF NOT EXISTS `frequencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aula_id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `presente` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aula_id` (`aula_id`,`aluno_id`),
  KEY `aluno_id` (`aluno_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `matricula`
--

DROP TABLE IF EXISTS `matricula`;
CREATE TABLE IF NOT EXISTS `matricula` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aluno_id` int(11) NOT NULL,
  `turma_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aluno_id` (`aluno_id`,`turma_id`),
  KEY `turma_id` (`turma_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbusuarios`
--

DROP TABLE IF EXISTS `tbusuarios`;
CREATE TABLE IF NOT EXISTS `tbusuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomeUsuario` varchar(60) NOT NULL,
  `codigoUsuario` int(10) NOT NULL,
  `senhaUsuario` varchar(32) NOT NULL,
  `nivelUsuario` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbusuarios`
--

INSERT INTO `tbusuarios` (`id`, `nomeUsuario`, `codigoUsuario`, `senhaUsuario`, `nivelUsuario`) VALUES
(2, 'testador', 2025, '54321', 'adm'),
(1, 'profesora joelma maria', 2213, '12345', 'professor');

-- --------------------------------------------------------

--
-- Estrutura da tabela `turma`
--

DROP TABLE IF EXISTS `turma`;
CREATE TABLE IF NOT EXISTS `turma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disciplina_id` int(11) NOT NULL,
  `professor_id` int(11) NOT NULL,
  `semestre` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `disciplina_id` (`disciplina_id`),
  KEY `professor_id` (`professor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tipo` enum('aluno','professor','coordenador') NOT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `email`, `tipo`, `login`, `senha`, `ativo`) VALUES
(1, 'Dr. Severino Cachaceiro', 'severino.cachaceiro@fluxus.edu', 'coordenador', 'cachaceiro', '123456', 1),
(2, 'Profa. Clotilde Rabugenta', 'clotilde.rabugenta@fluxus.edu', 'coordenador', 'rabugenta', '123456', 1),
(3, 'Prof. Astolfo Pimentel', 'astolfo.pimentel@fluxus.edu', 'professor', 'astolfo', '123456', 1),
(4, 'Profa. Berenice Trambolho', 'berenice.trambolho@fluxus.edu', 'professor', 'berenice', '123456', 1),
(5, 'Prof. Crispim Ventania', 'crispim.ventania@fluxus.edu', 'professor', 'crispim', '123456', 1),
(6, 'Profa. Doralice Fuzarca', 'doralice.fuzarca@fluxus.edu', 'professor', 'doralice', '123456', 1),
(7, 'Prof. Evaristo Bambuzal', 'evaristo.bambuzal@fluxus.edu', 'professor', 'evaristo', '123456', 1),
(8, 'Adamastor Bocó', 'adamastor.boco@estudante.fluxus.edu', 'aluno', 'adamastor', '123456', 1),
(9, 'Bernadete Xaropinho', 'bernadete.xaropinho@estudante.fluxus.edu', 'aluno', 'bernadete', '123456', 1),
(10, 'Clodoaldo Pé-de-Chinelo', 'clodoaldo.pe@estudante.fluxus.edu', 'aluno', 'clodoaldo', '123456', 1),
(11, 'Deusimar Trovoada', 'deusimar.trovoada@estudante.fluxus.edu', 'aluno', 'deusimar', '123456', 1),
(12, 'Eufrásia Catapimbas', 'eufrasia.catapimbas@estudante.fluxus.edu', 'aluno', 'eufrasia', '123456', 1),
(13, 'Florisbela Nhonhô', 'florisbela.nhonho@estudante.fluxus.edu', 'aluno', 'florisbela', '123456', 1),
(14, 'Gumercindo Pataquada', 'gumercindo.pataquada@estudante.fluxus.edu', 'aluno', 'gumercindo', '123456', 1),
(15, 'Hermenegilda Fuzuê', 'hermenegilda.fuzue@estudante.fluxus.edu', 'aluno', 'hermenegilda', '123456', 1),
(16, 'Inocêncio Tramela', 'inocencio.tramela@estudante.fluxus.edu', 'aluno', 'inocencio', '123456', 1),
(17, 'Jandira Xibungo', 'jandira.xibungo@estudante.fluxus.edu', 'aluno', 'jandira', '123456', 1),
(18, 'Kleber Zoeira', 'kleber.zoeira@estudante.fluxus.edu', 'aluno', 'kleber', '123456', 1),
(19, 'Lindaura Patacoada', 'lindaura.patacoada@estudante.fluxus.edu', 'aluno', 'lindaura', '123456', 1),
(20, 'Manoel Trapalhão', 'manoel.trapalhao@estudante.fluxus.edu', 'aluno', 'manoel', '123456', 1),
(21, 'Norberta Chilique', 'norberta.chilique@estudante.fluxus.edu', 'aluno', 'norberta', '123456', 1),
(22, 'Osvaldo Patuscada', 'osvaldo.patuscada@estudante.fluxus.edu', 'aluno', 'osvaldo', '123456', 1),
(23, 'Petronila Xaropada', 'petronila.xaropada@estudante.fluxus.edu', 'aluno', 'petronila', '123456', 1),
(24, 'Quintino Bamboleio', 'quintino.bamboleio@estudante.fluxus.edu', 'aluno', 'quintino', '123456', 1),
(25, 'Raimunda Fuzarca', 'raimunda.fuzarca@estudante.fluxus.edu', 'aluno', 'raimunda', '123456', 1),
(26, 'Sebastião Pataquada', 'sebastiao.pataquada@estudante.fluxus.edu', 'aluno', 'sebastiao', '123456', 1),
(27, 'Terezinha Xibungo', 'terezinha.xibungo@estudante.fluxus.edu', 'aluno', 'terezinha', '123456', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
