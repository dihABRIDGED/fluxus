<?php
/**
 * Header and Navigation Bar
 * Fluxus Project - Optimized Version
 */

// Ensure session is started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$user_type = $_SESSION["user_type"] ?? "";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fluxus - Sistema de Gestão</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="header">
        <div class="logo-container">
            <div class="logo-image">
                <img src="img/logo.png" alt="Logo Fluxus">
            </div>
            <div class="logo-text">FLUXUS</div>
        </div>
        
        <nav class="nav-menu">
            <a href="home.php" class="nav-link">
                <i class="fas fa-home"></i>
                <span>Home</span>
            </a>
            <?php if ($user_type === 'aluno'): ?>
                <a href="#" class="nav-link">
                    <i class="fas fa-chart-line"></i>
                    <span>Minhas Frequências</span>
                </a>
                <a href="cronograma_aluno.php" class="nav-link">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Meu Cronograma</span>
                </a>
                <a href="#" class="nav-link">
                    <i class="fas fa-book"></i>
                    <span>Minhas Disciplinas</span>
                </a>
            <?php elseif ($user_type === 'professor'): ?>
                <a href="chamada.php" class="nav-link">
                    <i class="fas fa-user-check"></i>
                    <span>Fazer Chamada</span>
                </a>
                <a href="agendamento.php" class="nav-link">
                    <i class="fas fa-calendar-plus"></i>
                    <span>Agendar Atividade</span>
                </a>
                <a href="minhas_turmas.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span>Minhas Turmas</span>
                </a>
            <?php elseif ($user_type === 'coordenador'): ?>
                <a href="gerenciar_usuarios.php" class="nav-link">
                    <i class="fas fa-users-cog"></i>
                    <span>Gerenciar Usuários</span>
                </a>
                <a href="gerenciar_disciplinas.php" class="nav-link">
                    <i class="fas fa-book-open"></i>
                    <span>Gerenciar Disciplinas</span>
                </a>
                <a href="relatorios.php" class="nav-link">
                    <i class="fas fa-chart-pie"></i>
                    <span>Relatórios</span>
                </a>
            <?php endif; ?>
            <a href="#" class="nav-link">
                <i class="fas fa-question-circle"></i>
                <span>Dúvidas</span>
            </a>
            <button class="theme-toggle" onclick="toggleTheme()" aria-label="Alternar tema">
                <i class="fas fa-moon" id="theme-icon"></i>
            </button>
            <a href="../core/logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Sair</span>
            </a>
        </nav>
    </header>
    
    <main class="main-content">



