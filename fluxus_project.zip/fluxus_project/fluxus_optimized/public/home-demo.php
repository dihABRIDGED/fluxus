<?php
/**
 * Home page - Demo Version
 * Fluxus Project - Optimized Version
 */
?>

<?php include_once '../includes/header.php'; ?>

<div class="theme-toggle-container">
    <button class="theme-toggle-btn" onclick="toggleTheme()" aria-label="Alternar tema">
        <img src="img/lamp.png" alt="Alternar tema" class="lamp-icon">
    </button>
</div>

<?php include_once '../includes/content.php'; ?>

</main>

<script src="js/main.js"></script>
</body>
</html>

