/**
 * Fluxus - Login Animation Script
 * Optimized Version
 */

// ===== LOGIN ANIMATION SYSTEM =====
class LoginAnimationManager {
  constructor() {
    this.container = document.querySelector('.container');
    this.spanCount = 50;
    this.init();
  }

  init() {
    if (!this.container) return;
    
    this.createAnimationElements();
    this.addFormEnhancements();
  }

  createAnimationElements() {
    // Clear existing spans
    this.container.innerHTML = '';
    
    // Create animation spans
    for (let i = 0; i < this.spanCount; i++) {
      const span = document.createElement('span');
      span.style.setProperty('--i', i);
      span.setAttribute('aria-hidden', 'true'); // Accessibility
      this.container.appendChild(span);
    }
  }

  addFormEnhancements() {
    const form = document.querySelector('.login-box form');
    const inputs = document.querySelectorAll('.input-box input');
    const submitBtn = document.querySelector('.btn');

    if (form) {
      // Add form submission handling
      form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }

    // Add input validation and effects
    inputs.forEach(input => {
      input.addEventListener('focus', () => this.handleInputFocus(input));
      input.addEventListener('blur', () => this.handleInputBlur(input));
      input.addEventListener('input', () => this.handleInputChange(input));
    });

    // Add button effects
    if (submitBtn) {
      submitBtn.addEventListener('mousedown', () => this.handleButtonPress(submitBtn));
      submitBtn.addEventListener('mouseup', () => this.handleButtonRelease(submitBtn));
    }
  }

  handleFormSubmit(e) {
    const submitBtn = document.querySelector('.btn');
    if (submitBtn) {
      submitBtn.textContent = 'Entrando...';
      submitBtn.disabled = true;
      
      // Add loading animation
      submitBtn.style.background = 'linear-gradient(90deg, #d32f2f, #b71c1c, #d32f2f)';
      submitBtn.style.backgroundSize = '200% 100%';
      submitBtn.style.animation = 'loading 1.5s ease-in-out infinite';
    }
  }

  handleInputFocus(input) {
    const inputBox = input.closest('.input-box');
    if (inputBox) {
      inputBox.classList.add('focused');
    }
  }

  handleInputBlur(input) {
    const inputBox = input.closest('.input-box');
    if (inputBox && !input.value) {
      inputBox.classList.remove('focused');
    }
  }

  handleInputChange(input) {
    const inputBox = input.closest('.input-box');
    if (inputBox) {
      if (input.value) {
        inputBox.classList.add('has-value');
      } else {
        inputBox.classList.remove('has-value');
      }
    }
    
    // Real-time validation
    this.validateInput(input);
  }

  validateInput(input) {
    const inputBox = input.closest('.input-box');
    if (!inputBox) return;

    // Remove previous error states
    inputBox.classList.remove('error', 'success');

    if (input.type === 'email' || input.name === 'login') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (input.value && !emailRegex.test(input.value)) {
        inputBox.classList.add('error');
      } else if (input.value) {
        inputBox.classList.add('success');
      }
    }

    if (input.type === 'password') {
      if (input.value && input.value.length < 6) {
        inputBox.classList.add('error');
      } else if (input.value && input.value.length >= 6) {
        inputBox.classList.add('success');
      }
    }
  }

  handleButtonPress(button) {
    button.style.transform = 'translateY(2px)';
  }

  handleButtonRelease(button) {
    button.style.transform = 'translateY(-2px)';
  }
}

// ===== UTILITY FUNCTIONS =====
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  
  // Style the notification
  Object.assign(notification.style, {
    position: 'fixed',
    top: '20px',
    right: '20px',
    padding: '15px 20px',
    borderRadius: '8px',
    color: 'white',
    fontWeight: '600',
    zIndex: '10000',
    transform: 'translateX(100%)',
    transition: 'transform 0.3s ease',
    maxWidth: '300px'
  });

  // Set background color based on type
  const colors = {
    success: '#4caf50',
    error: '#f44336',
    warning: '#ff9800',
    info: '#2196f3'
  };
  notification.style.backgroundColor = colors[type] || colors.info;

  document.body.appendChild(notification);

  // Animate in
  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 100);

  // Remove after 5 seconds
  setTimeout(() => {
    notification.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 5000);
}

// ===== KEYBOARD SHORTCUTS =====
function addKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Enter to submit form
    if (e.key === 'Enter' && !e.shiftKey) {
      const form = document.querySelector('.login-box form');
      const activeElement = document.activeElement;
      
      if (activeElement && activeElement.tagName === 'INPUT') {
        const inputs = Array.from(form.querySelectorAll('input'));
        const currentIndex = inputs.indexOf(activeElement);
        
        if (currentIndex < inputs.length - 1) {
          e.preventDefault();
          inputs[currentIndex + 1].focus();
        }
      }
    }
    
    // Escape to clear form
    if (e.key === 'Escape') {
      const inputs = document.querySelectorAll('.input-box input');
      inputs.forEach(input => {
        input.value = '';
        input.blur();
        const inputBox = input.closest('.input-box');
        if (inputBox) {
          inputBox.classList.remove('focused', 'has-value', 'error', 'success');
        }
      });
    }
  });
}

// ===== PERFORMANCE OPTIMIZATIONS =====
function optimizeAnimations() {
  // Reduce animations on low-end devices
  if (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) {
    document.documentElement.style.setProperty('--animation-duration', '6s');
  }
  
  // Pause animations when tab is not visible
  document.addEventListener('visibilitychange', () => {
    const container = document.querySelector('.container');
    if (container) {
      if (document.hidden) {
        container.style.animationPlayState = 'paused';
      } else {
        container.style.animationPlayState = 'running';
      }
    }
  });
}

// ===== ACCESSIBILITY ENHANCEMENTS =====
function addAccessibilityFeatures() {
  // Add ARIA labels
  const form = document.querySelector('.login-box form');
  if (form) {
    form.setAttribute('aria-label', 'Formulário de login');
  }

  const inputs = document.querySelectorAll('.input-box input');
  inputs.forEach(input => {
    const label = input.nextElementSibling;
    if (label && label.tagName === 'LABEL') {
      const id = input.name + '-input';
      input.id = id;
      label.setAttribute('for', id);
    }
  });

  // Add focus indicators for keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      document.body.classList.add('keyboard-navigation');
    }
  });

  document.addEventListener('mousedown', () => {
    document.body.classList.remove('keyboard-navigation');
  });
}

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
  // Initialize login animation manager
  window.loginAnimationManager = new LoginAnimationManager();
  
  // Add enhancements
  addKeyboardShortcuts();
  optimizeAnimations();
  addAccessibilityFeatures();
  
  // Add loading state management
  const form = document.querySelector('.login-box form');
  if (form) {
    form.addEventListener('submit', function() {
      // This will be handled by the LoginAnimationManager
      setTimeout(() => {
        showNotification('Processando login...', 'info');
      }, 100);
    });
  }
  
  // Add welcome animation
  const loginBox = document.querySelector('.login-box');
  if (loginBox) {
    loginBox.style.opacity = '0';
    loginBox.style.transform = 'translateY(30px)';
    
    setTimeout(() => {
      loginBox.style.transition = 'all 0.8s ease-out';
      loginBox.style.opacity = '1';
      loginBox.style.transform = 'translateY(0)';
    }, 500);
  }
});

// ===== CSS ANIMATIONS (injected via JavaScript) =====
const style = document.createElement('style');
style.textContent = `
  @keyframes loading {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }
  
  .input-box.success input {
    border-color: #4caf50 !important;
    box-shadow: 0 0 10px rgba(76, 175, 80, 0.3) !important;
  }
  
  .input-box.error input {
    border-color: #f44336 !important;
    box-shadow: 0 0 10px rgba(244, 67, 54, 0.3) !important;
  }
  
  .keyboard-navigation *:focus {
    outline: 2px solid #d32f2f !important;
    outline-offset: 2px !important;
  }
`;
document.head.appendChild(style);

