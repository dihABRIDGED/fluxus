<?php
/**
 * Authentication handler
 * Fluxus Project - Optimized Version
 */

require_once '../includes/connection.php';

// Start session for better security
session_start();

// Validate POST data
if (!isset($_POST['login']) || !isset($_POST['senha'])) {
    header('Location: ../public/index.php?error=missing_data');
    exit();
}

$login = $_POST['login'];
$senha = $_POST['senha'];

// Use prepared statements for better security
$stmt = $con->prepare("SELECT * FROM Usuario WHERE login = :login AND senha = :senha");
$stmt->bindParam(':login', $login);
$stmt->bindParam(':senha', $senha);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    // Store user data in session
    $_SESSION["user_id"] = $user["id"];
    $_SESSION["user_login"] = $user["login"];
    $_SESSION["user_type"] = $user["tipo"];
    $_SESSION['logged_in'] = true;
    
    echo "<script language='javascript' type='text/javascript'>
        alert('Você está logado!');
        window.location.href='../public/home.php';
    </script>";
} else {
    echo "<script language='javascript' type='text/javascript'>
        alert('Usuário inexistente ou senha incorreta');
        window.location.href='../public/index.php';
    </script>";
}

$con = null;
?>

