# Fluxus - Sistema de Gestão Educacional

## Visão Geral
O Fluxus é um sistema de gestão educacional desenvolvido em PHP que permite o gerenciamento de usuários, disciplinas, turmas, aulas e atividades acadêmicas. O sistema possui três tipos de usuários com funcionalidades específicas: Alunos, Professores e Coordenadores.

## Estrutura do Banco de Dados

### Tabelas Principais
- **Usuario**: Armazena informações dos usuários (alunos, professores, coordenadores)
- **Disciplina**: Disciplinas oferecidas pela instituição
- **Turma**: Turmas específicas de disciplinas por semestre
- **Matricula**: Relacionamento entre alunos e turmas
- **Aula**: Registro de aulas ministradas
- **Frequencia**: Controle de presença dos alunos
- **Atividade**: Atividades agendadas pelos professores

## Funcionalidades por Tipo de Usuário

### Aluno
- **Navegação específica**: Links para frequências, cronograma e disciplinas
- **Cronograma pessoal**: Visualização de atividades agendadas com indicadores de urgência
- **Histórico de atividades**: Visualização de atividades passadas

### Professor
- **Navegação específica**: Links para chamada, agendamento e turmas
- **Fazer chamada**: Sistema completo para registrar aulas e presença dos alunos
- **Agendar atividades**: Criação de provas, trabalhos, seminários e outras atividades
- **Gerenciar turmas**: Visualização das turmas sob sua responsabilidade

### Coordenador
- **Navegação específica**: Links para gerenciamento de usuários, disciplinas e relatórios
- **Gerenciar usuários**: CRUD completo de usuários com interface intuitiva
- **Controle de acesso**: Ativação/desativação de usuários
- **Visão geral do sistema**: Acesso a relatórios e estatísticas

## Arquivos Principais

### Core
- `core/auth.php`: Sistema de autenticação com suporte a tipos de usuário
- `core/logout.php`: Encerramento de sessão

### Includes
- `includes/connection.php`: Conexão com banco PostgreSQL usando PDO
- `includes/header.php`: Cabeçalho dinâmico com navegação baseada no tipo de usuário

### Páginas Públicas
- `public/index.php`: Página de login
- `public/home.php`: Dashboard principal
- `public/chamada.php`: Sistema de chamada para professores
- `public/agendamento.php`: Agendamento de atividades para professores
- `public/cronograma_aluno.php`: Cronograma personalizado para alunos
- `public/gerenciar_usuarios.php`: Gerenciamento de usuários para coordenadores

### Banco de Dados
- `database_schema.sql`: Estrutura completa do banco de dados
- `sample_data.sql`: Dados de teste com usuários engraçados

## Instalação e Configuração

### Pré-requisitos
- Servidor web (Apache/Nginx)
- PHP 7.4 ou superior
- PostgreSQL 12 ou superior
- Extensão PDO para PostgreSQL

### Passos de Instalação

1. **Configurar o banco de dados**:
   ```sql
   -- Criar banco de dados
   CREATE DATABASE fluxusdb;
   
   -- Executar o schema
   \i database_schema.sql
   
   -- Inserir dados de teste (opcional)
   \i sample_data.sql
   ```

2. **Configurar conexão**:
   Edite o arquivo `includes/connection.php` com suas credenciais:
   ```php
   $host = 'localhost';
   $dbname = 'fluxusdb';
   $user = 'seu_usuario';
   $password = 'sua_senha';
   ```

3. **Configurar servidor web**:
   - Aponte o DocumentRoot para a pasta `public/`
   - Certifique-se de que o PHP está configurado corretamente

## Usuários de Teste

### Coordenadores
- **Login**: `cachaceiro` | **Senha**: `123456` | **Nome**: Dr. Severino Cachaceiro
- **Login**: `rabugenta` | **Senha**: `123456` | **Nome**: Profa. Clotilde Rabugenta

### Professores
- **Login**: `astolfo` | **Senha**: `123456` | **Nome**: Prof. Astolfo Pimentel
- **Login**: `berenice` | **Senha**: `123456` | **Nome**: Profa. Berenice Trambolho
- **Login**: `crispim` | **Senha**: `123456` | **Nome**: Prof. Crispim Ventania

### Alunos
- **Login**: `adamastor` | **Senha**: `123456` | **Nome**: Adamastor Bocó
- **Login**: `bernadete` | **Senha**: `123456` | **Nome**: Bernadete Xaropinho
- **Login**: `clodoaldo` | **Senha**: `123456` | **Nome**: Clodoaldo Pé-de-Chinelo

## Funcionalidades Implementadas

### Sistema de Chamada
- Seleção de turma
- Registro de conteúdo da aula
- Lista de presença interativa
- Botões para marcar/desmarcar todos

### Agendamento de Atividades
- Criação de diferentes tipos de atividades (prova, trabalho, seminário, etc.)
- Interface intuitiva com formulários validados
- Visualização de atividades agendadas

### Cronograma do Aluno
- Separação entre atividades futuras e passadas
- Indicadores visuais de urgência
- Informações detalhadas sobre cada atividade

### Gerenciamento de Usuários
- Interface com abas por tipo de usuário
- CRUD completo com modais
- Controle de status ativo/inativo
- Validações de segurança

## Segurança

- Uso de prepared statements para prevenir SQL injection
- Validação de tipos de usuário em todas as páginas
- Controle de sessão adequado
- Sanitização de dados de entrada

## Tecnologias Utilizadas

- **Backend**: PHP 7.4+ com PDO
- **Banco de Dados**: PostgreSQL
- **Frontend**: HTML5, CSS3, JavaScript
- **Frameworks CSS**: Font Awesome para ícones
- **Fontes**: Google Fonts (Cinzel)

## Estrutura de Arquivos

```
fluxus_optimized/
├── core/
│   ├── auth.php
│   └── logout.php
├── includes/
│   ├── connection.php
│   ├── header.php
│   ├── content.php
│   └── cards.php
├── public/
│   ├── css/
│   │   ├── style.css
│   │   └── login.css
│   ├── js/
│   │   ├── main.js
│   │   └── login.js
│   ├── img/
│   │   ├── logo.png
│   │   └── lamp.png
│   ├── index.php
│   ├── home.php
│   ├── chamada.php
│   ├── agendamento.php
│   ├── cronograma_aluno.php
│   └── gerenciar_usuarios.php
├── database_schema.sql
├── sample_data.sql
└── README_UPDATED.md
```

## Próximas Melhorias

- Sistema de notificações
- Relatórios avançados para coordenadores
- Dashboard com gráficos e estatísticas
- Sistema de mensagens entre usuários
- Exportação de dados em PDF/Excel
- API REST para integração com outros sistemas

## Suporte

Para dúvidas ou problemas, consulte a documentação ou entre em contato com a equipe de desenvolvimento.

