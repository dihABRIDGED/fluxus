-- Dados de teste para o sistema Fluxus
-- Usuários com nomes engraçados para testes

-- Inserir usuários de teste
INSERT INTO Usuario (nome, email, tipo, login, senha, ativo) VALUES
-- Coordenadores
('Dr. Severino Cachaceiro', 'severino.cachaceiro@fluxus.edu', 'coordenador', 'cachaceiro', '123456', true),
('Profa. Clotilde Rabugenta', 'clotilde.rabugenta@fluxus.edu', 'coordenador', 'rabugenta', '123456', true),

-- Professores
('Prof. Astolfo Pimentel', 'astolfo.pimentel@fluxus.edu', 'professor', 'astolfo', '123456', true),
('Profa. Berenice Trambolho', 'berenice.trambolho@fluxus.edu', 'professor', 'berenice', '123456', true),
('Prof. Crispim Ventania', 'crispim.ventania@fluxus.edu', 'professor', 'crispim', '123456', true),
('Profa. Doralice Fuzarca', 'doralice.fuzarca@fluxus.edu', 'professor', 'doralice', '123456', true),
('Prof. Evaristo Bambuzal', 'evaristo.bambuzal@fluxus.edu', 'professor', 'evaristo', '123456', true),

-- Alunos
('Adamastor Bocó', 'adamastor.boco@estudante.fluxus.edu', 'aluno', 'adamastor', '123456', true),
('Bernadete Xaropinho', 'bernadete.xaropinho@estudante.fluxus.edu', 'aluno', 'bernadete', '123456', true),
('Clodoaldo Pé-de-Chinelo', 'clodoaldo.pe@estudante.fluxus.edu', 'aluno', 'clodoaldo', '123456', true),
('Deusimar Trovoada', 'deusimar.trovoada@estudante.fluxus.edu', 'aluno', 'deusimar', '123456', true),
('Eufrásia Catapimbas', 'eufrasia.catapimbas@estudante.fluxus.edu', 'aluno', 'eufrasia', '123456', true),
('Florisbela Nhonhô', 'florisbela.nhonho@estudante.fluxus.edu', 'aluno', 'florisbela', '123456', true),
('Gumercindo Pataquada', 'gumercindo.pataquada@estudante.fluxus.edu', 'aluno', 'gumercindo', '123456', true),
('Hermenegilda Fuzuê', 'hermenegilda.fuzue@estudante.fluxus.edu', 'aluno', 'hermenegilda', '123456', true),
('Inocêncio Tramela', 'inocencio.tramela@estudante.fluxus.edu', 'aluno', 'inocencio', '123456', true),
('Jandira Xibungo', 'jandira.xibungo@estudante.fluxus.edu', 'aluno', 'jandira', '123456', true),
('Kleber Zoeira', 'kleber.zoeira@estudante.fluxus.edu', 'aluno', 'kleber', '123456', true),
('Lindaura Patacoada', 'lindaura.patacoada@estudante.fluxus.edu', 'aluno', 'lindaura', '123456', true),
('Manoel Trapalhão', 'manoel.trapalhao@estudante.fluxus.edu', 'aluno', 'manoel', '123456', true),
('Norberta Chilique', 'norberta.chilique@estudante.fluxus.edu', 'aluno', 'norberta', '123456', true),
('Osvaldo Patuscada', 'osvaldo.patuscada@estudante.fluxus.edu', 'aluno', 'osvaldo', '123456', true),
('Petronila Xaropada', 'petronila.xaropada@estudante.fluxus.edu', 'aluno', 'petronila', '123456', true),
('Quintino Bamboleio', 'quintino.bamboleio@estudante.fluxus.edu', 'aluno', 'quintino', '123456', true),
('Raimunda Fuzarca', 'raimunda.fuzarca@estudante.fluxus.edu', 'aluno', 'raimunda', '123456', true),
('Sebastião Pataquada', 'sebastiao.pataquada@estudante.fluxus.edu', 'aluno', 'sebastiao', '123456', true),
('Terezinha Xibungo', 'terezinha.xibungo@estudante.fluxus.edu', 'aluno', 'terezinha', '123456', true);

-- Inserir disciplinas
INSERT INTO Disciplina (nome, coordenador_id) VALUES
('Matemática Aplicada ao Cotidiano', 1),
('Física Quântica para Iniciantes', 2),
('História da Humanidade em 50 Minutos', 1),
('Química Orgânica e Inorgânica', 2),
('Literatura Brasileira Contemporânea', 1),
('Programação para Leigos', 2),
('Filosofia da Vida Moderna', 1),
('Biologia Molecular Básica', 2);

-- Inserir turmas
INSERT INTO Turma (disciplina_id, professor_id, semestre) VALUES
(1, 3, '2024.1'), -- Matemática com Prof. Astolfo
(2, 4, '2024.1'), -- Física com Profa. Berenice
(3, 5, '2024.1'), -- História com Prof. Crispim
(4, 6, '2024.1'), -- Química com Profa. Doralice
(5, 7, '2024.1'), -- Literatura com Prof. Evaristo
(6, 3, '2024.1'), -- Programação com Prof. Astolfo
(7, 4, '2024.1'), -- Filosofia com Profa. Berenice
(8, 5, '2024.1'); -- Biologia com Prof. Crispim

-- Inserir matrículas (distribuindo alunos nas turmas)
INSERT INTO Matricula (aluno_id, turma_id) VALUES
-- Turma 1 (Matemática)
(8, 1), (9, 1), (10, 1), (11, 1), (12, 1),
-- Turma 2 (Física)
(13, 2), (14, 2), (15, 2), (16, 2), (17, 2),
-- Turma 3 (História)
(18, 3), (19, 3), (20, 3), (21, 3), (22, 3),
-- Turma 4 (Química)
(23, 4), (24, 4), (25, 4), (26, 4), (27, 4),
-- Turma 5 (Literatura)
(8, 5), (10, 5), (12, 5), (14, 5), (16, 5),
-- Turma 6 (Programação)
(9, 6), (11, 6), (13, 6), (15, 6), (17, 6),
-- Turma 7 (Filosofia)
(18, 7), (20, 7), (22, 7), (24, 7), (26, 7),
-- Turma 8 (Biologia)
(19, 8), (21, 8), (23, 8), (25, 8), (27, 8);

-- Inserir algumas aulas de exemplo
INSERT INTO Aula (turma_id, data, conteudo, criado_por) VALUES
(1, '2024-01-15', 'Introdução à Matemática Aplicada - Conceitos básicos e aplicações no dia a dia', 3),
(1, '2024-01-22', 'Operações básicas e resolução de problemas práticos', 3),
(2, '2024-01-16', 'Fundamentos da Física Quântica - O que é e por que estudar', 4),
(3, '2024-01-17', 'Pré-história: Como tudo começou em apenas 10 minutos', 5),
(4, '2024-01-18', 'Tabela Periódica: Seus elementos e suas personalidades', 6),
(5, '2024-01-19', 'Literatura Brasileira: De Machado de Assis aos memes', 7);

-- Inserir frequências de exemplo
INSERT INTO Frequencia (aula_id, aluno_id, presente) VALUES
-- Aula 1 (Matemática)
(1, 8, true), (1, 9, true), (1, 10, false), (1, 11, true), (1, 12, true),
-- Aula 2 (Matemática)
(2, 8, false), (2, 9, true), (2, 10, true), (2, 11, true), (2, 12, false),
-- Aula 3 (Física)
(3, 13, true), (3, 14, true), (3, 15, true), (3, 16, false), (3, 17, true),
-- Aula 4 (História)
(4, 18, true), (4, 19, false), (4, 20, true), (4, 21, true), (4, 22, true),
-- Aula 5 (Química)
(5, 23, true), (5, 24, true), (5, 25, true), (5, 26, true), (5, 27, false),
-- Aula 6 (Literatura)
(6, 8, true), (6, 10, false), (6, 12, true), (6, 14, true), (6, 16, true);

-- Inserir atividades de exemplo
INSERT INTO Atividade (turma_id, titulo, descricao, data_atividade, tipo, criado_por) VALUES
(1, 'Prova de Matemática Básica', 'Avaliação sobre operações básicas e resolução de problemas do cotidiano', '2024-02-15', 'prova', 3),
(1, 'Trabalho sobre Aplicações Matemáticas', 'Pesquisa sobre como a matemática é usada em diferentes profissões', '2024-02-28', 'trabalho', 3),
(2, 'Seminário: Gato de Schrödinger', 'Apresentação em grupo sobre o famoso experimento mental', '2024-02-20', 'seminario', 4),
(3, 'Exercícios sobre Pré-História', 'Lista de exercícios sobre os primórdios da humanidade', '2024-02-10', 'exercicio', 5),
(4, 'Projeto: Elemento Químico Favorito', 'Criar uma apresentação criativa sobre um elemento da tabela periódica', '2024-03-01', 'projeto', 6),
(5, 'Prova de Literatura Brasileira', 'Avaliação sobre autores e obras estudadas', '2024-02-25', 'prova', 7),
(6, 'Trabalho: Meu Primeiro Programa', 'Desenvolver um programa simples em Python', '2024-03-05', 'trabalho', 3),
(7, 'Ensaio Filosófico', 'Reflexão escrita sobre um tema filosófico atual', '2024-02-22', 'atividade', 4);

