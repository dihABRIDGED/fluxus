# Fluxus + TCC 2.0 - Projeto Integrado 🚀

## Visão Geral
Este projeto combina **todas as funcionalidades avançadas do Fluxus Project** com o **estilo visual exato do TCC 2.0**, criando uma solução educacional completa e visualmente consistente.

## ✨ O Que Foi Integrado

### 🎨 Estilo Visual (TCC 2.0)
- **Cores**: Esquema vermelho (#c62828) como cor principal
- **Layout**: Header com navegação horizontal
- **Tipografia**: Font Inter para consistência
- **Background**: Imagem de fundo específica do TCC 2.0
- **Formulários**: Estilo glassmorphism com backdrop-filter
- **Carrossel**: Design com blocos coloridos e ícones FontAwesome

### 🔧 Funcionalidades (Fluxus Project)
- **Sistema de autenticação** completo com sessões PHP
- **Gerenciamento de usuários** (alunos, professores, coordenadores)
- **Sistema de chamada** e controle de frequência
- **Cronograma interativo** com tarefas
- **Agendamentos** e notificações
- **Dark mode** com persistência no localStorage
- **Responsividade** avançada para todos os dispositivos

## 📁 Estrutura do Projeto Integrado

```
fluxus_tcc_integrated/
├── public/                          # Arquivos públicos
│   ├── css/
│   │   ├── tcc_style.css           # CSS integrado (TCC 2.0 + Fluxus)
│   │   ├── style.css               # CSS original do Fluxus
│   │   └── login.css               # CSS original do login
│   ├── js/
│   │   ├── main.js                 # JavaScript principal do Fluxus
│   │   └── login.js                # JavaScript do login
│   ├── img/                        # Imagens do projeto
│   ├── index.php                   # Login integrado (TCC 2.0 + Fluxus)
│   ├── home_integrated.php         # Página principal integrada
│   ├── cronograma_integrated.php   # Cronograma integrado
│   └── [outras páginas do Fluxus] # Páginas originais mantidas
├── includes/                       # Componentes reutilizáveis
│   ├── header.php                  # Cabeçalho do Fluxus
│   ├── cards.php                   # Componente de cards 3D
│   ├── content.php                 # Área de conteúdo principal
│   └── connection.php              # Configuração de conexão com banco
├── core/                          # Lógica central da aplicação
│   ├── auth.php                   # Autenticação integrada
│   └── logout.php                 # Sistema de logout
└── README_INTEGRATION.md          # Esta documentação
```

## 🔄 Principais Integrações Realizadas

### 1. **Login Integrado** (`index.php`)
- **Visual**: Estilo TCC 2.0 com glassmorphism e background
- **Funcionalidade**: Sistema de autenticação do Fluxus
- **Novidade**: Seletor de tipo de usuário (aluno/professor/coordenador)
- **Validação**: JavaScript para verificar campos obrigatórios

### 2. **Página Principal** (`home_integrated.php`)
- **Visual**: Header e carrossel no estilo TCC 2.0
- **Funcionalidade**: Navegação e sistema de temas do Fluxus
- **Carrossel**: Auto-play + navegação manual
- **Tema**: Botão flutuante para dark/light mode

### 3. **Cronograma** (`cronograma_integrated.php`)
- **Visual**: Calendário no estilo TCC 2.0
- **Funcionalidade**: Sistema completo de tarefas do Fluxus
- **Recursos**: Adicionar/editar/excluir tarefas, visualização mensal
- **Persistência**: LocalStorage para salvar tarefas

### 4. **Autenticação** (`core/auth.php`)
- **Integração**: Validação de tipo de usuário + login/senha
- **Segurança**: Prepared statements do Fluxus
- **Redirecionamento**: Para página integrada após login

## 🎨 Características Visuais Mantidas

### Do TCC 2.0:
- ✅ Cor principal: #c62828 (vermelho)
- ✅ Header com navegação horizontal
- ✅ Background com imagem específica
- ✅ Formulários com glassmorphism
- ✅ Carrossel com blocos coloridos
- ✅ Ícones FontAwesome
- ✅ Tipografia Inter

### Do Fluxus:
- ✅ Sistema de dark mode
- ✅ Responsividade avançada
- ✅ Animações suaves
- ✅ Botão flutuante de tema
- ✅ Estrutura modular PHP

## 🚀 Como Usar

### Requisitos
- PHP 8.1 ou superior
- Servidor web (Apache/Nginx) ou PHP built-in server
- MySQL (para funcionalidades completas)

### Instalação
1. Configure a conexão com banco em `includes/connection.php`
2. Acesse `public/index.php` para fazer login
3. Use as credenciais do banco de dados configurado

### Desenvolvimento Local
```bash
cd public/
php -S localhost:8080
```

## 🔐 Sistema de Login Integrado

### Campos Obrigatórios:
1. **Tipo de usuário**: Aluno/Professor/Coordenador
2. **Login**: Código de matrícula ou usuário
3. **Senha**: Senha do usuário

### Validações:
- JavaScript: Verificação de campos vazios
- PHP: Validação contra banco de dados
- Segurança: Prepared statements

## 🌙 Sistema de Temas

### Funcionalidades:
- **Alternância**: Botão flutuante no canto inferior direito
- **Persistência**: Tema salvo no localStorage
- **Transições**: Animações suaves entre temas
- **Compatibilidade**: Funciona em todas as páginas

### Como Usar:
- Clique no ícone da lâmpada para alternar
- O tema é salvo automaticamente
- Funciona em desktop e mobile

## 📱 Responsividade

### Breakpoints:
- **Desktop**: 1024px+ (layout completo)
- **Tablet**: 768px-1024px (header adaptado)
- **Mobile**: < 768px (layout mobile)

### Adaptações:
- Header responsivo
- Carrossel adaptativo
- Formulários otimizados
- Navegação mobile-friendly

## 🔧 Funcionalidades Técnicas

### Backend (PHP):
- Sistema de sessões seguro
- Prepared statements
- Validação de dados
- Estrutura modular

### Frontend (JavaScript):
- Dark mode com localStorage
- Carrossel automático
- Validação de formulários
- Calendário interativo

### CSS:
- Variáveis customizáveis
- Flexbox e Grid
- Animações CSS3
- Media queries

## 📝 Páginas Disponíveis

### Integradas (Novo Estilo):
- ✅ `index.php` - Login integrado
- ✅ `home_integrated.php` - Página principal
- ✅ `cronograma_integrated.php` - Cronograma

### Originais (Mantidas):
- `home.php` - Página original do Fluxus
- `chamada.php` - Sistema de chamada
- `agendamento.php` - Agendamentos
- `gerenciar_usuarios.php` - Gestão de usuários
- `cronograma_aluno.php` - Cronograma original

## 🎯 Resultado Final

O projeto integrado oferece:
- **Visual**: 100% fiel ao TCC 2.0
- **Funcionalidades**: 100% do Fluxus Project
- **Responsividade**: Funciona em todos os dispositivos
- **Performance**: Otimizado e rápido
- **Usabilidade**: Interface intuitiva e moderna

## 🤝 Manutenção

### Para Personalizar Cores:
Edite as variáveis no `css/tcc_style.css`:
```css
:root {
  --brand-primary: #c62828;    /* Cor principal */
  --brand-secondary: #a32222;  /* Cor secundária */
  --brand-accent: #8c1d1d;     /* Cor de destaque */
}
```

### Para Adicionar Páginas:
1. Copie a estrutura de `home_integrated.php`
2. Mantenha o header e o sistema de temas
3. Use o CSS `tcc_style.css`

---

**✨ Projeto desenvolvido combinando o melhor dos dois mundos: funcionalidades avançadas do Fluxus com o design elegante do TCC 2.0!**

