<?php
/**
 * Página de Chamada - Professor
 * Fluxus Project - Optimized Version
 */

session_start();

// Check if user is logged in and is a professor
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'professor') {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Get professor's classes
$stmt = $con->prepare("
    SELECT t.id, d.nome as disciplina_nome, t.semestre 
    FROM Turma t 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    WHERE t.professor_id = :professor_id
");
$stmt->bindParam(':professor_id', $_SESSION['user_id']);
$stmt->execute();
$turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_POST) {
    $turma_id = $_POST['turma_id'];
    $data = $_POST['data'];
    $conteudo = $_POST['conteudo'];
    
    // Create new class
    $stmt = $con->prepare("INSERT INTO Aula (turma_id, data, conteudo, criado_por) VALUES (:turma_id, :data, :conteudo, :criado_por)");
    $stmt->bindParam(':turma_id', $turma_id);
    $stmt->bindParam(':data', $data);
    $stmt->bindParam(':conteudo', $conteudo);
    $stmt->bindParam(':criado_por', $_SESSION['user_id']);
    $stmt->execute();
    
    $aula_id = $con->lastInsertId();
    
    // Get students from this class
    $stmt = $con->prepare("
        SELECT m.aluno_id 
        FROM Matricula m 
        WHERE m.turma_id = :turma_id
    ");
    $stmt->bindParam(':turma_id', $turma_id);
    $stmt->execute();
    $alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Insert attendance records
    foreach ($alunos as $aluno) {
        $presente = isset($_POST['presente_' . $aluno['aluno_id']]) ? 1 : 0;
        $stmt = $con->prepare("INSERT INTO Frequencia (aula_id, aluno_id, presente) VALUES (:aula_id, :aluno_id, :presente)");
        $stmt->bindParam(':aula_id', $aula_id);
        $stmt->bindParam(':aluno_id', $aluno['aluno_id']);
        $stmt->bindParam(':presente', $presente);
        $stmt->execute();
    }
    
    $success_message = "Chamada realizada com sucesso!";
}

// Get selected class students if turma_id is provided
$selected_turma_id = $_GET['turma_id'] ?? null;
$alunos_turma = [];
if ($selected_turma_id) {
    $stmt = $con->prepare("
        SELECT u.id, u.nome 
        FROM Usuario u 
        JOIN Matricula m ON u.id = m.aluno_id 
        WHERE m.turma_id = :turma_id AND u.tipo = 'aluno'
        ORDER BY u.nome
    ");
    $stmt->bindParam(':turma_id', $selected_turma_id);
    $stmt->execute();
    $alunos_turma = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<?php include_once '../includes/header.php'; ?>

<div class="container">
    <h1>Fazer Chamada</h1>
    
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <div class="chamada-container">
        <div class="step-1">
            <h2>1. Selecione a Turma</h2>
            <form method="GET" action="chamada.php">
                <select name="turma_id" onchange="this.form.submit()" required>
                    <option value="">Selecione uma turma...</option>
                    <?php foreach ($turmas as $turma): ?>
                        <option value="<?php echo $turma['id']; ?>" <?php echo $selected_turma_id == $turma['id'] ? 'selected' : ''; ?>>
                            <?php echo $turma['disciplina_nome'] . ' - ' . $turma['semestre']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        
        <?php if ($selected_turma_id && !empty($alunos_turma)): ?>
        <div class="step-2">
            <h2>2. Registrar Aula e Presença</h2>
            <form method="POST" action="chamada.php">
                <input type="hidden" name="turma_id" value="<?php echo $selected_turma_id; ?>">
                
                <div class="aula-info">
                    <div class="form-group">
                        <label for="data">Data da Aula:</label>
                        <input type="date" name="data" id="data" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="conteudo">Conteúdo da Aula:</label>
                        <textarea name="conteudo" id="conteudo" rows="3" placeholder="Descreva o conteúdo abordado na aula..."></textarea>
                    </div>
                </div>
                
                <div class="lista-alunos">
                    <h3>Lista de Presença</h3>
                    <div class="alunos-grid">
                        <?php foreach ($alunos_turma as $aluno): ?>
                        <div class="aluno-item">
                            <label class="checkbox-container">
                                <input type="checkbox" name="presente_<?php echo $aluno['id']; ?>" value="1">
                                <span class="checkmark"></span>
                                <?php echo $aluno['nome']; ?>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Registrar Chamada</button>
                    <button type="button" class="btn btn-secondary" onclick="marcarTodos()">Marcar Todos</button>
                    <button type="button" class="btn btn-secondary" onclick="desmarcarTodos()">Desmarcar Todos</button>
                </div>
            </form>
        </div>
        <?php elseif ($selected_turma_id): ?>
        <div class="no-students">
            <p>Nenhum aluno encontrado nesta turma.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.chamada-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

.step-1, .step-2 {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-group input, .form-group textarea, .form-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.alunos-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 10px;
    margin-top: 15px;
}

.aluno-item {
    padding: 10px;
    border: 1px solid #eee;
    border-radius: 4px;
    background: #f9f9f9;
}

.checkbox-container {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 14px;
}

.checkbox-container input {
    margin-right: 10px;
    width: auto;
}

.form-actions {
    margin-top: 20px;
    display: flex;
    gap: 10px;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    text-decoration: none;
    display: inline-block;
}

.btn-primary {
    background: #007bff;
    color: white;
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

.alert {
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 4px;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.no-students {
    text-align: center;
    padding: 40px;
    color: #666;
}
</style>

<script>
function marcarTodos() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name^="presente_"]');
    checkboxes.forEach(checkbox => checkbox.checked = true);
}

function desmarcarTodos() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name^="presente_"]');
    checkboxes.forEach(checkbox => checkbox.checked = false);
}
</script>

</main>
</body>
</html>

<?php
$con = null;
?>

