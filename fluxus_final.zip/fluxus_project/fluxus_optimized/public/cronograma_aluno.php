<?php
/**
 * Página de Cronograma - Aluno
 * Fluxus Project - Optimized Version
 */

session_start();

// Check if user is logged in and is a student
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'aluno') {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Get student's activities
$stmt = $con->prepare("
    SELECT a.*, d.nome as disciplina_nome, t.semestre, u.nome as professor_nome
    FROM Atividade a 
    JOIN Turma t ON a.turma_id = t.id 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    JOIN Usuario u ON t.professor_id = u.id
    JOIN Matricula m ON t.id = m.turma_id
    WHERE m.aluno_id = :aluno_id 
    ORDER BY a.data_atividade ASC
");
$stmt->bindParam(':aluno_id', $_SESSION['user_id']);
$stmt->execute();
$atividades = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Separate activities by status
$atividades_futuras = [];
$atividades_passadas = [];
$hoje = date('Y-m-d');

foreach ($atividades as $atividade) {
    if ($atividade['data_atividade'] >= $hoje) {
        $atividades_futuras[] = $atividade;
    } else {
        $atividades_passadas[] = $atividade;
    }
}
?>

<?php include_once '../includes/header.php'; ?>

<div class="container">
    <h1>Meu Cronograma</h1>
    
    <div class="cronograma-container">
        <div class="atividades-section">
            <h2>Próximas Atividades</h2>
            <?php if (empty($atividades_futuras)): ?>
                <p class="no-activities">Nenhuma atividade próxima agendada.</p>
            <?php else: ?>
                <div class="atividades-list">
                    <?php foreach ($atividades_futuras as $atividade): ?>
                        <?php
                        $dias_restantes = (strtotime($atividade['data_atividade']) - strtotime($hoje)) / (60 * 60 * 24);
                        $urgencia = '';
                        if ($dias_restantes <= 1) $urgencia = 'urgente';
                        elseif ($dias_restantes <= 7) $urgencia = 'proxima';
                        ?>
                        <div class="atividade-card <?php echo $urgencia; ?>">
                            <div class="atividade-header">
                                <h3><?php echo htmlspecialchars($atividade['titulo']); ?></h3>
                                <div class="badges">
                                    <span class="tipo-badge tipo-<?php echo $atividade['tipo']; ?>">
                                        <?php echo ucfirst($atividade['tipo']); ?>
                                    </span>
                                    <?php if ($dias_restantes <= 1): ?>
                                        <span class="urgencia-badge">URGENTE</span>
                                    <?php elseif ($dias_restantes <= 7): ?>
                                        <span class="proxima-badge">PRÓXIMA</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="atividade-info">
                                <p><strong>Disciplina:</strong> <?php echo $atividade['disciplina_nome'] . ' - ' . $atividade['semestre']; ?></p>
                                <p><strong>Professor:</strong> <?php echo $atividade['professor_nome']; ?></p>
                                <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                                <p><strong>Dias restantes:</strong> <?php echo ceil($dias_restantes); ?> dia(s)</p>
                                <?php if ($atividade['descricao']): ?>
                                    <p><strong>Descrição:</strong> <?php echo htmlspecialchars($atividade['descricao']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="atividades-section">
            <h2>Atividades Passadas</h2>
            <?php if (empty($atividades_passadas)): ?>
                <p class="no-activities">Nenhuma atividade passada registrada.</p>
            <?php else: ?>
                <div class="atividades-list">
                    <?php foreach (array_slice($atividades_passadas, 0, 10) as $atividade): ?>
                        <div class="atividade-card passada">
                            <div class="atividade-header">
                                <h3><?php echo htmlspecialchars($atividade['titulo']); ?></h3>
                                <span class="tipo-badge tipo-<?php echo $atividade['tipo']; ?>">
                                    <?php echo ucfirst($atividade['tipo']); ?>
                                </span>
                            </div>
                            <div class="atividade-info">
                                <p><strong>Disciplina:</strong> <?php echo $atividade['disciplina_nome'] . ' - ' . $atividade['semestre']; ?></p>
                                <p><strong>Professor:</strong> <?php echo $atividade['professor_nome']; ?></p>
                                <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                                <?php if ($atividade['descricao']): ?>
                                    <p><strong>Descrição:</strong> <?php echo htmlspecialchars($atividade['descricao']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if (count($atividades_passadas) > 10): ?>
                    <p class="mais-atividades">Mostrando as 10 atividades mais recentes de <?php echo count($atividades_passadas); ?> total.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.cronograma-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.atividades-section {
    background: white;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.atividades-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.atividade-card {
    border: 1px solid #eee;
    border-radius: 8px;
    padding: 20px;
    background: #f8f9fa;
    transition: transform 0.2s, box-shadow 0.2s;
}

.atividade-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.atividade-card.urgente {
    border-left: 5px solid #dc3545;
    background: #fff5f5;
}

.atividade-card.proxima {
    border-left: 5px solid #ffc107;
    background: #fffbf0;
}

.atividade-card.passada {
    opacity: 0.7;
    background: #f1f3f4;
}

.atividade-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}

.atividade-header h3 {
    margin: 0;
    color: #333;
    font-size: 16px;
    flex: 1;
}

.badges {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.tipo-badge, .urgencia-badge, .proxima-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.tipo-prova { background: #dc3545; color: white; }
.tipo-trabalho { background: #28a745; color: white; }
.tipo-seminario { background: #17a2b8; color: white; }
.tipo-exercicio { background: #ffc107; color: #212529; }
.tipo-projeto { background: #6f42c1; color: white; }
.tipo-atividade { background: #6c757d; color: white; }

.urgencia-badge {
    background: #dc3545;
    color: white;
    animation: pulse 2s infinite;
}

.proxima-badge {
    background: #ffc107;
    color: #212529;
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}

.atividade-info p {
    margin: 8px 0;
    font-size: 14px;
    color: #555;
}

.no-activities {
    text-align: center;
    color: #666;
    font-style: italic;
    padding: 40px;
}

.mais-atividades {
    text-align: center;
    color: #666;
    font-style: italic;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}

@media (max-width: 768px) {
    .cronograma-container {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .badges {
        flex-direction: column;
        align-items: flex-end;
    }
}
</style>

</main>
</body>
</html>

<?php
$con = null;
?>

