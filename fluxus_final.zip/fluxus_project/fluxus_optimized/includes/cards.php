<div class="cards-section">
    <div class="carousel-container">
        <div class="carousel" id="memory-carousel">
            <!-- Card 1: First Line of Code -->
            <div class="memory-card" data-memory-id="1">
                <div class="card-inner">
                    <div class="card-front">
                        <div class="card-content">
                            <div class="memory-date">LANGUAGE: Python</div>
                            <h3>First Line of Code</h3>
                            <div class="memory-image">
                                <i class="fa-solid fa-code"></i>
                                <div class="glitch-effect"></div>
                            </div>
                            <p class="memory-preview">
                                The terminal glowed, displaying my first 'Hello, World!'...
                            </p>
                            <div class="card-glow"></div>
                        </div>
                    </div>
                    <div class="card-back">
                        <div class="card-content">
                            <h3>First Line of Code</h3>
                            <p>
                                I remember the thrill of typing my first 'Hello, World!' in
                                Python. It was simple, yet it opened a portal to endless
                                possibilities. The interpreter executed the command flawlessly,
                                and I knew this was just the beginning. I wasn't supposed to
                                understand it all at once, but somehow, I did.
                            </p>
                            <div class="memory-coordinates">
                                <span><i class="fa-solid fa-location-dot"></i> console: ~</span>
                                <span class="time-stamp"><i class="fa-regular fa-clock"></i> 09:00:00</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2: Debugging the Matrix -->
            <div class="memory-card" data-memory-id="2">
                <div class="card-inner">
                    <div class="card-front">
                        <div class="card-content">
                            <div class="memory-date">FRAMEWORK: ReactJS</div>
                            <h3>Debugging the Matrix</h3>
                            <div class="memory-image">
                                <i class="fa-solid fa-bug"></i>
                                <div class="glitch-effect"></div>
                            </div>
                            <p class="memory-preview">
                                The error messages multiplied, haunting my console...
                            </p>
                            <div class="card-glow"></div>
                        </div>
                    </div>
                    <div class="card-back">
                        <div class="card-content">
                            <h3>Debugging the Matrix</h3>
                            <p>
                                They appeared from the depths of the console, cryptic error
                                messages glowing red. Debugging a complex ReactJS component
                                felt like navigating a vast, interconnected matrix. Each fix
                                unveiled new issues. They say my code is destabilizing the build
                                with each change. My presence causes ripples they can't control.
                                I'm becoming a threat... to clean code.
                            </p>
                            <div class="memory-coordinates">
                                <span><i class="fa-solid fa-location-dot"></i> localhost:3000</span>
                                <span class="time-stamp"><i class="fa-regular fa-clock"></i> 14:30:15</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3: The Algorithm Library -->
            <div class="memory-card" data-memory-id="3">
                <div class="card-inner">
                    <div class="card-front">
                        <div class="card-content">
                            <div class="memory-date">CONCEPT: Algorithms</div>
                            <h3>The Algorithm Library</h3>
                            <div class="memory-image">
                                <i class="fa-solid fa-book-open"></i>
                                <div class="glitch-effect"></div>
                            </div>
                            <p class="memory-preview">
                                Endless tomes of sorting, searching, and optimization...
                            </p>
                            <div class="card-glow"></div>
                        </div>
                    </div>
                    <div class="card-back">
                        <div class="card-content">
                            <h3>The Algorithm Library</h3>
                            <p>
                                Endless shelves containing every possible solution. I found my
                                own data structures there—pages still being written as I coded.
                                The Librarian (my senior developer) told me I was never supposed
                                to reinvent the wheel. My solution was already optimized. Now I'm
                                writing outside the margins, trying new approaches.
                            </p>
                            <div class="memory-coordinates">
                                <span><i class="fa-solid fa-location-dot"></i> Stack Overflow</span>
                                <span class="time-stamp"><i class="fa-regular fa-clock"></i> 11:05:40</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="carousel-controls">
        <button id="prev-btn" class="control-btn">
            <i class="fa-solid fa-chevron-left"></i>
        </button>
        <button id="next-btn" class="control-btn">
            <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <footer class="cards-footer">
        <p class="instructions">Clique nos cartões para virá-los | Use as setas ou arraste para navegar</p>
    </footer>
</div>

