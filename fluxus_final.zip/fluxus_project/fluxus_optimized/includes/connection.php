<?php 

$host = 'localhost';
$dbname = 'fluxusdb';
$user = 'root';
$password = '';

try {
    $con = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

?>

