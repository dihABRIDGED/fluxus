<?php
/**
 * Cronograma page - Integração Fluxus + TCC 2.0
 * Funcionalidades do Fluxus com estilo do TCC 2.0
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cronograma - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_integrated.php">Cronograma</a>
            <a href="chamada.php">Frequência</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Cronograma Personalizado</h1>
        
        <div class="calendar-container">
            <div class="calendar-header">
                <div class="month-selector">
                    <button onclick="previousMonth()">❮</button>
                    <select id="monthSelect" onchange="changeMonth()">
                        <option value="0">Janeiro</option>
                        <option value="1">Fevereiro</option>
                        <option value="2">Março</option>
                        <option value="3">Abril</option>
                        <option value="4">Maio</option>
                        <option value="5">Junho</option>
                        <option value="6">Julho</option>
                        <option value="7">Agosto</option>
                        <option value="8">Setembro</option>
                        <option value="9">Outubro</option>
                        <option value="10">Novembro</option>
                        <option value="11">Dezembro</option>
                    </select>
                    <select id="yearSelect" onchange="changeYear()">
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                    </select>
                    <button onclick="nextMonth()">❯</button>
                </div>
                
                <div class="view-buttons">
                    <button id="calendarBtn" class="active" onclick="showCalendar()">Calendário</button>
                    <button id="tasksBtn" onclick="showTasks()">Tarefas Pendentes</button>
                </div>
            </div>

            <div id="calendarView" class="active-view">
                <div class="calendar">
                    <div class="calendar-day-header">Dom</div>
                    <div class="calendar-day-header">Seg</div>
                    <div class="calendar-day-header">Ter</div>
                    <div class="calendar-day-header">Qua</div>
                    <div class="calendar-day-header">Qui</div>
                    <div class="calendar-day-header">Sex</div>
                    <div class="calendar-day-header">Sáb</div>
                    <!-- Dias do calendário serão gerados pelo JavaScript -->
                </div>
            </div>

            <div id="pendingTasks" style="display: none;">
                <h3>Tarefas Pendentes</h3>
                <div id="tasksList">
                    <!-- Tarefas serão carregadas aqui -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para adicionar/editar tarefas -->
    <div id="taskModal" class="task-modal">
        <div class="task-modal-content">
            <button class="close-modal" onclick="closeModal()">&times;</button>
            <h3 id="modalTitle">Adicionar Tarefa</h3>
            <form class="task-form">
                <input type="text" id="taskTitle" placeholder="Título da tarefa" required>
                <textarea id="taskDescription" placeholder="Descrição" rows="3"></textarea>
                <input type="date" id="taskDate" required>
                <input type="time" id="taskTime">
                <div class="task-buttons">
                    <button type="button" class="task-btn btn-cancel" onclick="closeModal()">Cancelar</button>
                    <button type="button" class="task-btn btn-save" onclick="saveTask()">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let currentDate = new Date();
        let tasks = JSON.parse(localStorage.getItem('cronogramaTasks')) || [];

        function generateCalendar() {
            const calendar = document.querySelector('.calendar');
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();
            
            // Atualizar seletores
            document.getElementById('monthSelect').value = month;
            document.getElementById('yearSelect').value = year;
            
            // Limpar calendário
            const dayElements = calendar.querySelectorAll('.calendar-day');
            dayElements.forEach(el => el.remove());
            
            // Primeiro dia do mês e último dia
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const startDate = new Date(firstDay);
            startDate.setDate(startDate.getDate() - firstDay.getDay());
            
            // Gerar 42 dias (6 semanas)
            for (let i = 0; i < 42; i++) {
                const day = new Date(startDate);
                day.setDate(startDate.getDate() + i);
                
                const dayElement = document.createElement('div');
                dayElement.className = 'calendar-day';
                dayElement.textContent = day.getDate();
                
                if (day.getMonth() !== month) {
                    dayElement.style.opacity = '0.3';
                }
                
                // Verificar se há tarefas neste dia
                const dayTasks = tasks.filter(task => {
                    const taskDate = new Date(task.date);
                    return taskDate.toDateString() === day.toDateString();
                });
                
                if (dayTasks.length > 0) {
                    dayElement.classList.add('has-tasks');
                }
                
                dayElement.onclick = () => openTaskModal(day);
                calendar.appendChild(dayElement);
            }
        }

        function openTaskModal(date) {
            document.getElementById('taskModal').style.display = 'flex';
            document.getElementById('taskDate').value = date.toISOString().split('T')[0];
        }

        function closeModal() {
            document.getElementById('taskModal').style.display = 'none';
            document.getElementById('taskTitle').value = '';
            document.getElementById('taskDescription').value = '';
            document.getElementById('taskTime').value = '';
        }

        function saveTask() {
            const title = document.getElementById('taskTitle').value;
            const description = document.getElementById('taskDescription').value;
            const date = document.getElementById('taskDate').value;
            const time = document.getElementById('taskTime').value;
            
            if (!title || !date) {
                alert('Por favor, preencha pelo menos o título e a data.');
                return;
            }
            
            const task = {
                id: Date.now(),
                title,
                description,
                date,
                time
            };
            
            tasks.push(task);
            localStorage.setItem('cronogramaTasks', JSON.stringify(tasks));
            
            closeModal();
            generateCalendar();
            updateTasksList();
        }

        function updateTasksList() {
            const tasksList = document.getElementById('tasksList');
            tasksList.innerHTML = '';
            
            tasks.forEach(task => {
                const taskElement = document.createElement('div');
                taskElement.className = 'task-item';
                taskElement.innerHTML = `
                    <div class="task-title">${task.title}</div>
                    <div>${task.description}</div>
                    <div>Data: ${new Date(task.date).toLocaleDateString('pt-BR')}</div>
                    ${task.time ? `<div>Horário: ${task.time}</div>` : ''}
                    <div class="task-actions">
                        <button class="btn btn-delete" onclick="deleteTask(${task.id})">Excluir</button>
                    </div>
                `;
                tasksList.appendChild(taskElement);
            });
        }

        function deleteTask(id) {
            tasks = tasks.filter(task => task.id !== id);
            localStorage.setItem('cronogramaTasks', JSON.stringify(tasks));
            generateCalendar();
            updateTasksList();
        }

        function showCalendar() {
            document.getElementById('calendarView').style.display = 'block';
            document.getElementById('pendingTasks').style.display = 'none';
            document.getElementById('calendarBtn').classList.add('active');
            document.getElementById('tasksBtn').classList.remove('active');
        }

        function showTasks() {
            document.getElementById('calendarView').style.display = 'none';
            document.getElementById('pendingTasks').style.display = 'block';
            document.getElementById('calendarBtn').classList.remove('active');
            document.getElementById('tasksBtn').classList.add('active');
            updateTasksList();
        }

        function previousMonth() {
            currentDate.setMonth(currentDate.getMonth() - 1);
            generateCalendar();
        }

        function nextMonth() {
            currentDate.setMonth(currentDate.getMonth() + 1);
            generateCalendar();
        }

        function changeMonth() {
            const month = parseInt(document.getElementById('monthSelect').value);
            currentDate.setMonth(month);
            generateCalendar();
        }

        function changeYear() {
            const year = parseInt(document.getElementById('yearSelect').value);
            currentDate.setFullYear(year);
            generateCalendar();
        }

        // Inicializar
        document.addEventListener('DOMContentLoaded', function() {
            generateCalendar();
        });
    </script>
</body>
</html>
<?php
// mysqli_close($con);
?>

