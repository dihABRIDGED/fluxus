<?php
/**
 * Página de Suporte - Sistema Educacional (Integrada com TCC 2.0)
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Handle form submission
if ($_POST) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];
    
    // In a real application, you would save this to database or send email
    $success_message = "Sua mensagem foi enviada com sucesso! Nossa equipe entrará em contato em breve.";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Suporte - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_aluno_integrated.php">Cronograma</a>
            <a href="faltas_integrated.php">Faltas</a>
            <a href="suporte_integrated.php">Suporte</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Central de Suporte</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <div class="suporte-container">
            <!-- FAQ Section -->
            <div class="faq-section">
                <h2><i class="fas fa-question-circle"></i> Perguntas Frequentes</h2>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(1)">
                        <i class="fas fa-chevron-right"></i>
                        Como faço para acessar meu cronograma?
                    </div>
                    <div class="faq-answer" id="faq-1">
                        <p>Para acessar seu cronograma, clique no menu "Cronograma" no topo da página. Lá você encontrará todas as suas atividades futuras e passadas organizadas por data.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(2)">
                        <i class="fas fa-chevron-right"></i>
                        Como verifico minhas faltas?
                    </div>
                    <div class="faq-answer" id="faq-2">
                        <p>Acesse a seção "Faltas" no menu principal. Lá você encontrará um resumo da sua frequência geral e o histórico detalhado de todas as suas faltas.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(3)">
                        <i class="fas fa-chevron-right"></i>
                        Esqueci minha senha, como recuperar?
                    </div>
                    <div class="faq-answer" id="faq-3">
                        <p>Entre em contato com a coordenação através do formulário abaixo ou pessoalmente. Informe seu código de matrícula para que possamos ajudá-lo a redefinir sua senha.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(4)">
                        <i class="fas fa-chevron-right"></i>
                        Como justificar uma falta?
                    </div>
                    <div class="faq-answer" id="faq-4">
                        <p>Para justificar uma falta, você deve apresentar o documento comprobatório (atestado médico, declaração, etc.) à coordenação dentro do prazo estabelecido pelo regulamento.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(5)">
                        <i class="fas fa-chevron-right"></i>
                        O sistema funciona no celular?
                    </div>
                    <div class="faq-answer" id="faq-5">
                        <p>Sim! O sistema é totalmente responsivo e funciona perfeitamente em smartphones e tablets. Você pode acessar todas as funcionalidades pelo seu dispositivo móvel.</p>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contato-section">
                <h2><i class="fas fa-envelope"></i> Entre em Contato</h2>
                
                <form method="POST" action="suporte_integrated.php" class="contato-form">
                    <div class="form-group">
                        <label for="nome">Nome Completo:</label>
                        <input type="text" name="nome" id="nome" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="assunto">Assunto:</label>
                        <select name="assunto" id="assunto" required>
                            <option value="">Selecione o assunto...</option>
                            <option value="duvida_sistema">Dúvida sobre o sistema</option>
                            <option value="problema_acesso">Problema de acesso</option>
                            <option value="erro_dados">Erro nos dados</option>
                            <option value="sugestao">Sugestão</option>
                            <option value="outro">Outro</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="mensagem">Mensagem:</label>
                        <textarea name="mensagem" id="mensagem" rows="6" required placeholder="Descreva detalhadamente sua dúvida ou problema..."></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Enviar Mensagem
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-eraser"></i> Limpar
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Contact Info -->
        <div class="info-contato">
            <h2><i class="fas fa-info-circle"></i> Informações de Contato</h2>
            <div class="contato-cards">
                <div class="contato-card">
                    <i class="fas fa-phone"></i>
                    <h3>Telefone</h3>
                    <p>(11) 1234-5678</p>
                </div>
                <div class="contato-card">
                    <i class="fas fa-envelope"></i>
                    <h3>E-mail</h3>
                    <p>suporte@sistema.edu.br</p>
                </div>
                <div class="contato-card">
                    <i class="fas fa-clock"></i>
                    <h3>Horário</h3>
                    <p>Seg-Sex: 8h às 18h</p>
                </div>
                <div class="contato-card">
                    <i class="fas fa-map-marker-alt"></i>
                    <h3>Localização</h3>
                    <p>Secretaria - Térreo</p>
                </div>
            </div>
        </div>
    </div>

    <style>
        .suporte-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .faq-section, .contato-section {
            background: #222;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #333;
        }

        .faq-section h2, .contato-section h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .faq-item {
            margin-bottom: 15px;
            border: 1px solid #444;
            border-radius: 8px;
            overflow: hidden;
        }

        .faq-question {
            padding: 15px;
            background: #333;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
            font-weight: 500;
            transition: background-color 0.3s;
        }

        .faq-question:hover {
            background: #444;
        }

        .faq-question i {
            color: #c62828;
            transition: transform 0.3s;
        }

        .faq-question.active i {
            transform: rotate(90deg);
        }

        .faq-answer {
            padding: 0 15px;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease;
            background: #2a2a2a;
        }

        .faq-answer.active {
            max-height: 200px;
            padding: 15px;
        }

        .faq-answer p {
            color: #ccc;
            line-height: 1.6;
            margin: 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: white;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 6px;
            font-size: 14px;
            background-color: #333;
            color: white;
            transition: border-color 0.3s;
        }

        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none;
            border-color: #c62828;
            box-shadow: 0 0 0 2px rgba(198, 40, 40, 0.25);
        }

        .form-actions {
            margin-top: 25px;
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .alert-success {
            background: #2d5a2d;
            color: #4CAF50;
            border: 1px solid #4CAF50;
        }

        .info-contato {
            max-width: 1200px;
            margin: 30px auto 0;
            padding: 20px;
            background: #222;
            border-radius: 10px;
            border: 1px solid #333;
        }

        .info-contato h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .contato-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .contato-card {
            background: #333;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid #444;
            transition: transform 0.3s;
        }

        .contato-card:hover {
            transform: translateY(-5px);
        }

        .contato-card i {
            font-size: 2rem;
            color: #c62828;
            margin-bottom: 15px;
        }

        .contato-card h3 {
            color: white;
            margin-bottom: 10px;
        }

        .contato-card p {
            color: #ccc;
            margin: 0;
        }

        @media (max-width: 768px) {
            .suporte-container {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }
    </style>

    <script>
        function toggleFaq(id) {
            const question = document.querySelector(`#faq-${id}`).previousElementSibling;
            const answer = document.querySelector(`#faq-${id}`);
            
            // Close all other FAQs
            document.querySelectorAll('.faq-answer').forEach(item => {
                if (item !== answer) {
                    item.classList.remove('active');
                    item.previousElementSibling.classList.remove('active');
                }
            });
            
            // Toggle current FAQ
            question.classList.toggle('active');
            answer.classList.toggle('active');
        }
    </script>
</body>
</html>

<?php
$con = null;
?>

