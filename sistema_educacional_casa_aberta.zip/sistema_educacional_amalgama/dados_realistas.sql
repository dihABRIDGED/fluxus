-- Script para adicionar dados realistas ao sistema educacional
-- Executar após importar o banco original

USE fluxusdb;

-- Adicionar mais disciplinas
INSERT INTO `disciplina` (`nome`, `professor_id`) VALUES
('Matemática', 2),
('História', 3),
('Geografia', 2),
('Ciências', 3);

-- Adicionar mais matrículas (alunos nas disciplinas)
INSERT INTO `matricula` (`aluno_id`, `disciplina_id`) VALUES
-- Rodrigo Silva (id=8) em todas as disciplinas
(8, 2), -- Matemática
(8, 3), -- História  
(8, 4), -- Geografia
(8, 5), -- Ciências

-- Diego Martins (id=4) em algumas disciplinas
(4, 1), -- Língua Portuguesa
(4, 2), -- Matemática
(4, 3), -- História

-- Fernanda Lopes (id=5) em algumas disciplinas
(5, 1), -- Língua Portuguesa
(5, 2), -- Matemática
(5, 4), -- Geografia
(5, 5), -- Ciências

-- Gustavo Pereira (id=6) em algumas disciplinas
(6, 1), -- Língua Portuguesa
(6, 3), -- História
(6, 4), -- Geografia

-- Mariana Costa (id=7) em algumas disciplinas
(7, 2), -- Matemática
(7, 3), -- História
(7, 5); -- Ciências

-- Adicionar mais aulas
INSERT INTO `aula` (`turma_id`, `data`, `conteudo`, `criado_por`) VALUES
-- Aulas de Língua Portuguesa (disciplina_id = 1, professor_id = 3)
(1, '2024-12-01', 'Introdução à Literatura Brasileira', 3),
(1, '2024-12-03', 'Análise de Texto - Machado de Assis', 3),
(1, '2024-12-05', 'Gramática: Classes de Palavras', 3),
(1, '2024-12-08', 'Redação: Texto Dissertativo', 3),
(1, '2024-12-10', 'Literatura: Romantismo', 3),

-- Aulas de Matemática (disciplina_id = 2, professor_id = 2)
(2, '2024-12-02', 'Equações do 1º Grau', 2),
(2, '2024-12-04', 'Equações do 2º Grau', 2),
(2, '2024-12-06', 'Funções Lineares', 2),
(2, '2024-12-09', 'Geometria Plana', 2),
(2, '2024-12-11', 'Trigonometria Básica', 2),

-- Aulas de História (disciplina_id = 3, professor_id = 3)
(3, '2024-12-02', 'Brasil Colonial', 3),
(3, '2024-12-04', 'Independência do Brasil', 3),
(3, '2024-12-06', 'República Velha', 3),
(3, '2024-12-09', 'Era Vargas', 3),
(3, '2024-12-11', 'Ditadura Militar', 3),

-- Aulas de Geografia (disciplina_id = 4, professor_id = 2)
(4, '2024-12-03', 'Relevo Brasileiro', 2),
(4, '2024-12-05', 'Hidrografia', 2),
(4, '2024-12-10', 'Clima e Vegetação', 2),

-- Aulas de Ciências (disciplina_id = 5, professor_id = 3)
(5, '2024-12-01', 'Sistema Solar', 3),
(5, '2024-12-03', 'Células e Tecidos', 3),
(5, '2024-12-08', 'Ecossistemas', 3);

-- Adicionar registros de frequência realistas
INSERT INTO `frequencia` (`aula_id`, `aluno_id`, `presente`) VALUES
-- Aulas de Língua Portuguesa (aula_id 5-9)
(5, 8, 1), (5, 4, 1), (5, 5, 1), (5, 6, 1), -- Aula 1 - todos presentes
(6, 8, 0), (6, 4, 1), (6, 5, 1), (6, 6, 1), -- Aula 2 - Rodrigo faltou
(7, 8, 1), (7, 4, 0), (7, 5, 1), (7, 6, 1), -- Aula 3 - Diego faltou
(8, 8, 1), (8, 4, 1), (8, 5, 0), (8, 6, 1), -- Aula 4 - Fernanda faltou
(9, 8, 1), (9, 4, 1), (9, 5, 1), (9, 6, 0), -- Aula 5 - Gustavo faltou

-- Aulas de Matemática (aula_id 10-14)
(10, 8, 1), (10, 4, 1), (10, 5, 1), (10, 7, 1), -- Aula 1 - todos presentes
(11, 8, 1), (11, 4, 0), (11, 5, 1), (11, 7, 1), -- Aula 2 - Diego faltou
(12, 8, 0), (12, 4, 1), (12, 5, 1), (12, 7, 1), -- Aula 3 - Rodrigo faltou
(13, 8, 1), (13, 4, 1), (13, 5, 1), (13, 7, 0), -- Aula 4 - Mariana faltou
(14, 8, 1), (14, 4, 1), (14, 5, 0), (14, 7, 1), -- Aula 5 - Fernanda faltou

-- Aulas de História (aula_id 15-19)
(15, 8, 1), (15, 4, 1), (15, 6, 1), (15, 7, 1), -- Aula 1 - todos presentes
(16, 8, 0), (16, 4, 1), (16, 6, 1), (16, 7, 1), -- Aula 2 - Rodrigo faltou
(17, 8, 1), (17, 4, 1), (17, 6, 0), (17, 7, 1), -- Aula 3 - Gustavo faltou
(18, 8, 1), (18, 4, 0), (18, 6, 1), (18, 7, 1), -- Aula 4 - Diego faltou
(19, 8, 1), (19, 4, 1), (19, 6, 1), (19, 7, 0), -- Aula 5 - Mariana faltou

-- Aulas de Geografia (aula_id 20-22)
(20, 8, 1), (20, 5, 1), (20, 6, 1), -- Aula 1 - todos presentes
(21, 8, 0), (21, 5, 1), (21, 6, 1), -- Aula 2 - Rodrigo faltou
(22, 8, 1), (22, 5, 0), (22, 6, 1), -- Aula 3 - Fernanda faltou

-- Aulas de Ciências (aula_id 23-25)
(23, 8, 1), (23, 5, 1), (23, 7, 1), -- Aula 1 - todos presentes
(24, 8, 1), (24, 5, 1), (24, 7, 0), -- Aula 2 - Mariana faltou
(25, 8, 0), (25, 5, 1), (25, 7, 1); -- Aula 3 - Rodrigo faltou

-- Adicionar mais atividades
INSERT INTO `atividade` (`disciplina_id`, `titulo`, `descricao`, `data_atividade`, `tipo`, `criado_por`) VALUES
(1, 'Redação sobre Machado de Assis', 'Escrever uma redação de 30 linhas sobre a obra Dom Casmurro', '2024-12-15', 'redacao', 3),
(1, 'Prova de Literatura', 'Avaliação sobre Romantismo e Realismo', '2024-12-18', 'prova', 3),
(2, 'Lista de Exercícios - Equações', 'Resolver exercícios do capítulo 5', '2024-12-12', 'exercicio', 2),
(2, 'Prova de Matemática', 'Avaliação sobre funções e geometria', '2024-12-20', 'prova', 2),
(3, 'Trabalho sobre Brasil Colonial', 'Pesquisa em grupo sobre período colonial', '2024-12-16', 'trabalho', 3),
(4, 'Mapa do Brasil', 'Desenhar mapa com relevos e rios', '2024-12-14', 'atividade', 2),
(5, 'Relatório de Experimento', 'Relatório sobre observação de células', '2024-12-17', 'relatorio', 3);
