-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 04-Out-2025 às 07:04
-- Versão do servidor: 10.4.10-MariaDB
-- versão do PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `fluxusdb`
--
CREATE DATABASE IF NOT EXISTS `fluxusdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fluxusdb`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `atividade`
--

DROP TABLE IF EXISTS `atividade`;
CREATE TABLE IF NOT EXISTS `atividade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disciplina_id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text DEFAULT NULL,
  `data_atividade` date NOT NULL,
  `tipo` varchar(50) NOT NULL DEFAULT 'atividade',
  `criado_por` int(11) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `criado_por` (`criado_por`),
  KEY `disciplina_id` (`disciplina_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `atividade`
--

INSERT INTO `atividade` (`id`, `disciplina_id`, `titulo`, `descricao`, `data_atividade`, `tipo`, `criado_por`, `criado_em`) VALUES
(1, 0, 'trabalho de portugues', 'escrevam o dicionário inteiro ', '2025-08-28', 'trabalho', 5, '2025-08-26 18:04:49');

-- --------------------------------------------------------

--
-- Estrutura da tabela `aula`
--

DROP TABLE IF EXISTS `aula`;
CREATE TABLE IF NOT EXISTS `aula` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `turma_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `conteudo` text DEFAULT NULL,
  `criado_por` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `turma_id` (`turma_id`),
  KEY `criado_por` (`criado_por`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `aula`
--

INSERT INTO `aula` (`id`, `turma_id`, `data`, `conteudo`, `criado_por`) VALUES
(4, 1, '2025-10-04', 'linua portuguese', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina`
--

DROP TABLE IF EXISTS `disciplina`;
CREATE TABLE IF NOT EXISTS `disciplina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `professor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `coordenador_id` (`professor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `disciplina`
--

INSERT INTO `disciplina` (`id`, `nome`, `professor_id`) VALUES
(1, 'Língua Portuguesa', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `frequencia`
--

DROP TABLE IF EXISTS `frequencia`;
CREATE TABLE IF NOT EXISTS `frequencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aula_id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `presente` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aula_id` (`aula_id`,`aluno_id`),
  KEY `aluno_id` (`aluno_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `frequencia`
--

INSERT INTO `frequencia` (`id`, `aula_id`, `aluno_id`, `presente`) VALUES
(1, 2, 22, 1),
(2, 3, 22, 0),
(3, 3, 23, 1),
(4, 4, 8, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `matricula`
--

DROP TABLE IF EXISTS `matricula`;
CREATE TABLE IF NOT EXISTS `matricula` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aluno_id` int(11) NOT NULL,
  `disciplina_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aluno_id` (`aluno_id`,`disciplina_id`),
  KEY `turma_id` (`disciplina_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `matricula`
--

INSERT INTO `matricula` (`id`, `aluno_id`, `disciplina_id`) VALUES
(1, 8, 1),
(2, 23, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tipo` enum('aluno','professor','coordenador') NOT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `email`, `tipo`, `login`, `senha`, `ativo`) VALUES
(1, 'Ana Souza', 'ana.souza@fluxus.edu', 'coordenador', 'ana.souza@fluxus.edu', '123456', 1),
(2, 'Bruno Almeida', 'bruno.almeida@fluxus.edu', 'professor', 'bruno.almeida@fluxus.edu', '123456', 1),
(3, 'Carla Ribeiro', 'carla.ribeiro@fluxus.edu', 'professor', 'carla.ribeiro@fluxus.edu', '123456', 1),
(4, 'Diego Martins', 'diego.martins@estudante.fluxus.edu', 'aluno', 'diego.martins@estudante.fluxus.edu', '123456', 1),
(5, 'Fernanda Lopes', 'fernanda.lopes@estudante.fluxus.edu', 'aluno', 'fernanda.lopes@estudante.fluxus.edu', '123456', 1),
(6, 'Gustavo Pereira', 'gustavo.pereira@estudante.fluxus.edu', 'aluno', 'gustavo.pereira@estudante.fluxus.edu', '123456', 1),
(7, 'Mariana Costa', 'mariana.costa@estudante.fluxus.edu', 'aluno', 'mariana.costa@estudante.fluxus.edu', '123456', 1),
(8, 'Rodrigo Silva', 'rodrigo.silva@estudante.fluxus.edu', 'aluno', 'rodrigo.silva@estudante.fluxus.edu', '123456', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
