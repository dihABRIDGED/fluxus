-- Script para adicionar campos de cronograma na tabela aula
-- Adiciona horário e dia da semana para cronograma semanal

USE fluxusdb;

-- Adicionar novos campos na tabela aula
ALTER TABLE `aula` 
ADD COLUMN `horario` TIME DEFAULT '08:00:00' AFTER `data`,
ADD COLUMN `dia_semana` VARCHAR(20) DEFAULT 'segunda' AFTER `horario`;

-- Atualizar registros existentes com horários e dias da semana baseados na data
UPDATE `aula` SET 
    `horario` = CASE 
        WHEN id % 3 = 0 THEN '08:00:00'
        WHEN id % 3 = 1 THEN '10:00:00'
        ELSE '14:00:00'
    END,
    `dia_semana` = CASE DAYOFWEEK(`data`)
        WHEN 2 THEN 'segunda'
        WHEN 3 THEN 'terca'
        WHEN 4 THEN 'quarta'
        WHEN 5 THEN 'quinta'
        WHEN 6 THEN 'sexta'
        ELSE 'segunda'
    END;

-- Inserir cronograma semanal padrão para as disciplinas
INSERT INTO `aula` (`turma_id`, `data`, `horario`, `dia_semana`, `conteudo`, `criado_por`) VALUES
-- Segunda-feira
(1, '2024-12-16', '08:00:00', 'segunda', 'Língua Portuguesa - Gramática', 3),
(2, '2024-12-16', '10:00:00', 'segunda', 'Matemática - Álgebra', 2),
(3, '2024-12-16', '14:00:00', 'segunda', 'História - Brasil República', 3),

-- Terça-feira
(4, '2024-12-17', '08:00:00', 'terca', 'Geografia - Relevo Brasileiro', 2),
(5, '2024-12-17', '10:00:00', 'terca', 'Ciências - Sistema Solar', 3),
(1, '2024-12-17', '14:00:00', 'terca', 'Língua Portuguesa - Literatura', 3),

-- Quarta-feira
(2, '2024-12-18', '08:00:00', 'quarta', 'Matemática - Geometria', 2),
(3, '2024-12-18', '10:00:00', 'quarta', 'História - Era Vargas', 3),
(4, '2024-12-18', '14:00:00', 'quarta', 'Geografia - Hidrografia', 2),

-- Quinta-feira
(5, '2024-12-19', '08:00:00', 'quinta', 'Ciências - Ecossistemas', 3),
(1, '2024-12-19', '10:00:00', 'quinta', 'Língua Portuguesa - Redação', 3),
(2, '2024-12-19', '14:00:00', 'quinta', 'Matemática - Funções', 2),

-- Sexta-feira
(3, '2024-12-20', '08:00:00', 'sexta', 'História - Ditadura Militar', 3),
(4, '2024-12-20', '10:00:00', 'sexta', 'Geografia - Clima e Vegetação', 2),
(5, '2024-12-20', '14:00:00', 'sexta', 'Ciências - Células e Tecidos', 3);

-- Criar índices para melhor performance
CREATE INDEX idx_dia_semana ON aula(dia_semana);
CREATE INDEX idx_horario ON aula(horario);
CREATE INDEX idx_dia_horario ON aula(dia_semana, horario);
