<html>

  <body>
    <?php
// Iniciar a sessão se ainda não estiver iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = isset($_SESSION["logged_in"]) && $_SESSION["logged_in"] === true;
$userType = $isLoggedIn ? $_SESSION["user_type"] : null;
?>
  <header>
    
           <nav>
        <a href="home_integrated.php">Página Inicial</a>

        <?php if ($isLoggedIn): // Mostrar links apenas se o usuário estiver logado ?>

            <?php if ($userType === 'aluno'): ?>
                <a href="cronograma_aluno_integrated.php">Cronograma</a>
                <a href="faltas.php">Faltas</a>
            <?php elseif ($userType === 'professor'): ?>
                <a href="chamada.php">Faltas</a>
                <a href="agendamento.php">Cronograma</a>
                <a href="gerenciar_usuarios_integrated.php">Gerenciar Usuários</a>
            <?php elseif ($userType === 'coordenador'): ?>
                <a href="agendamento.php">Agendamento</a>
                <a href="gerenciar_usuarios_integrated.php">Gerenciar Usuários</a>
            <?php endif; ?>

            <a href="suporte_integrated.php">Suporte</a>
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        <?php else: // Links para usuários não logados (opcional, se houver) ?>
            <!-- Adicionar links para usuários não logados aqui, se necessário -->
            <!-- Exemplo: <a href="index.php">Login</a> -->
        <?php endif; ?>
    </nav>
    </header>
  </body>
</html>