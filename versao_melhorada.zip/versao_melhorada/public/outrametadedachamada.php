<?php
session_start();

// Check if user is logged in and is a professor
if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true || $_SESSION["user_type"] !== "professor") {
    header("Location: ../index.php");
    exit();
}

require_once "../includes/connection.php";
require_once "../includes/header.php"; // Incluído aqui para consistência, se não estiver no header.php

// --- Lógica para buscar turmas do professor (do arquivo original sem nome e outrametadedachamada.php) ---
$professor_id = $_SESSION["user_id"];

$stmt_turmas_db = $con->prepare("
    SELECT
        t.id AS turma_id,
        d.nome AS disciplina_nome,
        t.semestre
    FROM
        turma t
    JOIN
        disciplina d ON t.disciplina_id = d.id
    WHERE
        t.professor_id = :professor_id
");
$stmt_turmas_db->bindParam(":professor_id", $professor_id, PDO::PARAM_INT);
$stmt_turmas_db->execute();
$turmas_db = $stmt_turmas_db->fetchAll(PDO::FETCH_ASSOC);

// --- Lógica do arquivo original 'chamada.php' (Controle de Frequência) ---
// Usar as turmas do banco de dados se existirem, caso contrário, usar as turmas de demonstração
$turmas_chamada = !empty($turmas_db) ? $turmas_db : [
    ["id" => 1, "disciplina_nome" => "Matemática", "semestre" => "2024.1"],
    ["id" => 2, "disciplina_nome" => "Português", "semestre" => "2024.1"],
    ["id" => 3, "disciplina_nome" => "História", "semestre" => "2024.1"]
];

$success_message = null;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $turma_id = $_POST["turma_id"] ?? null;
    $data = $_POST["data"] ?? null;
    $conteudo = $_POST["conteudo"] ?? null;
    
    // Aqui você adicionaria a lógica para salvar a chamada no banco de dados
    // Por exemplo:
    // $stmt_insert_chamada = $con->prepare("INSERT INTO chamadas (turma_id, data, conteudo) VALUES (?, ?, ?)");
    // $stmt_insert_chamada->execute([$turma_id, $data, $conteudo]);
    // $chamada_id = $con->lastInsertId();
    // foreach ($_POST as $key => $value) {
    //     if (strpos($key, 'presente_') === 0) {
    //         $aluno_id = str_replace('presente_', '', $key);
    //         $presenca = ($value == '1') ? 1 : 0;
    //         // Inserir presença do aluno para esta chamada
    //         // $stmt_insert_presenca = $con->prepare("INSERT INTO presencas (chamada_id, aluno_id, presente) VALUES (?, ?, ?)");
    //         // $stmt_insert_presenca->execute([$chamada_id, $aluno_id, $presenca]);
    //     }
    // }
    
    $success_message = "Chamada realizada com sucesso!";
}

$selected_turma_id = $_GET["turma_id"] ?? null;
$alunos_turma = [];
if ($selected_turma_id) {
    // Lógica para buscar alunos da turma no banco de dados
    // Exemplo:
    // $stmt_alunos = $con->prepare("SELECT id, nome FROM alunos WHERE turma_id = :turma_id");
    // $stmt_alunos->bindParam(':turma_id', $selected_turma_id, PDO::PARAM_INT);
    // $stmt_alunos->execute();
    // $alunos_turma = $stmt_alunos->fetchAll(PDO::FETCH_ASSOC);

    // Demo students if no DB logic is implemented or for testing
    if (empty($alunos_turma)) {
        $alunos_turma = [
            ["id" => 1, "nome" => "Ana Silva"],
            ["id" => 2, "nome" => "Bruno Santos"],
            ["id" => 3, "nome" => "Carlos Oliveira"],
            ["id" => 4, "nome" => "Diana Costa"],
            ["id" => 5, "nome" => "Eduardo Lima"]
        ];
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<body>
    <!-- Header no estilo TCC 2.0 -->
    <header>
        <a href="home_integrated.php" class="logo">
            <img src="img/logo.png" alt="Logo do Sistema" class="logo-img" />
        </a>
        <nav>
            <a href="home_integrated.php">Página Inicial</a>
            <a href="cronograma_integrated.php">Cronograma</a>
            <a href="chamada_fusionada.php">Frequência</a> <!-- Atualizado para o novo nome do arquivo -->
            <a href="../core/logout.php" class="sair">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </nav>
    </header>

    <div class="main-content">
        <h1>Controle de Frequência</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <div class="user-view-selector">
            <button class="view-btn active" onclick="showProfessorDashboardView()">
                <i class="fas fa-chalkboard-teacher"></i> Visão Professor (Dashboard)
            </button>
            <button class="view-btn" onclick="showProfessorAttendanceView()">
                <i class="fas fa-clipboard-check"></i> Visão Professor (Chamada)
            </button>
            <button class="view-btn" onclick="showStudentView()">
                <i class="fas fa-user-graduate"></i> Visão Aluno
            </button>
        </div>

        <!-- Visão Professor - Dashboard (Conteúdo do arquivo original sem nome e outrametadedachamada.php) -->
        <div id="professorDashboardView" class="view-section">
            <div class="professor-info">
                <div class="info-card">
                    <h2><i class="fas fa-info-circle"></i> Suas Turmas</h2>
                    <?php if (count($turmas_db) > 0): ?>
                        <p>Selecione uma turma para gerenciar a frequência e atividades:</p>
                        <ul>
                            <?php foreach ($turmas_db as $turma_item): ?>
                                <li>
                                    <strong><?php echo htmlspecialchars($turma_item["disciplina_nome"]); ?></strong> - Semestre: <?php echo htmlspecialchars($turma_item["semestre"]); ?>
                                    <div class="professor-actions">
                                        <a href="chamada_fusionada.php?turma_id=<?php echo $turma_item["turma_id"]; ?>" class="btn btn-primary">
                                            <i class="fas fa-clipboard-check"></i> Fazer Chamada
                                        </a>
                                        <a href="agendamento.php?turma_id=<?php echo $turma_item["turma_id"]; ?>" class="btn btn-secondary">
                                            <i class="fas fa-calendar-plus"></i> Agendar Atividade
                                        </a>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>Você não está associado a nenhuma turma ainda.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Visão Professor - Registro de Chamada (Conteúdo do arquivo original 'chamada.php') -->
        <div id="professorAttendanceView" class="view-section">
            <div class="chamada-container">
                <div class="step-card">
                    <h2><i class="fas fa-users"></i> 1. Selecione a Turma</h2>
                    <form method="GET" action="chamada_fusionada.php">
                        <select name="turma_id" onchange="this.form.submit()" required>
                            <option value="">Selecione uma turma...</option>
                            <?php foreach ($turmas_chamada as $turma): ?>
                                <option value="<?php echo $turma["id"]; ?>" <?php echo $selected_turma_id == $turma["id"] ? "selected" : ""; ?>>
                                    <?php echo $turma["disciplina_nome"] . " - " . $turma["semestre"]; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
                
                <?php if ($selected_turma_id && !empty($alunos_turma)): ?>
                <div class="step-card">
                    <h2><i class="fas fa-clipboard-check"></i> 2. Registrar Aula e Presença</h2>
                    <form method="POST" action="chamada_fusionada.php">
                        <input type="hidden" name="turma_id" value="<?php echo $selected_turma_id; ?>">
                        
                        <div class="aula-info">
                            <div class="form-group">
                                <label for="data">Data da Aula:</label>
                                <input type="date" name="data" id="data" value="<?php echo date("Y-m-d"); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="conteudo">Conteúdo da Aula:</label>
                                <textarea name="conteudo" id="conteudo" rows="3" placeholder="Descreva o conteúdo abordado na aula..."></textarea>
                            </div>
                        </div>
                        
                        <div class="lista-alunos">
                            <h3>Lista de Presença</h3>
                            <div class="alunos-grid">
                                <?php foreach ($alunos_turma as $aluno): ?>
                                <div class="aluno-item">
                                    <label class="checkbox-container">
                                        <input type="checkbox" name="presente_<?php echo $aluno["id"]; ?>" value="1">
                                        <span class="checkmark"></span>
                                        <?php echo $aluno["nome"]; ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Registrar Chamada
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="marcarTodos()">
                                <i class="fas fa-check-double"></i> Marcar Todos
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="desmarcarTodos()">
                                <i class="fas fa-times"></i> Desmarcar Todos
                            </button>
                        </div>
                    </form>
                </div>
                <?php elseif ($selected_turma_id): ?>
                <div class="no-students">
                    <i class="fas fa-user-slash"></i>
                    <p>Nenhum aluno encontrado nesta turma.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Visão Aluno -->
        <div id="studentView" class="view-section">
            <div class="frequencia-resumo">
                <div class="card">
                    <h3>Frequência Geral</h3>
                    <div class="numero-risco">85%</div>
                    <p>Presença nas aulas</p>
                </div>
                <div class="card">
                    <h3>Faltas no Mês</h3>
                    <div class="numero-risco">3</div>
                    <p>Faltas em Dezembro</p>
                </div>
            </div>

            <table class="tabela-frequencia">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Disciplina</th>
                        <th>Conteúdo</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>15/12/2024</td>
                        <td>Matemática</td>
                        <td>Equações do 2º grau</td>
                        <td><span class="presenca">Presente</span></td>
                    </tr>
                    <tr>
                        <td>14/12/2024</td>
                        <td>Português</td>
                        <td>Análise sintática</td>
                        <td><span class="falta">Falta</span></td>
                    </tr>
                    <tr>
                        <td>13/12/2024</td>
                        <td>História</td>
                        <td>Segunda Guerra Mundial</td>
                        <td><span class="presenca">Presente</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function showProfessorDashboardView() {
            document.getElementById('professorDashboardView').classList.add('active');
            document.getElementById('professorAttendanceView').classList.remove('active');
            document.getElementById('studentView').classList.remove('active');
            document.querySelectorAll('.user-view-selector .view-btn')[0].classList.add('active');
            document.querySelectorAll('.user-view-selector .view-btn')[1].classList.remove('active');
            document.querySelectorAll('.user-view-selector .view-btn')[2].classList.remove('active');
        }

        function showProfessorAttendanceView() {
            document.getElementById('professorDashboardView').classList.remove('active');
            document.getElementById('professorAttendanceView').classList.add('active');
            document.getElementById('studentView').classList.remove('active');
            document.querySelectorAll('.user-view-selector .view-btn')[0].classList.remove('active');
            document.querySelectorAll('.user-view-selector .view-btn')[1].classList.add('active');
            document.querySelectorAll('.user-view-selector .view-btn')[2].classList.remove('active');
        }

        function showStudentView() {
            document.getElementById('professorDashboardView').classList.remove('active');
            document.getElementById('professorAttendanceView').classList.remove('active');
            document.getElementById('studentView').classList.add('active');
            document.querySelectorAll('.user-view-selector .view-btn')[0].classList.remove('active');
            document.querySelectorAll('.user-view-selector .view-btn')[1].classList.remove('active');
            document.querySelectorAll('.user-view-selector .view-btn')[2].classList.add('active');
        }

        function marcarTodos() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name^="presente_"]');
            checkboxes.forEach(checkbox => checkbox.checked = true);
        }

        function desmarcarTodos() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name^="presente_"]');
            checkboxes.forEach(checkbox => checkbox.checked = false);
        }

        // Initial view setup
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('turma_id')) {
                // If a turma_id is selected, show the attendance view by default
                showProfessorAttendanceView();
            } else {
                // Otherwise, show the dashboard view by default
                showProfessorDashboardView();
            }
        });
    </script>

    <style>
        .chamada-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .step-card {
            background: #222;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid #333;
        }

        .step-card h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: white;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 5px;
            background-color: #333;
            color: white;
            font-size: 14px;
        }

        .alunos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .aluno-item {
            padding: 15px;
            border: 1px solid #444;
            border-radius: 8px;
            background: #333;
            transition: background-color 0.3s;
        }

        .aluno-item:hover {
            background: #444;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            cursor: pointer;
            font-size: 14px;
            color: white;
        }

        .checkbox-container input {
            margin-right: 12px;
            width: auto;
            transform: scale(1.2);
        }

        .form-actions {
            margin-top: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .alert-success {
            background: #2d5a2d;
            color: #4CAF50;
            border: 1px solid #4CAF50;
        }

        .no-students {
            text-align: center;
            padding: 60px;
            color: #ccc;
            background: #222;
            border-radius: 10px;
        }

        .no-students i {
            font-size: 3rem;
            color: #c62828;
            margin-bottom: 15px;
        }

        .coordenador-resumo {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            margin-bottom: 30px;
        }

        .coordenador-resumo .card {
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            width: 45%;
        }

        /* Estilos para as seções de visualização */
        .view-section {
            display: none;
        }

        .view-section.active {
            display: block;
        }

        .user-view-selector {
            text-align: center;
            margin-bottom: 30px;
        }

        .user-view-selector .view-btn {
            background-color: #444;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .user-view-selector .view-btn.active {
            background-color: #c62828;
        }

        .user-view-selector .view-btn:hover:not(.active) {
            background-color: #555;
        }

        .professor-info {
            margin-top: 20px;
        }

        .professor-info .info-card {
            background-color: #222;
            padding: 30px;
            border-radius: 10px;
            border: 1px solid #333;
        }

        .professor-info .info-card h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .professor-info .info-card ul {
            list-style: none;
            padding: 0;
        }

        .professor-info .info-card li {
            background-color: #333;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .professor-info .info-card li strong {
            color: white;
        }

        .professor-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .professor-actions .btn {
            padding: 8px 15px;
            font-size: 13px;
        }

        .frequencia-resumo {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            margin-bottom: 30px;
        }

        .frequencia-resumo .card {
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            width: 45%;
            border: 1px solid #333;
        }

        .frequencia-resumo .card h3 {
            color: #c62828;
            margin-bottom: 10px;
        }

        .frequencia-resumo .card .numero-risco {
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            margin-bottom: 5px;
        }

        .tabela-frequencia {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .tabela-frequencia th, .tabela-frequencia td {
            border: 1px solid #444;
            padding: 12px;
            text-align: left;
            color: white;
        }

        .tabela-frequencia th {
            background-color: #333;
            color: #c62828;
        }

        .tabela-frequencia tr:nth-child(even) {
            background-color: #2a2a2a;
        }

        .tabela-frequencia tr:hover {
            background-color: #3a3a3a;
        }

        .presenca {
            color: #4CAF50;
            font-weight: bold;
        }

        .falta {
            color: #f44336;
            font-weight: bold;
        }
    </style>
</body>
</html>
<?php
// mysqli_close($con); // Comentado para evitar fechar a conexão prematuramente se outras partes do sistema a usarem
?>