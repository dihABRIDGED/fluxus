<?php
/**
 * Página de Dashboard Dinâmico (Agendamento e Cronograma)
 * Fluxus Project - Versão Aperfeiçoada com Front-End Dinâmico
 */

session_start();

// Check if user is logged in and is a professor
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'professor') {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Definir o ID da turma padrão, já que há apenas uma turma
$turma_padrao_id = 1; // Assumindo que o ID da única turma é 1

// Lógica PHP para Agendamento de Atividades
$atividades = [];
$success_message = '';

// Handle form submission for activities
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'agendar_atividade') {
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $data_atividade = $_POST['data_atividade'];
    $tipo = $_POST['tipo'];
    
    $stmt = $con->prepare("INSERT INTO Atividade (turma_id, titulo, descricao, data_atividade, tipo, criado_por) VALUES (:turma_id, :titulo, :descricao, :data_atividade, :tipo, :criado_por)");
    $stmt->bindParam(':turma_id', $turma_padrao_id);
    $stmt->bindParam(':titulo', $titulo);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':data_atividade', $data_atividade);
    $stmt->bindParam(':tipo', $tipo);
    $stmt->bindParam(':criado_por', $_SESSION['user_id']);
    $stmt->execute();
    
    $success_message = "Atividade agendada com sucesso!";
    header('Location: dashboard_dinamico.php?message=' . urlencode($success_message));
    exit();
}

// Get existing activities for the default class
$stmt = $con->prepare("
    SELECT a.*, d.nome as disciplina_nome, t.semestre 
    FROM Atividade a 
    JOIN Turma t ON a.turma_id = t.id 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    WHERE a.criado_por = :professor_id AND a.turma_id = :turma_id 
    ORDER BY a.data_atividade DESC
");
$stmt->bindParam(':professor_id', $_SESSION['user_id']);
$stmt->bindParam(':turma_id', $turma_padrao_id);
$stmt->execute();
$atividades = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lógica para exibir mensagem de sucesso após redirecionamento
if (isset($_GET['message'])) {
    $success_message = htmlspecialchars($_GET['message']);
}

// Lógica PHP para Aulas
$aulas = [];
$success_message_aula = "";

// Handle form submission for classes
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "agendar_aula") {
    $data_aula = $_POST["data_aula"];
    $conteudo_aula = $_POST["conteudo_aula"];
    
    // Reabrir conexão se necessário, ou garantir que esteja aberta
    require_once '../includes/connection.php';

    $stmt_aula = $con->prepare("INSERT INTO Aula (turma_id, data, conteudo, criado_por) VALUES (:turma_id, :data, :conteudo, :criado_por)");
    $stmt_aula->bindParam(':turma_id', $turma_padrao_id);
    $stmt_aula->bindParam(':data', $data_aula);
    $stmt_aula->bindParam(':conteudo', $conteudo_aula);
    $stmt_aula->bindParam(':criado_por', $_SESSION['user_id']);
    $stmt_aula->execute();
    
    $success_message_aula = "Aula agendada com sucesso!";
    header('Location: dashboard_dinamico.php?message=' . urlencode($success_message_aula) . '&view=agendamento');
    exit();
}

// Get existing classes for the default class
require_once '../includes/connection.php';
$stmt_aulas = $con->prepare("
    SELECT a.*, d.nome as disciplina_nome, t.semestre 
    FROM Aula a 
    JOIN Turma t ON a.turma_id = t.id 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    WHERE a.criado_por = :professor_id AND a.turma_id = :turma_id 
    ORDER BY a.data DESC
");
$stmt_aulas->bindParam(':professor_id', $_SESSION['user_id']);
$stmt_aulas->bindParam(':turma_id', $turma_padrao_id);
$stmt_aulas->execute();
$aulas = $stmt_aulas->fetchAll(PDO::FETCH_ASSOC);

// Lógica para exibir mensagem de sucesso após redirecionamento (se for de aula)
if (isset($_GET['message']) && strpos($_GET['message'], 'Aula agendada') !== false) {
    $success_message = htmlspecialchars($_GET['message']);
}

$con = null;
require_once '../includes/header.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Dinâmico - Sistema Educacional</title>
    <link rel="stylesheet" href="css/principal.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary: hsl(0, 65%, 51%);
            --primary-rgb: 211, 75, 75;
            --accent: hsl(30, 40%, 85%);
            --background: hsl(30, 30%, 95%);
            --card-bg: hsl(0, 0%, 100%);
            --text-primary: hsl(0, 0%, 20%);
            --text-secondary: hsl(0, 0%, 40%);
            --text-inverse: hsl(0, 0%, 100%);
            --border: hsl(0, 0%, 85%);
            --muted: hsl(30, 20%, 90%);
            --success: hsl(142, 71%, 45%);
            --warning: hsl(38, 92%, 50%);
            --error: hsl(0, 65%, 51%);
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.15);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--background);
            color: var(--text-primary);
            line-height: 1.6;
        }

        /* Animações */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* Layout Principal */
        .dynamic-dashboard-container {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            padding: 30px;
            max-width: 1600px;
            margin: 0 auto;
            animation: fadeIn 0.6s ease-out;
        }

        /* Formulário de Agendamento */
        .form-agendamento-wrapper {
            flex: 1 1 45%;
            min-width: 380px;
            background: var(--card-bg);
            padding: 30px;
            border-radius: 16px;
            box-shadow: var(--shadow-md);
            display: none;
            opacity: 0;
            transform: translateX(-30px);
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid var(--border);
        }

        .form-agendamento-wrapper.active {
            display: block;
            opacity: 1;
            transform: translateX(0);
            animation: slideInLeft 0.5s ease-out;
        }

        /* Calendário e Cronograma */
        .calendar-cronograma-wrapper {
            flex: 1 1 50%;
            min-width: 420px;
            background: var(--card-bg);
            padding: 30px;
            border-radius: 16px;
            box-shadow: var(--shadow-md);
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid var(--border);
            animation: slideInRight 0.5s ease-out;
        }

        .calendar-cronograma-wrapper.expanded {
            flex: 1 1 100%;
        }

        .calendar-cronograma-wrapper.shrunk {
            flex: 1 1 50%;
        }

        /* Abas de Formulário */
        .form-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            border-bottom: 2px solid var(--border);
        }

        .tab-button {
            flex: 1;
            padding: 14px 20px;
            background: transparent;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
            color: var(--text-secondary);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .tab-button::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 3px;
            background: var(--primary);
            transform: translateX(-50%);
            transition: width 0.3s ease;
        }

        .tab-button:hover {
            color: var(--primary);
            background: var(--muted);
        }

        .tab-button.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .tab-button.active::before {
            width: 100%;
        }

        /* Conteúdo das Abas */
        .form-tab-content {
            display: none;
            animation: fadeIn 0.4s ease-out;
        }

        .form-tab-content.active {
            display: block;
        }

        /* Seções do Formulário */
        .form-section h2 {
            color: var(--primary);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 700;
        }

        .form-section h2 i {
            font-size: 28px;
        }

        /* Grupos de Formulário */
        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
            transition: color 0.3s ease;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 15px;
            background-color: var(--background);
            color: var(--text-primary);
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(var(--primary-rgb), 0.15);
            background-color: var(--card-bg);
            transform: translateY(-2px);
        }

        .form-group input:hover,
        .form-group textarea:hover,
        .form-group select:hover {
            border-color: var(--primary);
        }

        /* Validação de Formulário */
        .form-group input.invalid,
        .form-group textarea.invalid,
        .form-group select.invalid {
            border-color: var(--error);
            animation: shake 0.3s ease;
        }

        .form-group input.valid,
        .form-group textarea.valid,
        .form-group select.valid {
            border-color: var(--success);
        }

        .form-group .error-message {
            color: var(--error);
            font-size: 12px;
            margin-top: 6px;
            display: none;
            animation: fadeIn 0.3s ease;
        }

        .form-group .error-message.show {
            display: block;
        }

        .form-group .char-count {
            position: absolute;
            right: 12px;
            bottom: 12px;
            font-size: 12px;
            color: var(--text-secondary);
            background: var(--card-bg);
            padding: 2px 6px;
            border-radius: 4px;
        }

        /* Botões */
        .form-actions {
            margin-top: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 14px 28px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn:hover::before {
            width: 300px;
            height: 300px;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--text-inverse);
            box-shadow: var(--shadow-sm);
        }

        .btn-primary:hover {
            background: hsl(0, 65%, 45%);
            box-shadow: var(--shadow-md);
            transform: translateY(-2px);
        }

        .btn-primary:active {
            transform: translateY(0);
            box-shadow: var(--shadow-sm);
        }

        .btn-secondary {
            background: var(--muted);
            color: var(--text-primary);
            box-shadow: var(--shadow-sm);
        }

        .btn-secondary:hover {
            background: hsl(30, 20%, 80%);
            box-shadow: var(--shadow-md);
            transform: translateY(-2px);
        }

        .btn-delete {
            background: var(--error);
            color: var(--text-inverse);
            padding: 8px 16px;
            font-size: 13px;
        }

        .btn-delete:hover {
            background: hsl(0, 65%, 45%);
        }

        /* Alertas */
        .alert {
            padding: 18px 24px;
            margin-bottom: 25px;
            border-radius: 12px;
            text-align: center;
            font-weight: 500;
            animation: fadeIn 0.5s ease-out;
            box-shadow: var(--shadow-sm);
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            border: 2px solid #c3e6cb;
        }

        /* Seção de Atividades */
        .atividades-section,
        .aulas-section {
            margin-top: 35px;
            animation: fadeIn 0.6s ease-out;
        }

        .atividades-section h2,
        .aulas-section h2 {
            color: var(--primary);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 22px;
        }

        .no-activities {
            text-align: center;
            padding: 50px 20px;
            color: var(--text-secondary);
        }

        .no-activities i {
            font-size: 64px;
            margin-bottom: 15px;
            opacity: 0.3;
        }

        .atividades-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .atividade-card {
            background: var(--background);
            border: 2px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
            animation: fadeIn 0.4s ease-out;
        }

        .atividade-card:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow-md);
            transform: translateY(-3px);
        }

        .atividade-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            gap: 15px;
        }

        .atividade-header h3 {
            color: var(--text-primary);
            font-size: 18px;
            font-weight: 600;
            flex: 1;
        }

        .tipo-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .tipo-prova {
            background: hsl(0, 70%, 95%);
            color: hsl(0, 70%, 40%);
            border: 1px solid hsl(0, 70%, 85%);
        }

        .tipo-trabalho {
            background: hsl(210, 70%, 95%);
            color: hsl(210, 70%, 40%);
            border: 1px solid hsl(210, 70%, 85%);
        }

        .tipo-seminario {
            background: hsl(150, 70%, 95%);
            color: hsl(150, 70%, 35%);
            border: 1px solid hsl(150, 70%, 85%);
        }

        .tipo-exercicio {
            background: hsl(45, 70%, 95%);
            color: hsl(45, 70%, 35%);
            border: 1px solid hsl(45, 70%, 85%);
        }

        .tipo-projeto {
            background: hsl(280, 70%, 95%);
            color: hsl(280, 70%, 40%);
            border: 1px solid hsl(280, 70%, 85%);
        }

        .tipo-atividade {
            background: hsl(30, 70%, 95%);
            color: hsl(30, 70%, 40%);
            border: 1px solid hsl(30, 70%, 85%);
        }

        .tipo-aula {
            background: hsl(200, 70%, 95%);
            color: hsl(200, 70%, 40%);
            border: 1px solid hsl(200, 70%, 85%);
        }

        .atividade-info p {
            margin-bottom: 8px;
            color: var(--text-secondary);
            font-size: 14px;
        }

        .atividade-info strong {
            color: var(--text-primary);
            font-weight: 600;
        }

        /* Calendário */
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .month-selector {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .month-selector button {
            background: var(--primary);
            color: var(--text-inverse);
            border: none;
            padding: 10px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            font-weight: 600;
        }

        .month-selector button:hover {
            background: hsl(0, 65%, 45%);
            transform: scale(1.1);
        }

        .month-selector button:active {
            transform: scale(0.95);
        }

        .month-selector select {
            background: var(--background);
            color: var(--text-primary);
            border: 2px solid var(--border);
            padding: 10px 14px;
            border-radius: 8px;
            margin: 0 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .month-selector select:hover {
            border-color: var(--primary);
        }

        .month-selector select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.15);
        }

        .view-buttons {
            display: flex;
            gap: 10px;
        }

        .view-buttons button {
            background: var(--muted);
            color: var(--text-primary);
            border: 2px solid var(--border);
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .view-buttons button:hover {
            background: var(--accent);
            border-color: var(--primary);
        }

        .view-buttons button.active {
            background: var(--primary);
            color: var(--text-inverse);
            border-color: var(--primary);
        }

        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 8px;
            margin-top: 20px;
        }

        .calendar-day-header {
            font-weight: 700;
            text-align: center;
            padding: 12px 0;
            background: var(--muted);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .calendar-day {
            padding: 18px 8px;
            text-align: center;
            border-radius: 10px;
            background: var(--background);
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            min-height: 70px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            font-weight: 500;
            font-size: 15px;
            border: 2px solid transparent;
        }

        .calendar-day:hover {
            background: var(--accent);
            box-shadow: var(--shadow-md);
            transform: translateY(-3px) scale(1.05);
            border-color: var(--primary);
        }

        .calendar-day.has-tasks {
            background: linear-gradient(135deg, var(--background) 0%, hsl(0, 65%, 95%) 100%);
            font-weight: 700;
        }

        .calendar-day.has-tasks::after {
            content: "●";
            color: var(--primary);
            font-size: 20px;
            position: absolute;
            bottom: 8px;
            animation: pulse 2s infinite;
        }

        .calendar-day.selected {
            background: var(--primary);
            color: var(--text-inverse);
            font-weight: 700;
            box-shadow: var(--shadow-lg);
            transform: scale(1.1);
        }

        .calendar-day.selected:hover {
            transform: scale(1.1);
        }

        /* Modal de Tarefas */
        .task-modal {
            display: none;
            position: fixed;
            z-index: 1001;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.6);
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(5px);
            animation: fadeIn 0.3s ease;
        }

        .task-modal-content {
            background-color: var(--card-bg);
            margin: auto;
            padding: 35px;
            border: none;
            width: 90%;
            max-width: 550px;
            border-radius: 16px;
            position: relative;
            box-shadow: var(--shadow-lg);
            animation: slideInLeft 0.4s ease-out;
        }

        .close-modal {
            color: var(--text-secondary);
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .close-modal:hover {
            color: var(--primary);
            background: var(--muted);
            transform: rotate(90deg);
        }

        .task-form input,
        .task-form textarea {
            margin-bottom: 18px;
        }

        .task-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 25px;
        }

        .task-item {
            background: var(--background);
            border: 2px solid var(--border);
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 12px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            transition: all 0.3s ease;
            animation: fadeIn 0.4s ease-out;
        }

        .task-item:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow-md);
            transform: translateX(5px);
        }

        .task-item .task-title {
            font-weight: 700;
            color: var(--primary);
            font-size: 16px;
        }

        .task-item .task-actions {
            margin-top: 12px;
            text-align: right;
        }

        /* Loading Spinner */
        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsividade */
        @media (max-width: 1024px) {
            .dynamic-dashboard-container {
                padding: 20px;
                gap: 20px;
            }

            .form-agendamento-wrapper,
            .calendar-cronograma-wrapper {
                flex: 1 1 100%;
                min-width: unset;
            }

            .calendar-cronograma-wrapper.shrunk {
                flex: 1 1 100%;
            }
        }

        @media (max-width: 768px) {
            .dynamic-dashboard-container {
                padding: 15px;
            }

            .form-agendamento-wrapper,
            .calendar-cronograma-wrapper {
                padding: 20px;
            }

            .calendar {
                gap: 5px;
            }

            .calendar-day {
                min-height: 55px;
                padding: 12px 5px;
                font-size: 14px;
            }

            .calendar-header {
                flex-direction: column;
                align-items: stretch;
            }

            .month-selector,
            .view-buttons {
                justify-content: center;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }

            .atividade-header {
                flex-direction: column;
            }

            .tipo-badge {
                align-self: flex-start;
            }
        }

        @media (max-width: 480px) {
            .form-section h2 {
                font-size: 20px;
            }

            .calendar-day-header {
                font-size: 11px;
                padding: 8px 0;
            }

            .calendar-day {
                min-height: 45px;
                font-size: 13px;
            }

            .task-modal-content {
                padding: 25px;
            }
        }

        /* Tooltip */
        [data-tooltip] {
            position: relative;
        }

        [data-tooltip]::before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%) translateY(-5px);
            padding: 8px 12px;
            background: var(--text-primary);
            color: var(--text-inverse);
            border-radius: 6px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        [data-tooltip]:hover::before {
            opacity: 1;
            transform: translateX(-50%) translateY(-10px);
        }
    </style>
</head>
<body>
    <div class="main-content">
        <h1>Dashboard Dinâmico</h1>

        <?php if (isset($success_message) && $success_message): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="dynamic-dashboard-container">
            <div id="formAgendamentoWrapper" class="form-agendamento-wrapper">
                <div class="form-tabs">
                    <button class="tab-button active" onclick="showFormTab('atividade')">
                        <i class="fas fa-tasks"></i> Agendar Atividade
                    </button>
                    <button class="tab-button" onclick="showFormTab('aula')">
                        <i class="fas fa-chalkboard-teacher"></i> Agendar Aula
                    </button>
                </div>

                <div id="formAtividade" class="form-section form-tab-content active">
                    <h2><i class="fas fa-plus-circle"></i> Nova Atividade</h2>
                    <form method="POST" action="dashboard_dinamico.php" id="formNovaAtividade">
                        <input type="hidden" name="action" value="agendar_atividade">

                        <div class="form-group">
                            <label for="tipo">Tipo de Atividade:</label>
                            <select name="tipo" id="tipo" required>
                                <option value="">Selecione o tipo</option>
                                <option value="prova">📝 Prova</option>
                                <option value="trabalho">📚 Trabalho</option>
                                <option value="seminario">🎤 Seminário</option>
                                <option value="exercicio">✏️ Exercício</option>
                                <option value="projeto">🚀 Projeto</option>
                                <option value="atividade">📋 Atividade Geral</option>
                            </select>
                            <span class="error-message">Por favor, selecione um tipo de atividade</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="titulo">Título:</label>
                            <input type="text" name="titulo" id="titulo" required 
                                   placeholder="Ex: Prova de Matemática - Capítulo 3"
                                   maxlength="100">
                            <span class="char-count"><span id="tituloCount">0</span>/100</span>
                            <span class="error-message">O título deve ter entre 3 e 100 caracteres</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="data_atividade">Data da Atividade:</label>
                            <input type="date" name="data_atividade" id="data_atividade" required>
                            <span class="error-message">Por favor, selecione uma data válida</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="descricao">Descrição:</label>
                            <textarea name="descricao" id="descricao" rows="4" 
                                      placeholder="Descreva os detalhes da atividade, conteúdo a ser estudado, materiais necessários, etc."
                                      maxlength="500"></textarea>
                            <span class="char-count"><span id="descricaoCount">0</span>/500</span>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary" id="btnSubmitAtividade">
                                <i class="fas fa-save"></i> Agendar Atividade
                            </button>
                            <button type="reset" class="btn btn-secondary">
                                <i class="fas fa-eraser"></i> Limpar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="formAula" class="form-section form-tab-content">
                    <h2><i class="fas fa-chalkboard-teacher"></i> Nova Aula</h2>
                    <form method="POST" action="dashboard_dinamico.php" id="formNovaAula">
                        <input type="hidden" name="action" value="agendar_aula">

                        <div class="form-group">
                            <label for="data_aula">Data da Aula:</label>
                            <input type="date" name="data_aula" id="data_aula" required>
                            <span class="error-message">Por favor, selecione uma data válida</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="conteudo_aula">Conteúdo da Aula:</label>
                            <textarea name="conteudo_aula" id="conteudo_aula" rows="4" required
                                      placeholder="Descreva o conteúdo da aula."
                                      maxlength="500"></textarea>
                            <span class="char-count"><span id="conteudoCount">0</span>/500</span>
                            <span class="error-message">O conteúdo deve ter entre 5 e 500 caracteres</span>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary" id="btnSubmitAula">
                                <i class="fas fa-save"></i> Agendar Aula
                            </button>
                            <button type="reset" class="btn btn-secondary">
                                <i class="fas fa-eraser"></i> Limpar
                            </button>
                        </div>
                    </form>
                </div>

                <div class="atividades-section">
                    <h2><i class="fas fa-list"></i> Atividades Agendadas</h2>
                    <?php if (empty($atividades)): ?>
                        <div class="no-activities">
                            <i class="fas fa-calendar-plus"></i>
                            <p>Nenhuma atividade agendada ainda.</p>
                        </div>
                    <?php else: ?>
                        <div class="atividades-list">
                            <?php foreach ($atividades as $atividade): ?>
                                <div class="atividade-card" data-tooltip="Clique para ver detalhes">
                                    <div class="atividade-header">
                                        <h3><?php echo htmlspecialchars($atividade["titulo"]); ?></h3>
                                        <span class="tipo-badge tipo-<?php echo $atividade["tipo"]; ?>">
                                            <?php echo ucfirst($atividade["tipo"]); ?>
                                        </span>
                                    </div>
                                    <div class="atividade-info">
                                        <p><strong>📚 Disciplina:</strong> <?php echo $atividade["disciplina_nome"] . " - " . $atividade["semestre"]; ?> (Turma Única)</p>
                                        <p><strong>📅 Data:</strong> <?php echo date("d/m/Y", strtotime($atividade["data_atividade"])); ?></p>
                                        <?php if ($atividade["descricao"]): ?>
                                            <p><strong>📝 Descrição:</strong> <?php echo htmlspecialchars($atividade["descricao"]); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="aulas-section">
                    <h2><i class="fas fa-book-open"></i> Aulas Agendadas</h2>
                    <?php if (empty($aulas)): ?>
                        <div class="no-activities">
                            <i class="fas fa-chalkboard"></i>
                            <p>Nenhuma aula agendada ainda.</p>
                        </div>
                    <?php else: ?>
                        <div class="atividades-list">
                            <?php foreach ($aulas as $aula): ?>
                                <div class="atividade-card" data-tooltip="Clique para ver detalhes">
                                    <div class="atividade-header">
                                        <h3><?php echo htmlspecialchars($aula["conteudo"]); ?></h3>
                                        <span class="tipo-badge tipo-aula">
                                            Aula
                                        </span>
                                    </div>
                                    <div class="atividade-info">
                                        <p><strong>📚 Disciplina:</strong> <?php echo $aula["disciplina_nome"] . " - " . $aula["semestre"]; ?> (Turma Única)</p>
                                        <p><strong>📅 Data:</strong> <?php echo date("d/m/Y", strtotime($aula["data"])); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div id="calendarCronogramaWrapper" class="calendar-cronograma-wrapper expanded">
                <h1>📅 Cronograma Personalizado</h1>
                
                <div class="calendar-container">
                    <div class="calendar-header">
                        <div class="month-selector">
                            <button onclick="cronogramaModule.previousMonth()" data-tooltip="Mês anterior">❮</button>
                            <select id="monthSelect" onchange="cronogramaModule.changeMonth()">
                                <option value="0">Janeiro</option>
                                <option value="1">Fevereiro</option>
                                <option value="2">Março</option>
                                <option value="3">Abril</option>
                                <option value="4">Maio</option>
                                <option value="5">Junho</option>
                                <option value="6">Julho</option>
                                <option value="7">Agosto</option>
                                <option value="8">Setembro</option>
                                <option value="9">Outubro</option>
                                <option value="10">Novembro</option>
                                <option value="11">Dezembro</option>
                            </select>
                            <select id="yearSelect" onchange="cronogramaModule.changeYear()">
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                            </select>
                            <button onclick="cronogramaModule.nextMonth()" data-tooltip="Próximo mês">❯</button>
                        </div>
                        
                        <div class="view-buttons">
                            <button id="calendarBtn" class="active" onclick="cronogramaModule.showCalendarView()">
                                <i class="fas fa-calendar-alt"></i> Calendário
                            </button>
                            <button id="tasksBtn" onclick="cronogramaModule.showTasksView()">
                                <i class="fas fa-tasks"></i> Tarefas Pendentes
                            </button>
                        </div>
                    </div>

                    <div id="calendarView" class="active-view">
                        <div class="calendar">
                            <div class="calendar-day-header">Dom</div>
                            <div class="calendar-day-header">Seg</div>
                            <div class="calendar-day-header">Ter</div>
                            <div class="calendar-day-header">Qua</div>
                            <div class="calendar-day-header">Qui</div>
                            <div class="calendar-day-header">Sex</div>
                            <div class="calendar-day-header">Sáb</div>
                        </div>
                    </div>

                    <div id="pendingTasks" style="display: none;">
                        <h3><i class="fas fa-clipboard-list"></i> Tarefas Pendentes</h3>
                        <div id="tasksList">
                            <!-- Tarefas serão carregadas aqui -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para adicionar/editar tarefas -->
    <div id="taskModal" class="task-modal">
        <div class="task-modal-content">
            <button class="close-modal" onclick="cronogramaModule.closeModal()">&times;</button>
            <h3 id="modalTitle"><i class="fas fa-plus-circle"></i> Adicionar Tarefa</h3>
            <form class="task-form" id="taskForm">
                <input type="text" id="taskTitle" placeholder="Título da tarefa" required>
                <textarea id="taskDescription" placeholder="Descrição" rows="3"></textarea>
                <input type="date" id="taskDate" required>
                <input type="time" id="taskTime">
                <div class="task-buttons">
                    <button type="button" class="btn btn-secondary" onclick="cronogramaModule.closeModal()">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                    <button type="button" class="btn btn-primary" onclick="cronogramaModule.saveTask()">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Função para alternar entre abas do formulário
        function showFormTab(tabName) {
            const tabs = document.querySelectorAll('.tab-button');
            const contents = document.querySelectorAll('.form-tab-content');
            
            tabs.forEach(tab => tab.classList.remove('active'));
            contents.forEach(content => content.classList.remove('active'));
            
            event.target.classList.add('active');
            document.getElementById('form' + tabName.charAt(0).toUpperCase() + tabName.slice(1)).classList.add('active');
        }

        // Função para alternar o layout dinâmico
        function toggleDynamicLayout(showForm, selectedDate = null) {
            const formWrapper = document.getElementById('formAgendamentoWrapper');
            const calendarWrapper = document.getElementById('calendarCronogramaWrapper');
            const dataAtividadeInput = document.getElementById('data_atividade');
            const dataAulaInput = document.getElementById('data_aula');

            if (showForm) {
                formWrapper.classList.add('active');
                calendarWrapper.classList.remove('expanded');
                calendarWrapper.classList.add('shrunk');
                
                if (selectedDate) {
                    const dateString = selectedDate.toISOString().split('T')[0];
                    if (dataAtividadeInput) dataAtividadeInput.value = dateString;
                    if (dataAulaInput) dataAulaInput.value = dateString;
                }
            } else {
                formWrapper.classList.remove('active');
                calendarWrapper.classList.remove('shrunk');
                calendarWrapper.classList.add('expanded');
            }
        }

        // Validação de formulários em tempo real
        document.addEventListener('DOMContentLoaded', function() {
            // Configurar data mínima
            const dataAtividadeInput = document.getElementById('data_atividade');
            const dataAulaInput = document.getElementById('data_aula');
            const today = new Date().toISOString().split('T')[0];
            
            if (dataAtividadeInput) dataAtividadeInput.min = today;
            if (dataAulaInput) dataAulaInput.min = today;

            // Contador de caracteres
            const setupCharCounter = (inputId, counterId) => {
                const input = document.getElementById(inputId);
                const counter = document.getElementById(counterId);
                if (input && counter) {
                    input.addEventListener('input', function() {
                        counter.textContent = this.value.length;
                    });
                }
            };

            setupCharCounter('titulo', 'tituloCount');
            setupCharCounter('descricao', 'descricaoCount');
            setupCharCounter('conteudo_aula', 'conteudoCount');

            // Validação em tempo real
            const validateField = (field, validator) => {
                field.addEventListener('blur', function() {
                    const errorMsg = this.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('error-message')) {
                        if (validator(this)) {
                            this.classList.remove('invalid');
                            this.classList.add('valid');
                            errorMsg.classList.remove('show');
                        } else {
                            this.classList.remove('valid');
                            this.classList.add('invalid');
                            errorMsg.classList.add('show');
                        }
                    }
                });

                field.addEventListener('input', function() {
                    if (this.classList.contains('invalid')) {
                        const errorMsg = this.nextElementSibling;
                        if (errorMsg && errorMsg.classList.contains('error-message')) {
                            if (validator(this)) {
                                this.classList.remove('invalid');
                                this.classList.add('valid');
                                errorMsg.classList.remove('show');
                            }
                        }
                    }
                });
            };

            // Validadores
            const tituloInput = document.getElementById('titulo');
            if (tituloInput) {
                validateField(tituloInput, (field) => field.value.trim().length >= 3 && field.value.trim().length <= 100);
            }

            const tipoSelect = document.getElementById('tipo');
            if (tipoSelect) {
                validateField(tipoSelect, (field) => field.value !== '');
            }

            const conteudoAulaTextarea = document.getElementById('conteudo_aula');
            if (conteudoAulaTextarea) {
                validateField(conteudoAulaTextarea, (field) => field.value.trim().length >= 5 && field.value.trim().length <= 500);
            }

            // Validação de formulário completo
            const formAtividade = document.getElementById('formNovaAtividade');
            if (formAtividade) {
                formAtividade.addEventListener('submit', function(e) {
                    const titulo = document.getElementById('titulo');
                    const tipo = document.getElementById('tipo');
                    const dataAtividade = document.getElementById('data_atividade');

                    let isValid = true;

                    if (!titulo.value.trim() || titulo.value.trim().length < 3) {
                        titulo.classList.add('invalid');
                        isValid = false;
                    }

                    if (!tipo.value) {
                        tipo.classList.add('invalid');
                        isValid = false;
                    }

                    if (!dataAtividade.value) {
                        dataAtividade.classList.add('invalid');
                        isValid = false;
                    }

                    if (!isValid) {
                        e.preventDefault();
                        alert('Por favor, preencha todos os campos obrigatórios corretamente.');
                    } else {
                        const btn = document.getElementById('btnSubmitAtividade');
                        btn.innerHTML = '<span class="loading-spinner"></span> Agendando...';
                        btn.disabled = true;
                    }
                });
            }

            const formAula = document.getElementById('formNovaAula');
            if (formAula) {
                formAula.addEventListener('submit', function(e) {
                    const dataAula = document.getElementById('data_aula');
                    const conteudoAula = document.getElementById('conteudo_aula');

                    let isValid = true;

                    if (!dataAula.value) {
                        dataAula.classList.add('invalid');
                        isValid = false;
                    }

                    if (!conteudoAula.value.trim() || conteudoAula.value.trim().length < 5) {
                        conteudoAula.classList.add('invalid');
                        isValid = false;
                    }

                    if (!isValid) {
                        e.preventDefault();
                        alert('Por favor, preencha todos os campos obrigatórios corretamente.');
                    } else {
                        const btn = document.getElementById('btnSubmitAula');
                        btn.innerHTML = '<span class="loading-spinner"></span> Agendando...';
                        btn.disabled = true;
                    }
                });
            }

            // Animação de entrada para cards
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            document.querySelectorAll('.atividade-card').forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'all 0.5s ease-out';
                observer.observe(card);
            });
        });

        // Módulo de Cronograma
        const cronogramaModule = (() => {
            let currentCronogramaDate = new Date();
            let cronogramaTasks = JSON.parse(localStorage.getItem('cronogramaTasks')) || [];
            let selectedDayElement = null;

            function generateCalendar() {
                const calendar = document.querySelector('#calendarCronogramaWrapper .calendar');
                if (!calendar) return;
                
                const year = currentCronogramaDate.getFullYear();
                const month = currentCronogramaDate.getMonth();
                
                document.querySelector('#calendarCronogramaWrapper #monthSelect').value = month;
                document.querySelector('#calendarCronogramaWrapper #yearSelect').value = year;
                
                const dayElements = calendar.querySelectorAll('.calendar-day');
                dayElements.forEach(el => el.remove());
                
                const firstDay = new Date(year, month, 1);
                const lastDay = new Date(year, month + 1, 0);
                const startDate = new Date(firstDay);
                startDate.setDate(startDate.getDate() - firstDay.getDay());
                
                for (let i = 0; i < 42; i++) {
                    const day = new Date(startDate);
                    day.setDate(startDate.getDate() + i);
                    
                    const dayElement = document.createElement('div');
                    dayElement.className = 'calendar-day';
                    dayElement.textContent = day.getDate();
                    
                    if (day.getMonth() !== month) {
                        dayElement.style.opacity = '0.3';
                    }
                    
                    const dayTasks = cronogramaTasks.filter(task => {
                        const taskDate = new Date(task.date);
                        return taskDate.toDateString() === day.toDateString();
                    });
                    
                    if (dayTasks.length > 0) {
                        dayElement.classList.add('has-tasks');
                        dayElement.setAttribute('data-tooltip', `${dayTasks.length} tarefa(s)`);
                    }
                    
                    // Destacar dia atual
                    const today = new Date();
                    if (day.toDateString() === today.toDateString()) {
                        dayElement.style.border = '2px solid var(--primary)';
                        dayElement.style.fontWeight = '700';
                    }
                    
                    dayElement.onclick = () => {
                        if (selectedDayElement) {
                            selectedDayElement.classList.remove('selected');
                        }
                        dayElement.classList.add('selected');
                        selectedDayElement = dayElement;
                        toggleDynamicLayout(true, day);
                    };
                    
                    calendar.appendChild(dayElement);
                }
            }

            function openTaskModal(date) {
                document.getElementById('taskModal').style.display = 'flex';
                document.getElementById('taskDate').value = date.toISOString().split('T')[0];
            }

            function closeModal() {
                document.getElementById('taskModal').style.display = 'none';
                document.getElementById('taskTitle').value = '';
                document.getElementById('taskDescription').value = '';
                document.getElementById('taskTime').value = '';
            }

            function saveTask() {
                const title = document.getElementById('taskTitle').value;
                const description = document.getElementById('taskDescription').value;
                const date = document.getElementById('taskDate').value;
                const time = document.getElementById('taskTime').value;
                
                if (!title || !date) {
                    alert('Por favor, preencha pelo menos o título e a data.');
                    return;
                }
                
                const task = {
                    id: Date.now(),
                    title,
                    description,
                    date,
                    time
                };
                
                cronogramaTasks.push(task);
                localStorage.setItem('cronogramaTasks', JSON.stringify(cronogramaTasks));
                
                closeModal();
                generateCalendar();
                updateTasksList();
                
                // Feedback visual
                const successMsg = document.createElement('div');
                successMsg.className = 'alert alert-success';
                successMsg.textContent = 'Tarefa adicionada com sucesso!';
                successMsg.style.position = 'fixed';
                successMsg.style.top = '20px';
                successMsg.style.right = '20px';
                successMsg.style.zIndex = '9999';
                document.body.appendChild(successMsg);
                
                setTimeout(() => {
                    successMsg.style.opacity = '0';
                    setTimeout(() => successMsg.remove(), 300);
                }, 3000);
            }

            function updateTasksList() {
                const tasksList = document.querySelector('#calendarCronogramaWrapper #tasksList');
                if (!tasksList) return;
                tasksList.innerHTML = '';
                
                if (cronogramaTasks.length === 0) {
                    tasksList.innerHTML = '<div class="no-activities"><i class="fas fa-tasks"></i><p>Nenhuma tarefa pendente.</p></div>';
                    return;
                }
                
                cronogramaTasks.sort((a, b) => new Date(a.date) - new Date(b.date));
                
                cronogramaTasks.forEach(task => {
                    const taskElement = document.createElement('div');
                    taskElement.className = 'task-item';
                    taskElement.innerHTML = `
                        <div class="task-title">${task.title}</div>
                        <div>${task.description || 'Sem descrição'}</div>
                        <div>📅 Data: ${new Date(task.date).toLocaleDateString('pt-BR')}</div>
                        ${task.time ? `<div>🕐 Horário: ${task.time}</div>` : ''}
                        <div class="task-actions">
                            <button class="btn btn-delete" onclick="cronogramaModule.deleteTask(${task.id})">
                                <i class="fas fa-trash"></i> Excluir
                            </button>
                        </div>
                    `;
                    tasksList.appendChild(taskElement);
                });
            }

            function deleteTask(taskId) {
                if (confirm('Tem certeza que deseja excluir esta tarefa?')) {
                    cronogramaTasks = cronogramaTasks.filter(task => task.id !== taskId);
                    localStorage.setItem('cronogramaTasks', JSON.stringify(cronogramaTasks));
                    generateCalendar();
                    updateTasksList();
                }
            }

            function showCalendarView() {
                document.getElementById('calendarView').style.display = 'grid';
                document.getElementById('pendingTasks').style.display = 'none';
                document.getElementById('calendarBtn').classList.add('active');
                document.getElementById('tasksBtn').classList.remove('active');
            }

            function showTasksView() {
                document.getElementById('calendarView').style.display = 'none';
                document.getElementById('pendingTasks').style.display = 'block';
                document.getElementById('calendarBtn').classList.remove('active');
                document.getElementById('tasksBtn').classList.add('active');
                updateTasksList();
            }

            function previousMonth() {
                currentCronogramaDate.setMonth(currentCronogramaDate.getMonth() - 1);
                generateCalendar();
            }

            function nextMonth() {
                currentCronogramaDate.setMonth(currentCronogramaDate.getMonth() + 1);
                generateCalendar();
            }

            function changeMonth() {
                const month = parseInt(document.getElementById('monthSelect').value);
                currentCronogramaDate.setMonth(month);
                generateCalendar();
            }

            function changeYear() {
                const year = parseInt(document.getElementById('yearSelect').value);
                currentCronogramaDate.setFullYear(year);
                generateCalendar();
            }

            // Inicializar
            document.addEventListener('DOMContentLoaded', function() {
                generateCalendar();
                updateTasksList();
            });

            return {
                generateCalendar,
                openTaskModal,
                closeModal,
                saveTask,
                deleteTask,
                showCalendarView,
                showTasksView,
                previousMonth,
                nextMonth,
                changeMonth,
                changeYear
            };
        })();

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('taskModal');
            if (event.target === modal) {
                cronogramaModule.closeModal();
            }
        };

        // Atalhos de teclado
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                cronogramaModule.closeModal();
            }
        });
    </script>
</body>
</html>