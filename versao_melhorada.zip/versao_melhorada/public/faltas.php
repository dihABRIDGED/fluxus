<?php
session_start();

// Check if user is logged in and is a student
if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true || $_SESSION["user_type"] !== "aluno") {
    header("Location: ../index.php");
    exit();
}

require_once '../includes/connection.php';
require_once '../includes/header.php';

// Fetch student absences from the database
$aluno_id = $_SESSION["user_id"]; // Assuming user_id is stored in session

// Query para buscar todas as aulas relacionadas às disciplinas do aluno e o status de frequência
$stmt = $con->prepare("
    SELECT
        a.id as aula_id,
        a.data,
        d.nome AS disciplina,
        a.conteudo,
        IFNULL(f.presente, 0) AS presente -- Use IFNULL para aulas sem registro de frequência (considerar como falta)
    FROM
        matricula m
    JOIN
        disciplina d ON m.disciplina_id = d.id
    JOIN
        aula a ON a.turma_id = d.id -- Relaciona aulas à disciplina através de turma_id, que é o id da disciplina
    LEFT JOIN
        frequencia f ON f.aula_id = a.id AND f.aluno_id = m.aluno_id
    WHERE
        m.aluno_id = :aluno_id
    ORDER BY
        a.data DESC, d.nome ASC
");
$stmt->bindParam(':aluno_id', $aluno_id, PDO::PARAM_INT);
$stmt->execute();
$aulas_aluno = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate statistics
$total_aulas = 0;
$total_presencas = 0;
$total_faltas = 0;
$disciplinas_stats = [];
$monthly_stats = [];

foreach ($aulas_aluno as $aula) {
    $total_aulas++;
    $disciplina = $aula['disciplina'];
    $mes = date('Y-m', strtotime($aula['data']));
    $mes_nome = date('M/Y', strtotime($aula['data']));
    
    // Stats por disciplina
    if (!isset($disciplinas_stats[$disciplina])) {
        $disciplinas_stats[$disciplina] = ['presencas' => 0, 'faltas' => 0, 'total' => 0];
    }
    
    // Stats por mês
    if (!isset($monthly_stats[$mes])) {
        $monthly_stats[$mes] = ['presencas' => 0, 'faltas' => 0, 'total' => 0, 'nome' => $mes_nome];
    }
    
    $disciplinas_stats[$disciplina]['total']++;
    $monthly_stats[$mes]['total']++;
    
    if ($aula['presente']) {
        $total_presencas++;
        $disciplinas_stats[$disciplina]['presencas']++;
        $monthly_stats[$mes]['presencas']++;
    } else {
        $total_faltas++;
        $disciplinas_stats[$disciplina]['faltas']++;
        $monthly_stats[$mes]['faltas']++;
    }
}

$frequencia_geral = ($total_aulas > 0) ? round(($total_presencas / $total_aulas) * 100) : 100;

// Determinar status da frequência
$status_frequencia = 'excellent';
if ($frequencia_geral < 75) $status_frequencia = 'critical';
elseif ($frequencia_geral < 85) $status_frequencia = 'warning';
elseif ($frequencia_geral < 95) $status_frequencia = 'good';

// Data para gráfico de pizza
$chart_data_pizza = [
    'labels' => ['Presenças', 'Faltas'],
    'datasets' => [
        [
            'data' => [$total_presencas, $total_faltas],
            'backgroundColor' => ['#4CAF50', '#F44336'],
            'hoverBackgroundColor' => ['#66BB6A', '#E57373'],
            'borderWidth' => 3,
            'borderColor' => '#1a1a1a'
        ]
    ]
];

// Data para gráfico de barras por disciplina
$disciplinas_labels = array_keys($disciplinas_stats);
$disciplinas_presencas = [];
$disciplinas_faltas = [];
$disciplinas_percentuais = [];

foreach ($disciplinas_stats as $disciplina => $stats) {
    $disciplinas_presencas[] = $stats['presencas'];
    $disciplinas_faltas[] = $stats['faltas'];
    $percentual = ($stats['total'] > 0) ? round(($stats['presencas'] / $stats['total']) * 100) : 100;
    $disciplinas_percentuais[] = $percentual;
}

$chart_data_barras = [
    'labels' => $disciplinas_labels,
    'datasets' => [
        [
            'label' => 'Presenças',
            'data' => $disciplinas_presencas,
            'backgroundColor' => '#4CAF50',
            'borderColor' => '#1a1a1a',
            'borderWidth' => 2
        ],
        [
            'label' => 'Faltas',
            'data' => $disciplinas_faltas,
            'backgroundColor' => '#F44336',
            'borderColor' => '#1a1a1a',
            'borderWidth' => 2
        ]
    ]
];

// Data para gráfico de linha temporal
ksort($monthly_stats);
$monthly_labels = [];
$monthly_percentuais = [];

foreach ($monthly_stats as $mes => $stats) {
    $monthly_labels[] = $stats['nome'];
    $percentual = ($stats['total'] > 0) ? round(($stats['presencas'] / $stats['total']) * 100) : 100;
    $monthly_percentuais[] = $percentual;
}

$chart_data_linha = [
    'labels' => $monthly_labels,
    'datasets' => [
        [
            'label' => 'Frequência (%)',
            'data' => $monthly_percentuais,
            'borderColor' => '#2196F3',
            'backgroundColor' => 'rgba(33, 150, 243, 0.1)',
            'borderWidth' => 3,
            'fill' => true,
            'tension' => 0.4,
            'pointBackgroundColor' => '#2196F3',
            'pointBorderColor' => '#1a1a1a',
            'pointBorderWidth' => 2,
            'pointRadius' => 6
        ]
    ]
];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Faltas - Sistema Maio de 68</title>
    <link rel="stylesheet" href="css/principal.css">
    <link rel="stylesheet" href="css/graficos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Estilos específicos para a página de faltas */
        .main-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
            background: var(--background);
            min-height: 100vh;
        }

        .page-title {
            font-family: 'Bebas Neue', sans-serif;
            font-size: clamp(2.5rem, 5vw, 3.5rem);
            color: var(--primary);
            text-align: center;
            margin-bottom: 40px;
            letter-spacing: 2px;
            text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .page-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: repeating-linear-gradient(
                45deg,
                var(--primary),
                var(--primary) 10px,
                var(--accent) 10px,
                var(--accent) 20px
            );
        }

        .frequencia-resumo {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 30px;
            text-align: center;
            box-shadow: 
                0 4px 6px rgba(0, 0, 0, 0.1),
                0 10px 20px rgba(0, 0, 0, 0.15),
                0 0 0 3px var(--border);
            transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: repeating-linear-gradient(
                45deg,
                var(--primary),
                var(--primary) 8px,
                var(--accent) 8px,
                var(--accent) 16px
            );
        }

        .card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 
                0 15px 30px rgba(0, 0, 0, 0.2),
                0 20px 40px rgba(0, 0, 0, 0.15),
                0 0 0 4px var(--primary);
        }

        .card h3 {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.4rem;
            color: var(--accent);
            margin-bottom: 15px;
            letter-spacing: 1px;
        }

        .card h3 i {
            color: var(--primary);
            margin-right: 8px;
        }

        .numero-destaque {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 10px;
            text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.1);
        }

        .card p {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .charts-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 40px;
        }

        .charts-container-full {
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
            margin-bottom: 40px;
        }

        .chart-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 
                0 4px 6px rgba(0, 0, 0, 0.1),
                0 10px 20px rgba(0, 0, 0, 0.15),
                0 0 0 3px var(--border);
            position: relative;
            overflow: hidden;
        }

        .chart-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: repeating-linear-gradient(
                45deg,
                var(--secondary),
                var(--secondary) 8px,
                var(--accent) 8px,
                var(--accent) 16px
            );
        }

        .chart-card h2 {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.8rem;
            color: var(--accent);
            margin-bottom: 20px;
            letter-spacing: 1px;
            text-align: center;
        }

        .chart-card h2 i {
            color: var(--secondary);
            margin-right: 8px;
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        .chart-container-tall {
            position: relative;
            height: 400px;
        }

        .tabela-container {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 
                0 4px 6px rgba(0, 0, 0, 0.1),
                0 10px 20px rgba(0, 0, 0, 0.15),
                0 0 0 3px var(--border);
            position: relative;
            overflow: hidden;
        }

        .tabela-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: repeating-linear-gradient(
                45deg,
                var(--primary),
                var(--primary) 8px,
                var(--accent) 8px,
                var(--accent) 16px
            );
        }

        .tabela-container h2 {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 2rem;
            color: var(--accent);
            margin-bottom: 20px;
            letter-spacing: 1px;
        }

        .tabela-container h2 i {
            color: var(--primary);
            margin-right: 8px;
        }

        .tabela-frequencia {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .tabela-frequencia thead {
            background: var(--accent);
            color: var(--text-inverse);
        }

        .tabela-frequencia th,
        .tabela-frequencia td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--muted);
        }

        .tabela-frequencia th {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.1rem;
            letter-spacing: 1px;
        }

        .tabela-frequencia tbody tr:hover {
            background: var(--muted);
            transform: scale(1.01);
            transition: all 0.2s ease;
        }

        .status-presente {
            color: #4CAF50;
            font-weight: 600;
        }

        .status-ausente {
            color: #F44336;
            font-weight: 600;
        }

        .status-presente i,
        .status-ausente i {
            margin-right: 5px;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
            
            .frequencia-resumo {
                grid-template-columns: 1fr;
            }
            
            .tabela-frequencia {
                font-size: 0.9rem;
            }
            
            .tabela-frequencia th,
            .tabela-frequencia td {
                padding: 10px;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 20px 10px;
            }
            
            .card {
                padding: 20px;
            }
            
            .chart-card {
                padding: 20px;
            }
            
            .tabela-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="main-content">
    <h1 class="page-title">
        <i class="fas fa-chart-line"></i>
        Controle de Faltas
    </h1>
    
    <div class="frequencia-resumo">
        <div class="card">
            <div class="performance-indicator <?php echo $status_frequencia; ?>"></div>
            <h3><i class="fas fa-chart-pie"></i> Frequência Geral</h3>
            <div class="numero-destaque"><?php echo $frequencia_geral; ?>%</div>
            <p>Presença nas aulas</p>
            <div class="status-badge <?php echo $status_frequencia; ?>">
                <?php 
                switch($status_frequencia) {
                    case 'excellent': echo 'Excelente'; break;
                    case 'good': echo 'Bom'; break;
                    case 'warning': echo 'Atenção'; break;
                    case 'critical': echo 'Crítico'; break;
                }
                ?>
            </div>
        </div>
        <div class="card">
            <h3><i class="fas fa-calendar-check"></i> Total de Presenças</h3>
            <div class="numero-destaque"><?php echo $total_presencas; ?></div>
            <p>Presenças registradas</p>
            <div class="trend-indicator trend-up">
                <i class="fas fa-arrow-up"></i> Positivo
            </div>
        </div>
        <div class="card">
            <h3><i class="fas fa-calendar-times"></i> Total de Faltas</h3>
            <div class="numero-destaque"><?php echo $total_faltas; ?></div>
            <p>Faltas registradas</p>
            <div class="trend-indicator <?php echo $total_faltas > $total_presencas ? 'trend-up' : 'trend-down'; ?>">
                <i class="fas fa-arrow-<?php echo $total_faltas > $total_presencas ? 'up' : 'down'; ?>"></i>
                <?php echo $total_faltas > $total_presencas ? 'Alto' : 'Controlado'; ?>
            </div>
        </div>
        <div class="card">
            <h3><i class="fas fa-chalkboard"></i> Total de Aulas</h3>
            <div class="numero-destaque"><?php echo $total_aulas; ?></div>
            <p>Aulas no total</p>
            <div class="trend-indicator trend-stable">
                <i class="fas fa-minus"></i> Total
            </div>
        </div>
    </div>

    <div class="charts-container">
        <div class="chart-card">
            <h2><i class="fas fa-chart-pie"></i> Distribuição Geral</h2>
            <div class="chart-container">
                <canvas id="frequenciaChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <h2><i class="fas fa-chart-bar"></i> Por Disciplina</h2>
            <div class="chart-container">
                <canvas id="disciplinasChart"></canvas>
            </div>
        </div>
    </div>

    <?php if (count($monthly_stats) > 1): ?>
    <div class="charts-container-full">
        <div class="chart-card">
            <h2><i class="fas fa-chart-line"></i> Evolução Temporal da Frequência</h2>
            <div class="chart-container-tall">
                <canvas id="temporalChart"></canvas>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="tabela-container">
        <h2><i class="fas fa-list"></i> Histórico Detalhado de Aulas</h2>
        <table class="tabela-frequencia">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Disciplina</th>
                    <th>Conteúdo</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($aulas_aluno) > 0): ?>
                    <?php foreach ($aulas_aluno as $aula): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($aula['data'])); ?></td>
                        <td><?php echo htmlspecialchars($aula['disciplina']); ?></td>
                        <td><?php echo htmlspecialchars($aula['conteudo']); ?></td>
                        <td>
                            <?php if ($aula['presente']): ?>
                                <span class="status-presente">
                                    <i class="fas fa-check"></i> Presente
                                </span>
                            <?php else: ?>
                                <span class="status-ausente">
                                    <i class="fas fa-times"></i> Ausente
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                            <i class="fas fa-info-circle"></i> Nenhuma aula registrada para suas disciplinas.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Configuração global dos gráficos
    Chart.defaults.font.family = "'Work Sans', sans-serif";
    Chart.defaults.color = '#1a1a1a';

    // Dados do PHP para os gráficos
    const chartDataPizza = <?php echo json_encode($chart_data_pizza); ?>;
    const chartDataBarras = <?php echo json_encode($chart_data_barras); ?>;
    const chartDataLinha = <?php echo json_encode($chart_data_linha); ?>;

    // Gráfico de pizza - Distribuição geral
    const ctxPizza = document.getElementById('frequenciaChart').getContext('2d');
    new Chart(ctxPizza, {
        type: 'doughnut',
        data: chartDataPizza,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14,
                            weight: '600'
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed * 100) / total).toFixed(1);
                            return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                        }
                    }
                }
            },
            cutout: '60%',
            animation: {
                animateRotate: true,
                duration: 2000
            }
        }
    });

    // Gráfico de barras - Por disciplina
    const ctxBarras = document.getElementById('disciplinasChart').getContext('2d');
    new Chart(ctxBarras, {
        type: 'bar',
        data: chartDataBarras,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14,
                            weight: '600'
                        }
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    ticks: {
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                }
            },
            animation: {
                duration: 2000,
                easing: 'easeOutQuart'
            }
        }
    });

    // Gráfico de linha temporal (se houver dados suficientes)
    <?php if (count($monthly_stats) > 1): ?>
    const ctxLinha = document.getElementById('temporalChart').getContext('2d');
    new Chart(ctxLinha, {
        type: 'line',
        data: chartDataLinha,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14,
                            weight: '600'
                        }
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    ticks: {
                        font: {
                            size: 12,
                            weight: '600'
                        },
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            },
            animation: {
                duration: 2500,
                easing: 'easeOutQuart'
            }
        }
    });
    <?php endif; ?>

    // Animações de entrada
    document.addEventListener('DOMContentLoaded', function() {
        // Animar números
        const numerosDestaque = document.querySelectorAll('.numero-destaque');
        numerosDestaque.forEach((numero, index) => {
            const valor = parseInt(numero.textContent);
            numero.textContent = '0';
            
            setTimeout(() => {
                let contador = 0;
                const incremento = valor / 50;
                const timer = setInterval(() => {
                    contador += incremento;
                    if (contador >= valor) {
                        contador = valor;
                        clearInterval(timer);
                    }
                    numero.textContent = Math.floor(contador) + (numero.textContent.includes('%') ? '%' : '');
                }, 30);
            }, 500 + (index * 200));
        });
    });
</script>

</body>
</html>