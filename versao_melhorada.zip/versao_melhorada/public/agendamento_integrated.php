<?php
/**
 * Página de Agendamento de Atividades - Professor (Integrada com TCC 2.0)
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

require_once '../includes/header.php';
session_start();

// Check if user is logged in and is a professor
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'professor') {
    header('Location: index.php');
    exit();
}

require_once '../includes/connection.php';

// Get professor's classes
$stmt = $con->prepare("
    SELECT t.id, d.nome as disciplina_nome, t.semestre 
    FROM Turma t 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    WHERE t.professor_id = :professor_id
");
$stmt->bindParam(':professor_id', $_SESSION['user_id']);
$stmt->execute();
$turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_POST) {
    $turma_id = $_POST['turma_id'];
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $data_atividade = $_POST['data_atividade'];
    $tipo = $_POST['tipo'];
    
    $stmt = $con->prepare("INSERT INTO Atividade (turma_id, titulo, descricao, data_atividade, tipo, criado_por) VALUES (:turma_id, :titulo, :descricao, :data_atividade, :tipo, :criado_por)");
    $stmt->bindParam(':turma_id', $turma_id);
    $stmt->bindParam(':titulo', $titulo);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':data_atividade', $data_atividade);
    $stmt->bindParam(':tipo', $tipo);
    $stmt->bindParam(':criado_por', $_SESSION['user_id']);
    $stmt->execute();
    
    $success_message = "Atividade agendada com sucesso!";
}

// Get existing activities
$stmt = $con->prepare("
    SELECT a.*, d.nome as disciplina_nome, t.semestre 
    FROM Atividade a 
    JOIN Turma t ON a.turma_id = t.id 
    JOIN Disciplina d ON t.disciplina_id = d.id 
    WHERE a.criado_por = :professor_id 
    ORDER BY a.data_atividade DESC
");
$stmt->bindParam(':professor_id', $_SESSION['user_id']);
$stmt->execute();
$atividades = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Agendamento - Sistema Educacional</title>
    <link rel="stylesheet" href="css/tcc2_style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header no estilo TCC 2.0 -->
    

    <div class="main-content">
        <h1>Agendar Atividade</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <div class="agendamento-container">
            <div class="form-section">
                <h2><i class="fas fa-plus-circle"></i> Nova Atividade</h2>
                <form method="POST" action="agendamento_integrated.php">
                    <div class="form-group">
                        <label for="turma_id">Turma:</label>
                        <select name="turma_id" id="turma_id" required>
                            <option value="">Selecione uma turma...</option>
                            <?php foreach ($turmas as $turma): ?>
                                <option value="<?php echo $turma['id']; ?>">
                                    <?php echo $turma['disciplina_nome'] . ' - ' . $turma['semestre']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo">Tipo de Atividade:</label>
                        <select name="tipo" id="tipo" required>
                            <option value="prova">Prova</option>
                            <option value="trabalho">Trabalho</option>
                            <option value="seminario">Seminário</option>
                            <option value="exercicio">Exercício</option>
                            <option value="projeto">Projeto</option>
                            <option value="atividade">Atividade Geral</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="titulo">Título:</label>
                        <input type="text" name="titulo" id="titulo" required placeholder="Ex: Prova de Matemática - Capítulo 3">
                    </div>
                    
                    <div class="form-group">
                        <label for="data_atividade">Data da Atividade:</label>
                        <input type="date" name="data_atividade" id="data_atividade" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="descricao">Descrição:</label>
                        <textarea name="descricao" id="descricao" rows="4" placeholder="Descreva os detalhes da atividade, conteúdo a ser estudado, materiais necessários, etc."></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Agendar Atividade
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-eraser"></i> Limpar
                        </button>
                    </div>
                </form>
            </div>
            
            <div class="atividades-section">
                <h2><i class="fas fa-list"></i> Atividades Agendadas</h2>
                <?php if (empty($atividades)): ?>
                    <div class="no-activities">
                        <i class="fas fa-calendar-plus"></i>
                        <p>Nenhuma atividade agendada ainda.</p>
                    </div>
                <?php else: ?>
                    <div class="atividades-list">
                        <?php foreach ($atividades as $atividade): ?>
                            <div class="atividade-card">
                                <div class="atividade-header">
                                    <h3><?php echo htmlspecialchars($atividade['titulo']); ?></h3>
                                    <span class="tipo-badge tipo-<?php echo $atividade['tipo']; ?>">
                                        <?php echo ucfirst($atividade['tipo']); ?>
                                    </span>
                                </div>
                                <div class="atividade-info">
                                    <p><strong>Disciplina:</strong> <?php echo $atividade['disciplina_nome'] . ' - ' . $atividade['semestre']; ?></p>
                                    <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($atividade['data_atividade'])); ?></p>
                                    <?php if ($atividade['descricao']): ?>
                                        <p><strong>Descrição:</strong> <?php echo htmlspecialchars($atividade['descricao']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
        .agendamento-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .form-section, .atividades-section {
            background: #222;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #333;
        }

        .form-section h2, .atividades-section h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: white;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 6px;
            font-size: 14px;
            background-color: #333;
            color: white;
            transition: border-color 0.3s;
        }

        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none;
            border-color: #c62828;
            box-shadow: 0 0 0 2px rgba(198, 40, 40, 0.25);
        }

        .form-actions {
            margin-top: 25px;
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .alert-success {
            background: #2d5a2d;
            color: #4CAF50;
            border: 1px solid #4CAF50;
        }

        .atividades-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .atividade-card {
            border: 1px solid #444;
            border-radius: 8px;
            padding: 20px;
            background: #333;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .atividade-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(198, 40, 40, 0.3);
        }

        .atividade-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .atividade-header h3 {
            margin: 0;
            color: white;
            font-size: 16px;
        }

        .tipo-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .tipo-prova { background: #c62828; color: white; }
        .tipo-trabalho { background: #28a745; color: white; }
        .tipo-seminario { background: #17a2b8; color: white; }
        .tipo-exercicio { background: #ffc107; color: #212529; }
        .tipo-projeto { background: #6f42c1; color: white; }
        .tipo-atividade { background: #6c757d; color: white; }

        .atividade-info p {
            margin: 8px 0;
            font-size: 14px;
            color: #ccc;
        }

        .no-activities {
            text-align: center;
            color: #666;
            padding: 60px;
        }

        .no-activities i {
            font-size: 3rem;
            color: #c62828;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {
            .agendamento-container {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }
    </style>

    <script>
        // Set minimum date to today
        document.getElementById('data_atividade').min = new Date().toISOString().split('T')[0];

        // Auto-focus on first input
        document.getElementById('turma_id').focus();
    </script>
</body>
</html>

<?php
$con = null;
?>

