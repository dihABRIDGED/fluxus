<?php
/**
 * Página de Chamada - Professor
 * Fluxus Project - Optimized Version com design TCC 2.0
 */

session_start();

// Check if user is logged in
if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true) {
    header("Location: index.php");
    exit();
}

require_once "../includes/connection.php"; // Adjusted path

$professor_id = $_SESSION["user_id"] ?? 5; // Assuming professor_id is in session, using 5 as default for testing

// Get professor's disciplines
$disciplinas = [];
// Now, a professor is associated with a discipline if they are the 'coordenador_id' of that discipline.
// Or if there's a direct link, which is not explicitly in the schema. Let's assume 'coordenador_id' for now.
// If a professor can teach a discipline without being the coordinator, the DB schema would need a 'professor_disciplina' table.
// For now, we'll get disciplines where the professor is the coordinator.
$sql_disciplinas = "SELECT id, nome FROM disciplina WHERE professor_id = ? ORDER BY nome";
$stmt_disciplinas = $con->prepare($sql_disciplinas);
$stmt_disciplinas->execute([$professor_id]);
$disciplinas = $stmt_disciplinas->fetchAll(PDO::FETCH_ASSOC);

$success_message = "";
$error_message = "";

// Handle form submission for attendance
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "register_attendance") {
    $disciplina_id_post = $_POST["disciplina_id"];
    $data = $_POST["data"];
    $conteudo = $_POST["conteudo"];
    $alunos_presentes = isset($_POST["presentes"]) ? $_POST["presentes"] : [];

    // With 'turma' table removed, an 'aula' is now directly associated with a 'disciplina'.
    // We need to insert one 'aula' record per discipline for the given professor.
    $con->beginTransaction();
    try {
        // Insert new aula record for the discipline
        // The 'aula' table still has 'turma_id'. This is a conflict.
        // Given the 'turma' table is removed, 'aula' table needs to be updated to 'disciplina_id'.
        // For now, I will insert a dummy 'turma_id' (e.g., 1) or assume the 'aula' table will be updated.
        // Since the user said 'só era pra ter uma turma', I'll use a fixed turma_id for now.
        // However, the ideal solution is to modify the 'aula' table to have 'disciplina_id' instead of 'turma_id'.
        // As I cannot modify the database schema, I will use a placeholder 'turma_id' (e.g., 1) and note this.
        
        // *** IMPORTANT: The 'aula' table still references 'turma_id'. If 'turma' table is gone, this will cause foreign key issues.
        // You need to either remove 'turma_id' from 'aula' and add 'disciplina_id', or re-evaluate the 'aula' table structure.
        // For now, I'm using a placeholder 'turma_id = 1' to make the code run, but this is NOT a correct solution.
        // Please update your 'aula' table to reference 'disciplina_id' instead of 'turma_id'.
        $dummy_turma_id = 1; // Placeholder. This needs to be addressed in your DB schema.

        $sql_insert_aula = "INSERT INTO aula (turma_id, data, conteudo, criado_por) VALUES (?, ?, ?, ?)";
        $stmt_insert_aula = $con->prepare($sql_insert_aula);
        $stmt_insert_aula->execute([$dummy_turma_id, $data, $conteudo, $professor_id]);
        $aula_id = $con->lastInsertId();

        // Get all students for the selected discipline (based on the new matricula structure)
        $alunos_da_disciplina = [];
        $sql_alunos_disciplina_para_aula = "SELECT u.id FROM usuario u 
                                            JOIN matricula m ON u.id = m.aluno_id 
                                            WHERE m.disciplina_id = ?"; // Using diciplina_id as per new SQL dump
        $stmt_alunos_disciplina_para_aula = $con->prepare($sql_alunos_disciplina_para_aula);
        $stmt_alunos_disciplina_para_aula->execute([$disciplina_id_post]);
        $alunos_da_disciplina_raw = $stmt_alunos_disciplina_para_aula->fetchAll(PDO::FETCH_ASSOC);
        foreach ($alunos_da_disciplina_raw as $aluno_row) {
            $alunos_da_disciplina[] = $aluno_row["id"];
        }

        // Insert attendance records for each student in this discipline
        foreach ($alunos_da_disciplina as $aluno_id) {
            $presente = in_array($aluno_id, $alunos_presentes) ? 1 : 0;
            $sql_insert_frequencia = "INSERT INTO frequencia (aula_id, aluno_id, presente) VALUES (?, ?, ?)";
            $stmt_insert_frequencia = $con->prepare($sql_insert_frequencia);
            $stmt_insert_frequencia->execute([$aula_id, $aluno_id, $presente]);
        }
        
        $con->commit();
        $success_message = "Chamada registrada com sucesso para a disciplina!";
    } catch (Exception $e) {
        $con->rollBack();
        $error_message = "Erro ao registrar chamada: " . $e->getMessage();
    }
}

// Get selected discipline students if disciplina_id is provided
$selected_disciplina_id = $_GET["disciplina_id"] ?? null;
$alunos_disciplina = [];
if ($selected_disciplina_id) {
    // Get all students for the selected discipline (based on the new matricula structure)
    $sql_alunos_disciplina = "SELECT DISTINCT u.id, u.nome FROM usuario u 
                                JOIN matricula m ON u.id = m.aluno_id 
                                WHERE m.disciplina_id = ? 
                                ORDER BY u.nome"; // Using diciplina_id as per new SQL dump
    $stmt_alunos_disciplina = $con->prepare($sql_alunos_disciplina);
    $stmt_alunos_disciplina->execute([$selected_disciplina_id]);
    $alunos_disciplina = $stmt_alunos_disciplina->fetchAll(PDO::FETCH_ASSOC);
}

require_once "../includes/header.php"; // Assuming header.php is in the same directory as connection.php
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Frequência</title>
    <link rel="stylesheet" href="./css/principal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
 
    <div class="main-content">
        <h1>Controle de Frequência por Disciplina</h1>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
       

        <!-- Visão Professor -->
        <div id="professorView" class="view-section active">
            <div class="chamada-container">
                <div class="step-card">
                    <h2><i class="fas fa-book"></i> 1. Selecione a Disciplina</h2>
                    <form method="GET" action="chamada.php">
                        <select name="disciplina_id" onchange="this.form.submit()" required>
                            <option value="">Selecione uma disciplina...</option>
                            <?php foreach ($disciplinas as $disciplina): ?>
                                <option value="<?php echo $disciplina["id"]; ?>" <?php echo $selected_disciplina_id == $disciplina["id"] ? "selected" : ""; ?>>
                                    <?php echo $disciplina["nome"]; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
                
                <?php if ($selected_disciplina_id && !empty($alunos_disciplina)): ?>
                <div class="step-card">
                    <h2><i class="fas fa-clipboard-check"></i> 2. Registrar Aula e Presença</h2>
                    <form method="POST" action="chamada.php">
                        <input type="hidden" name="action" value="register_attendance">
                        <input type="hidden" name="disciplina_id" value="<?php echo $selected_disciplina_id; ?>">
                        
                        <div class="aula-info">
                            <div class="form-group">
                                <label for="data">Data da Aula:</label>
                                <input type="date" name="data" id="data" value="<?php echo date("Y-m-d"); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="conteudo">Conteúdo da Aula:</label>
                                <textarea name="conteudo" id="conteudo" rows="3" placeholder="Descreva o conteúdo abordado na aula..."></textarea>
                            </div>
                        </div>
                        
                        <div class="lista-alunos">
                            <h3>Lista de Presença</h3>
                            <div class="alunos-grid">
                                <?php foreach ($alunos_disciplina as $aluno): ?>
                                <div class="aluno-item">
                                    <label class="checkbox-container">
                                        <input type="checkbox" name="presentes[]" value="<?php echo $aluno["id"]; ?>">
                                        <span class="checkmark"></span>
                                        <?php echo $aluno["nome"]; ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Registrar Chamada
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="marcarTodos()">
                                <i class="fas fa-check-double"></i> Marcar Todos
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="desmarcarTodos()">
                                <i class="fas fa-times"></i> Desmarcar Todos
                            </button>
                        </div>
                    </form>
                </div>
                <?php elseif ($selected_disciplina_id): ?>
                <div class="no-students">
                    <i class="fas fa-user-slash"></i>
                    <p>Nenhum aluno encontrado para esta disciplina.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        
    <script>
        function marcarTodos() {
            const checkboxes = document.querySelectorAll("input[type=\"checkbox\"][name^=\"presentes\"]");
            checkboxes.forEach(checkbox => checkbox.checked = true);
        }

        function desmarcarTodos() {
            const checkboxes = document.querySelectorAll("input[type=\"checkbox\"][name^=\"presentes\"]");
            checkboxes.forEach(checkbox => checkbox.checked = false);
        }
    </script>

    <style>
        .chamada-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .step-card {
            background: #222;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid #333;
        }

        .step-card h2 {
            color: #c62828;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: white;
        }

        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 5px;
            background-color: #333;
            color: white;
            font-size: 14px;
        }

        .alunos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .aluno-item {
            padding: 15px;
            border: 1px solid #444;
            border-radius: 8px;
            background: #333;
            transition: background-color 0.3s;
        }

        .aluno-item:hover {
            background: #444;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            cursor: pointer;
            font-size: 14px;
            color: white;
        }

        .checkbox-container input {
            margin-right: 12px;
            width: auto;
            transform: scale(1.2);
        }

        .form-actions {
            margin-top: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
        }

        .btn-primary {
            background: #c62828;
            color: white;
        }

        .btn-primary:hover {
            background: #9c1d1d;
        }

        .btn-secondary {
            background: #666;
            color: white;
        }

        .btn-secondary:hover {
            background: #555;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .alert-success {
            background: #2d5a2d;
            color: #4CAF50;
            border: 1px solid #4CAF50;
        }

        .alert-danger {
            background: #5a2d2d;
            color: #FF0000;
            border: 1px solid #FF0000;
        }

        .no-students {
            text-align: center;
            padding: 60px;
            color: #ccc;
            background: #222;
            border-radius: 10px;
        }

        .no-students i {
            font-size: 3rem;
            color: #c62828;
            margin-bottom: 15px;
        }

        .coordenador-resumo {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            margin-bottom: 30px;
        }

        .coordenador-resumo .card {
            background-color: #222;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            width: 45%;
        }
    </style>
</body>
</html>
<?php
// PDO connections close automatically when the script finishes, or when the object is unset.
// $con = null;
?>